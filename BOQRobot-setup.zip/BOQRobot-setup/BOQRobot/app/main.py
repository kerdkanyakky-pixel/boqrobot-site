"""BOQ Quantity Takeoff Robot - entry point."""
import logging
import logging.handlers
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def setup_logging():
    d = Path.home() / "BOQRobot" / "logs"
    d.mkdir(parents=True, exist_ok=True)
    h = logging.handlers.RotatingFileHandler(d / "boqrobot.log", maxBytes=2_000_000,
                                             backupCount=3, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    lg = logging.getLogger("boqrobot")
    lg.setLevel(logging.INFO)
    lg.addHandler(h)
    return lg


def main():
    log = setup_logging()
    import tkinter as tk
    from tkinter import messagebox
    from boqrobot import VERSION
    from boqrobot.ui.app import App
    log.info("application start v%s", VERSION)
    if sys.platform == "win32":
        try:  # sharp text on high-DPI screens
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()

    def report(exc, val, tb):
        log.error("unhandled: %s", "".join(traceback.format_exception(exc, val, tb)))
        messagebox.showerror("เกิดข้อผิดพลาด", f"{val}\n\nโปรแกรมยังทำงานต่อได้ (บันทึกรายละเอียดใน log แล้ว)")
    root.report_callback_exception = report
    App(root)
    root.mainloop()
    log.info("application exit")


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
