"""Drawing canvas: renders only the visible part of a PDF page (fast on large A1 sheets),
zoom/pan, and measurement tools. All points are stored in PDF page coordinates."""
import tkinter as tk
from tkinter import ttk

from ..core.geometry import dist, seg_distance, point_in_polygon, rect_points, \
    polyline_length, polygon_area, polygon_perimeter

TOOLS = [("pan", "✋ เลื่อน/เลือก"), ("calib", "📏 ตั้งสเกล"), ("line", "ความยาว"),
         ("poly", "พื้นที่"), ("rect", "สี่เหลี่ยม"), ("count", "นับจำนวน")]
HINT = {
    "pan": "ลากเมาส์เพื่อเลื่อนแบบ • ล้อเมาส์ = ซูม • คลิกเส้นวัดเพื่อเลือก แล้วลากจุดมุมเพื่อแก้ • Delete = ลบ",
    "calib": "คลิกจุดที่ 1 และจุดที่ 2 บนเส้นบอกระยะที่รู้ค่า แล้วกรอกระยะจริง",
    "line": "คลิกทีละจุด (กรอบเขียว = จับปลายเส้นในแบบ) • ดับเบิลคลิก/Enter/คลิกขวา = จบ • Backspace = ถอยจุด • Esc = ยกเลิก • กด Shift ค้าง = ล็อกแนวตั้ง/นอน",
    "poly": "คลิกรอบพื้นที่ • ดับเบิลคลิก/Enter/คลิกขวา = ปิดรูป • Backspace = ถอยจุด • Esc = ยกเลิก",
    "rect": "คลิกมุมที่ 1 แล้วคลิกมุมตรงข้าม",
    "count": "คลิกทุกจุดที่ต้องการนับ • Enter/คลิกขวา = บันทึก • Esc = ยกเลิก",
}


class DrawingView(ttk.Frame):
    def __init__(self, master, on_done=None, on_calib=None, on_select=None, on_delete=None,
                 status=None, on_edit=None):
        super().__init__(master)
        self.on_edit = on_edit
        self._vdrag = None
        self.on_done, self.on_calib = on_done, on_calib
        self.on_select, self.on_delete = on_select, on_delete
        self.status = status or (lambda s: None)
        self.doc = self.doc_path = self.page = None
        self.page_no = 1
        self.page_count = 0
        self.mm_per_pt = None
        self.zoom, self.ox, self.oy = 1.0, 0.0, 0.0
        self.overlays, self.selected = [], None
        self.pts, self.mouse = [], None
        self.tool = tk.StringVar(value="pan")
        self.deduct = tk.BooleanVar(value=False)
        self.snap = tk.BooleanVar(value=True)
        self._grid, self._grid_key, self._snapped = None, None, False
        self.cur_color = "#e6194b"
        self._img = None
        self._render_job = None
        self._drag = None
        self.on_page_change = None
        self._build()

    # ---------------- UI ----------------
    def _build(self):
        bar = ttk.Frame(self)
        bar.pack(fill="x")
        ttk.Button(bar, text="◀", width=3, command=lambda: self.goto(self.page_no - 1)).pack(side="left")
        self.page_var = tk.StringVar(value="-")
        e = ttk.Entry(bar, textvariable=self.page_var, width=5, justify="center")
        e.pack(side="left")
        e.bind("<Return>", lambda ev: self._goto_entry())
        self.page_lbl = ttk.Label(bar, text="/ 0")
        self.page_lbl.pack(side="left", padx=(2, 4))
        ttk.Button(bar, text="▶", width=3, command=lambda: self.goto(self.page_no + 1)).pack(side="left")
        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=6)
        ttk.Button(bar, text="－", width=3, command=lambda: self.zoom_by(1 / 1.25)).pack(side="left")
        ttk.Button(bar, text="＋", width=3, command=lambda: self.zoom_by(1.25)).pack(side="left")
        ttk.Button(bar, text="พอดีหน้า", command=self.fit_page).pack(side="left", padx=2)
        ttk.Button(bar, text="พอดีความกว้าง", command=self.fit_width).pack(side="left")
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(2, 2))
        ttk.Label(bar, text="เครื่องมือ:").pack(side="left", padx=(2, 4))
        for key, label in TOOLS:
            ttk.Radiobutton(bar, text=label, value=key, variable=self.tool,
                            style="Toolbutton", command=self._tool_changed).pack(side="left", padx=1)
        ttk.Checkbutton(bar, text="หักออก (−)", variable=self.deduct,
                        style="Toolbutton").pack(side="left", padx=6)
        ttk.Checkbutton(bar, text="🧲 จับจุดปลายเส้น", variable=self.snap,
                        style="Toolbutton").pack(side="left")
        self.cv = tk.Canvas(self, bg="#7f7f7f", highlightthickness=0, cursor="crosshair")
        self.cv.pack(fill="both", expand=True)
        c = self.cv
        c.bind("<Configure>", lambda e: self.schedule_render())
        c.bind("<ButtonPress-1>", self._press)
        c.bind("<B1-Motion>", self._drag_move)
        c.bind("<ButtonRelease-1>", self._release)
        c.bind("<Double-Button-1>", lambda e: self.finish())
        c.bind("<Button-3>", lambda e: self.finish())
        c.bind("<ButtonPress-2>", self._mpress)
        c.bind("<B2-Motion>", self._mdrag)
        c.bind("<Motion>", self._motion)
        c.bind("<MouseWheel>", self._wheel)
        c.bind("<Button-4>", lambda e: self._wheel(e, 120))
        c.bind("<Button-5>", lambda e: self._wheel(e, -120))
        for k, fn in (("<Return>", lambda e: self.finish()), ("<Escape>", lambda e: self.cancel()),
                      ("<BackSpace>", lambda e: self.undo_point()),
                      ("<Delete>", lambda e: self._delete_selected())):
            c.bind(k, fn)

    def _tool_changed(self):
        self.pts = []
        self.status(HINT[self.tool.get()])
        self.redraw()
        self.cv.focus_set()

    def set_tool(self, t):
        self.tool.set(t)
        self._tool_changed()

    # ---------------- document ----------------
    def load(self, doc, page_no, mm_per_pt, keep_view=False):
        same = doc is self.doc and page_no == self.page_no
        self.doc, self.page_no = doc, page_no
        self.page_count = doc.page_count
        self.page = doc[page_no - 1]
        self.mm_per_pt = mm_per_pt
        self.page_var.set(str(page_no))
        self.page_lbl.config(text=f"/ {self.page_count}")
        self.pts, self.selected = [], None
        if not (same and keep_view):
            self.after_idle(self.fit_page)
        else:
            self.schedule_render()

    def clear(self):
        self.doc = self.page = None
        self.cv.delete("all")
        self.page_var.set("-")
        self.page_lbl.config(text="/ 0")

    def goto(self, n):
        if self.doc and 1 <= n <= self.page_count and n != self.page_no and self.on_page_change:
            self.on_page_change(n)

    def _goto_entry(self):
        try:
            self.goto(int(self.page_var.get()))
        except ValueError:
            self.page_var.set(str(self.page_no))

    # ---------------- view transform ----------------
    def to_screen(self, p):
        return p[0] * self.zoom - self.ox, p[1] * self.zoom - self.oy

    def to_page(self, x, y):
        return (x + self.ox) / self.zoom, (y + self.oy) / self.zoom

    def fit_page(self):
        if not self.page:
            return
        w, h = max(self.cv.winfo_width(), 100), max(self.cv.winfo_height(), 100)
        r = self.page.rect
        self.zoom = min(w / r.width, h / r.height) * 0.97
        self.ox = (r.width * self.zoom - w) / 2
        self.oy = (r.height * self.zoom - h) / 2
        self.schedule_render(0)

    def fit_width(self):
        if not self.page:
            return
        w = max(self.cv.winfo_width(), 100)
        self.zoom = w / self.page.rect.width
        self.ox, self.oy = 0, 0
        self.schedule_render(0)

    def zoom_by(self, f, cx=None, cy=None):
        if not self.page:
            return
        if cx is None:
            cx, cy = self.cv.winfo_width() / 2, self.cv.winfo_height() / 2
        nz = max(0.05, min(40.0, self.zoom * f))
        px, py = self.to_page(cx, cy)
        self.zoom = nz
        self.ox, self.oy = px * nz - cx, py * nz - cy
        self.redraw()
        self.schedule_render()

    def _wheel(self, e, delta=None):
        d = delta if delta is not None else e.delta
        self.zoom_by(1.2 if d > 0 else 1 / 1.2, e.x, e.y)

    # ---------------- rendering ----------------
    def schedule_render(self, ms=60):
        if self._render_job:
            self.after_cancel(self._render_job)
        self._render_job = self.after(ms, self._render)
        self.redraw()

    def _render(self):
        import fitz
        self._render_job = None
        if not self.page:
            return
        w, h = self.cv.winfo_width(), self.cv.winfo_height()
        r = self.page.rect
        x0, y0 = self.to_page(0, 0)
        x1, y1 = self.to_page(w, h)
        clip = fitz.Rect(x0, y0, x1, y1) & r
        self.cv.delete("page")
        if clip.is_empty:
            return
        try:
            pix = self.page.get_pixmap(matrix=fitz.Matrix(self.zoom, self.zoom), clip=clip,
                                       alpha=False)
            self._img = tk.PhotoImage(data=pix.tobytes("ppm"))
        except Exception as e:  # corrupted page etc.
            self.status(f"แสดงหน้านี้ไม่ได้: {e}")
            return
        sx, sy = self.to_screen((clip.x0, clip.y0))
        self._img_origin = (clip.x0, clip.y0, self.zoom)
        self.cv.create_image(round(sx), round(sy), image=self._img, anchor="nw", tags="page")
        self.cv.tag_lower("page")
        # paper shadow/border
        a, b = self.to_screen((r.x0, r.y0)), self.to_screen((r.x1, r.y1))
        self.cv.delete("paper")
        self.cv.create_rectangle(*a, *b, outline="#333", tags="paper")

    def _move_image(self, dx, dy):
        self.cv.move("page", dx, dy)
        self.cv.move("paper", dx, dy)

    # ---------------- overlays ----------------
    def set_overlays(self, overlays, selected=None):
        """overlays: list of dict(id, kind, pts, color, label, sign, active)"""
        self.overlays = overlays
        self.selected = selected
        self.redraw()

    def redraw(self):
        c = self.cv
        c.delete("ov")
        if not self.page:
            return
        for o in self.overlays:
            self._draw_shape(o["kind"], o["pts"], o["color"], o["id"] == self.selected,
                             o.get("sign", 1) == -1, o.get("label", ""), o.get("active", True))
        if self.mouse and self._snapped and self.tool.get() != "pan":
            x, y = self.to_screen(self.mouse)
            c.create_rectangle(x - 5, y - 5, x + 5, y + 5, outline="#00b050", width=2, tags="ov")
        # in-progress
        if self.pts:
            t = self.tool.get()
            pts = list(self.pts) + ([self.mouse] if self.mouse and t not in ("count", "pan") else [])
            col = "#ff00ff" if t == "calib" else self.cur_color
            if t == "rect" and len(pts) == 2:
                self._draw_shape("rect", pts, col, True, self.deduct.get(), "", True)
            else:
                k = {"poly": "poly_open", "count": "count", "calib": "line"}.get(t, "line")
                self._draw_shape(k, pts, col, True, self.deduct.get(), "", True)
            self._live_readout(pts)

    def _draw_shape(self, kind, pts, color, sel, neg, label, active):
        c = self.cv
        sp = [self.to_screen(p) for p in pts]
        if not sp:
            return
        w = 3 if sel else 2
        dash = (6, 4) if neg else None
        if kind == "count":
            for x, y in sp:
                c.create_oval(x - 7, y - 7, x + 7, y + 7, outline=color, width=w, tags="ov")
                c.create_line(x - 4, y, x + 4, y, fill=color, width=w, tags="ov")
                if not neg:
                    c.create_line(x, y - 4, x, y + 4, fill=color, width=w, tags="ov")
        elif kind in ("poly", "rect", "poly_open"):
            if kind == "rect" and len(pts) == 2:
                sp = [self.to_screen(p) for p in rect_points(*pts)]
            flat = [v for p in sp for v in p]
            if len(sp) >= 3 and kind != "poly_open":
                c.create_polygon(*flat, outline=color, fill="", width=w + 1, dash=dash,
                                 tags="ov")
            elif len(sp) >= 2:
                c.create_line(*flat, fill=color, width=w, dash=dash, tags="ov")
        else:
            if len(sp) >= 2:
                c.create_line(*[v for p in sp for v in p], fill=color, width=w, dash=dash,
                              tags="ov")
        if sel:
            for x, y in sp:
                c.create_rectangle(x - 3, y - 3, x + 3, y + 3, fill="white", outline=color, tags="ov")
        if label:
            x, y = sp[0]
            c.create_text(x + 6, y - 8, text=label, fill=color, anchor="w",
                          font=("Tahoma", 9, "bold"), tags="ov")

    def _live_readout(self, pts):
        t = self.tool.get()
        k = self.mm_per_pt
        if t == "calib" and len(pts) >= 2:
            self.status(f"ระยะบนแบบ {dist(pts[0], pts[1]):.1f} pt — คลิกจุดที่ 2 เพื่อกรอกระยะจริง")
            return
        if not k:
            self.status("⚠ หน้านี้ยังไม่ได้ตั้งสเกล — ปริมาณจะเป็น 0 จนกว่าจะตั้งสเกล")
            return
        m = k / 1000
        if t == "line":
            self.status(f"ความยาว {polyline_length(pts) * m:,.3f} ม.")
        elif t == "poly" and len(pts) >= 3:
            self.status(f"พื้นที่ {polygon_area(pts) * m * m:,.3f} ตร.ม. • "
                        f"เส้นรอบรูป {polygon_perimeter(pts) * m:,.3f} ม.")
        elif t == "rect" and len(pts) == 2:
            (x1, y1), (x2, y2) = pts
            self.status(f"กว้าง {abs(x2 - x1) * m:,.3f} × ยาว {abs(y2 - y1) * m:,.3f} = "
                        f"{abs(x2 - x1) * abs(y2 - y1) * m * m:,.3f} ตร.ม.")
        elif t == "count":
            self.status(f"นับได้ {len(self.pts)} จุด — Enter/คลิกขวา เพื่อบันทึก")

    # ---------------- mouse ----------------
    def _snap_grid(self):
        key = (id(self.doc), self.page_no)
        if self._grid_key != key:
            self._grid_key, self._grid = key, {}
            try:
                self.status("กำลังเตรียมจุดจับบนแบบ...")
                self.update_idletasks()
                for d in self.page.get_drawings():
                    for it in d["items"]:
                        if it[0] in ("l", "c"):
                            pts = (it[1], it[-1])
                        elif it[0] == "re":
                            r = it[1]
                            pts = (r.tl, r.tr, r.bl, r.br)
                        else:
                            continue
                        for q in pts:
                            self._grid.setdefault((int(q.x // 6), int(q.y // 6)), []).append((q.x, q.y))
                self.status(HINT[self.tool.get()])
            except Exception:
                self._grid = {}
        return self._grid

    def _nearest_vertex(self, p):
        g = self._snap_grid()
        r = 9 / self.zoom
        cx, cy = int(p[0] // 6), int(p[1] // 6)
        n = int(r // 6) + 1
        best, bd = None, r
        for i in range(cx - n, cx + n + 1):
            for j in range(cy - n, cy + n + 1):
                for q in g.get((i, j), ()):
                    d = dist(p, q)
                    if d < bd:
                        best, bd = q, d
        return best

    def _snap(self, e):
        p = self.to_page(e.x, e.y)
        self._snapped = False
        if self.snap.get() and self.tool.get() in ("line", "poly", "rect", "calib") \
                and not (e.state & 0x0001):
            q = self._nearest_vertex(p)
            if q:
                self._snapped = True
                return q
        if self.pts and (e.state & 0x0001) and self.tool.get() in ("line", "poly", "calib"):
            q = self.pts[-1]
            p = (p[0], q[1]) if abs(p[0] - q[0]) > abs(p[1] - q[1]) else (q[0], p[1])
        return p

    def _press(self, e):
        self.cv.focus_set()
        if not self.page:
            return
        t = self.tool.get()
        if t == "pan":
            v = self._vertex_hit(e.x, e.y)
            if v:
                self._vdrag = v
                return
            self._drag = (e.x, e.y, e.x, e.y)
            return
        p = self._snap(e)
        if self.pts and dist(self.to_screen(p), self.to_screen(self.pts[-1])) < 2:
            return  # ignore double click duplicates
        self.pts.append(p)
        if t == "calib" and len(self.pts) == 2:
            a, b = self.pts
            self.pts = []
            self.redraw()
            if self.on_calib:
                self.on_calib(a, b)
            return
        if t == "rect" and len(self.pts) == 2:
            self.finish()
            return
        self.redraw()

    def _vertex_hit(self, x, y):
        """(overlay, index) if the click is on a vertex of the selected measurement."""
        o = next((o for o in self.overlays if o["id"] == self.selected), None)
        if not o or o["kind"] == "rect":
            return None
        for i, q in enumerate(o["pts"]):
            if dist((x, y), self.to_screen(q)) < 7:
                return (o, i)
        return None

    def _drag_move(self, e):
        if self._vdrag:
            o, i = self._vdrag
            p = self.to_page(e.x, e.y)
            if self.snap.get() and not (e.state & 0x0001):
                q = self._nearest_vertex(p)
                p = q or p
            o["pts"][i] = p
            self.redraw()
            return
        if self._drag:
            sx, sy, lx, ly = self._drag
            dx, dy = e.x - lx, e.y - ly
            self.ox -= dx
            self.oy -= dy
            self._move_image(dx, dy)
            self._drag = (sx, sy, e.x, e.y)
            self.redraw()

    def _release(self, e):
        if self._vdrag:
            o, _ = self._vdrag
            self._vdrag = None
            if self.on_edit:
                self.on_edit(o["id"], o["pts"])
            return
        if self._drag:
            sx, sy, _, _ = self._drag
            self._drag = None
            if abs(e.x - sx) < 3 and abs(e.y - sy) < 3:
                self._pick(e)
            else:
                self.schedule_render()

    def _mpress(self, e):
        self._mlast = (e.x, e.y)

    def _mdrag(self, e):
        dx, dy = e.x - self._mlast[0], e.y - self._mlast[1]
        self._mlast = (e.x, e.y)
        self.ox -= dx
        self.oy -= dy
        self._move_image(dx, dy)
        self.redraw()
        self.schedule_render(150)

    def _motion(self, e):
        if not self.page or self.tool.get() == "pan":
            return
        self.mouse = self._snap(e)
        if self.pts or self._snapped or getattr(self, "_had_snap", False):
            self._had_snap = self._snapped
            self.redraw()

    def _pick(self, e):
        p = (e.x, e.y)
        best, bd = None, 8.0
        for o in self.overlays:
            sp = [self.to_screen(q) for q in o["pts"]]
            if o["kind"] == "rect" and len(sp) == 2:
                sp = [self.to_screen(q) for q in rect_points(*o["pts"])]
            if o["kind"] == "count":
                d = min(dist(p, q) for q in sp)
            else:
                segs = list(zip(sp, sp[1:])) + ([(sp[-1], sp[0])] if o["kind"] != "line" else [])
                d = min((seg_distance(p, a, b) for a, b in segs), default=99)
                if o["kind"] != "line" and len(sp) >= 3 and point_in_polygon(p, sp):
                    d = min(d, 7.9)
            if d < bd:
                best, bd = o["id"], d
        self.selected = best
        self.redraw()
        if self.on_select:
            self.on_select(best)

    # ---------------- finishing ----------------
    def finish(self):
        t = self.tool.get()
        need = {"line": 2, "poly": 3, "rect": 2, "count": 1}.get(t)
        if not need:
            return
        if len(self.pts) < need:
            if self.pts:
                self.status(f"ต้องมีอย่างน้อย {need} จุด")
            return
        pts, self.pts, self.mouse = self.pts, [], None
        self.redraw()
        if self.on_done:
            self.on_done(t, pts, -1 if self.deduct.get() else 1)

    def cancel(self):
        self.pts, self.mouse = [], None
        self.redraw()
        self.status(HINT[self.tool.get()])

    def undo_point(self):
        if self.pts:
            self.pts.pop()
            self.redraw()

    def _delete_selected(self):
        if self.selected and self.on_delete:
            self.on_delete(self.selected)

    def show(self, pts):
        """Center view on given page points (traceability: jump to source)."""
        if not pts or not self.page:
            return
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
        w, h = self.cv.winfo_width(), self.cv.winfo_height()
        span = max(max(xs) - min(xs), max(ys) - min(ys), 20)
        vis_w, vis_h = w / self.zoom, h / self.zoom
        if span > 0.9 * min(vis_w, vis_h) or span < 0.1 * min(vis_w, vis_h):
            self.zoom = max(0.05, min(40, 0.5 * min(w, h) / span))
        self.ox, self.oy = cx * self.zoom - w / 2, cy * self.zoom - h / 2
        self.schedule_render(0)
