"""หน้าต่าง ถอดงานออกจากผู้รับเหมาเดิม — pick lines of the original BOQ, mark what is already done, export."""
import logging
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, filedialog, messagebox, simpledialog

from ..core import pullout as P

log = logging.getLogger("boqrobot")
MULTS = ["1 (ไม่คูณ)", "1.07 (VAT 7%)", "1.10 (OH 10%)", "1.15 (OH 15%)", "1.177 (OH 10% + VAT)",
         "1.2305 (OH 15% + VAT)"]
TICK, EMPTY, HALF = "☑", "☐", "◩"


def _num(t, default=1.0):
    try:
        return float(str(t).split()[0].replace(",", ""))
    except (ValueError, IndexError):
        return default


class PulloutDialog(tk.Toplevel):
    def __init__(self, master, files, settings, open_file=None):
        super().__init__(master)
        self.title("ถอดงานออกจากผู้รับเหมาเดิม")
        self.geometry("1280x780")
        self.minsize(900, 500)
        self.settings = settings
        self.open_file = open_file or (lambda p: None)
        self.files = list(files)
        self.rows, skipped = P.read_boq(self.files)
        self.sel, self.done = set(), {}
        self.pdfs = {}
        self._build()
        self._fill()
        if skipped:
            self.status("หมายเหตุ: " + " · ".join(skipped))
        self.transient(master)

    # ---------------- layout
    def _build(self):
        top = ttk.Frame(self, padding=(8, 6))
        top.pack(fill="x")
        ttk.Label(top, text="ชื่องาน").pack(side="left")
        self.job = tk.StringVar(value=self.settings.get("pull_job", "งานไฟฟ้า"))
        ttk.Entry(top, textvariable=self.job, width=22).pack(side="left", padx=(4, 12))
        ttk.Label(top, text="ผู้รับเหมาเดิม").pack(side="left")
        self.old = tk.StringVar(value=self.settings.get("pull_old", "ผู้รับเหมาเดิม"))
        ttk.Entry(top, textvariable=self.old, width=14).pack(side="left", padx=(4, 12))
        ttk.Label(top, text="โครงการ").pack(side="left")
        self.proj = tk.StringVar(value=self.settings.get("pull_project", ""))
        ttk.Entry(top, textvariable=self.proj, width=22).pack(side="left", padx=(4, 12))
        ttk.Label(top, text="ตัวคูณ OH/VAT").pack(side="left")
        self.mult = tk.StringVar(value=self.settings.get("pull_mult", MULTS[4]))
        ttk.Combobox(top, textvariable=self.mult, values=MULTS, width=20).pack(side="left", padx=4)

        sr = ttk.Frame(self, padding=(8, 0))
        sr.pack(fill="x")
        ttk.Label(sr, text="ค้นหา (หลายคำคั่นด้วย , )").pack(side="left")
        self.q = tk.StringVar()
        e = ttk.Entry(sr, textvariable=self.q, width=40)
        e.pack(side="left", padx=4)
        e.bind("<Return>", lambda ev: self.pick_found(True))
        ttk.Button(sr, text="✔ เลือกที่ค้นเจอ", command=lambda: self.pick_found(True)).pack(side="left", padx=2)
        ttk.Button(sr, text="✖ ไม่เลือกที่ค้นเจอ", command=lambda: self.pick_found(False)).pack(side="left", padx=2)
        ttk.Button(sr, text="ล้างที่เลือกทั้งหมด", command=self.clear).pack(side="left", padx=8)
        self.only = tk.BooleanVar(value=False)
        ttk.Checkbutton(sr, text="แสดงเฉพาะที่เลือก", variable=self.only, command=self._fill).pack(side="left", padx=8)
        ttk.Button(sr, text="📂 ดึงที่เลือกไว้จากไฟล์เดิม", command=self.load_prev).pack(side="right")

        ttk.Label(self, text="คลิกช่อง ☐ เพื่อเลือก/ไม่เลือก (คลิกที่หัวหมวด = ทั้งหมวด) · ดับเบิลคลิกช่อง 'ทำแล้ว %' "
                             "เพื่อใส่ว่าผู้รับเหมาเดิมทำไปแล้วเท่าไร · Space = เลือก/ไม่เลือกแถวที่ไฮไลต์",
                  foreground="#555", padding=(8, 2)).pack(fill="x")

        mid = ttk.Frame(self)
        mid.pack(fill="both", expand=True, padx=8)
        cols = ("sel", "done", "code", "unit", "qty", "amount", "group", "where")
        self.tv = ttk.Treeview(mid, columns=cols, selectmode="extended")
        heads = {"#0": ("รายการ", 470), "sel": ("เลือก", 50), "done": ("ทำแล้ว %", 70), "code": ("ข้อ", 55),
                 "unit": ("หน่วย", 55), "qty": ("จำนวน", 80), "amount": ("รวมเงิน (บาท)", 110),
                 "group": ("กลุ่ม", 150), "where": ("ที่มา", 200)}
        for c, (t, w) in heads.items():
            self.tv.heading(c, text=t)
            self.tv.column(c, width=w, stretch=c in ("#0", "where"),
                           anchor="e" if c in ("qty", "amount", "done") else ("center" if c == "sel" else "w"))
        self.tv.tag_configure("head", background="#EEF3FA", font=("Tahoma", 10, "bold"))
        self.tv.tag_configure("on", background="#FFF2B3")
        self.tv.tag_configure("done", background="#F8CBAD")
        self.tv.tag_configure("summary", foreground="#888")
        ys = ttk.Scrollbar(mid, orient="vertical", command=self.tv.yview)
        self.tv.configure(yscrollcommand=ys.set)
        self.tv.pack(side="left", fill="both", expand=True)
        ys.pack(side="left", fill="y")
        self.tv.bind("<Button-1>", self._click)
        self.tv.bind("<Double-1>", self._dbl)
        self.tv.bind("<space>", self._space)

        self.sum_var = tk.StringVar()
        ttk.Label(self, textvariable=self.sum_var, style="Total.TLabel", padding=(8, 6, 8, 0)).pack(fill="x")
        bot = ttk.Frame(self, padding=(8, 4))
        bot.pack(fill="x")
        ttk.Button(bot, text="💾 ทำไฟล์ (BOQ ขอราคา + ไฟล์ภายใน)", style="Accent.TButton",
                   command=self.export).pack(side="right", padx=4)
        ttk.Button(bot, text="📄 PDF ต้นฉบับ (สำหรับไฮไลต์)", command=self.pick_pdf).pack(side="right", padx=4)
        self.st = tk.StringVar()
        ttk.Label(bot, textvariable=self.st, foreground="#555").pack(side="left")

    def status(self, s):
        self.st.set(s)

    # ---------------- tree
    def _fill(self):
        self.tv.delete(*self.tv.get_children())
        only = self.only.get()
        keep = None
        if only:
            keep = set(self.sel)
            for k in list(self.sel):
                p = self.rows[k].parent
                while p is not None:
                    keep.add(p)
                    p = self.rows[p].parent
        roots = {}
        for x in self.rows:
            if keep is not None and x.idx not in keep:
                continue
            if x.parent is not None and (keep is None or x.parent in keep):
                parent = f"r{x.parent}"
            else:
                key = (x.source, x.sheet)
                if key not in roots:
                    roots[key] = self.tv.insert("", "end", iid=f"s{len(roots)}", text=f"{x.source} — {x.sheet}",
                                                open=True, tags=("head",))
                parent = roots[key]
            self.tv.insert(parent, "end", iid=f"r{x.idx}", text=f"{x.desc}", open=x.level <= 1 or only,
                           values=self._vals(x), tags=self._tags(x))
        self._update_sum()

    def _vals(self, x):
        if x.kind == "head":
            its = P.items_under(self.rows, x.idx)
            n = sum(1 for k in its if k in self.sel)
            mark = TICK if its and n == len(its) else (HALF if n else EMPTY)
            return (mark, "", x.code, "", "", f"{sum((self.rows[k].value or 0) for k in its):,.2f}",
                    x.group, x.where)
        v = x.value
        d = self.done.get(x.idx, 0)
        return (TICK if x.idx in self.sel else EMPTY, f"{d:g}%" if d else "", x.code, x.unit,
                "" if x.qty is None else f"{x.qty:,.2f}", "" if v is None else f"{v:,.2f}", x.group, x.where)

    def _tags(self, x):
        if x.kind == "head":
            return ("head",)
        t = []
        if x.idx in self.sel:
            t.append("done" if self.done.get(x.idx) else "on")
        if x.summary_of:
            t.append("summary")
        return tuple(t)

    def _refresh(self, idxs):
        touched = set(idxs)
        for k in idxs:
            p = self.rows[k].parent
            while p is not None:
                touched.add(p)
                p = self.rows[p].parent
        for k in touched:
            iid = f"r{k}"
            if self.tv.exists(iid):
                self.tv.item(iid, values=self._vals(self.rows[k]), tags=self._tags(self.rows[k]))
        self._update_sum()

    def _toggle(self, idxs):
        its = sorted({i for k in idxs for i in P.items_under(self.rows, k)})
        if not its:
            return
        on = not all(k in self.sel for k in its)
        for k in its:
            (self.sel.add if on else self.sel.discard)(k)
        self._refresh(its)

    def _idx(self, iid):
        return int(iid[1:]) if iid and iid.startswith("r") else None

    def _click(self, ev):
        if self.tv.identify_region(ev.x, ev.y) != "cell" or self.tv.identify_column(ev.x) != "#1":
            return None
        k = self._idx(self.tv.identify_row(ev.y))
        if k is not None:
            self._toggle([k])
        return "break"

    def _space(self, ev):
        ks = [self._idx(i) for i in self.tv.selection()]
        self._toggle([k for k in ks if k is not None])
        return "break"

    def _dbl(self, ev):
        if self.tv.identify_column(ev.x) != "#2":
            return None
        k = self._idx(self.tv.identify_row(ev.y))
        if k is None:
            return None
        its = P.items_under(self.rows, k)
        cur = self.done.get(its[0], 0) if its else 0
        v = simpledialog.askfloat("ทำแล้ว %", "ผู้รับเหมาเดิมทำไปแล้วกี่ % (0 = ยังไม่ทำ, 100 = ทำเสร็จแล้ว)\n"
                                  "ส่วนที่ทำแล้วไม่หัก และถ้า 100% จะไม่อยู่ใน BOQ ขอราคา",
                                  initialvalue=cur, minvalue=0, maxvalue=100, parent=self)
        if v is None:
            return "break"
        for i in its:
            if v:
                self.done[i] = v
                self.sel.add(i)
            else:
                self.done.pop(i, None)
        self._refresh(its)
        return "break"

    def _update_sum(self):
        t = P.totals(self.rows, self.sel, self.done)
        s = (f"เลือก {t['n']} บรรทัด · ยอดตาม BOQ เดิม {t['base']:,.2f} · ทำแล้ว {t['done']:,.2f} · "
             f"ยอดถอด {t['pull']:,.2f}  (ก่อน OH/VAT)")
        if t["notes"]:
            s += f" · ⚠ ยอดสรุปไม่นับซ้ำ {len(t['notes'])} บรรทัด"
        self.sum_var.set(s)

    # ---------------- actions
    def pick_found(self, on):
        found = P.search(self.rows, self.q.get())
        if not found:
            self.status("ไม่เจอรายการที่ตรงกับคำค้น")
            return
        for k in found:
            (self.sel.add if on else self.sel.discard)(k)
        if self.only.get():
            self._fill()
        else:
            self._refresh(found)
            self.tv.see(f"r{found[0]}")
        self.status(f"{'เลือก' if on else 'ไม่เลือก'} {len(found)} บรรทัดที่ตรงกับ “{self.q.get()}” — "
                    f"ตรวจดูในรายการก่อนทำไฟล์ (คำค้นอาจเจอบรรทัดที่ไม่เกี่ยว)")

    def clear(self):
        if self.sel and not messagebox.askyesno("ล้างที่เลือก", "ล้างรายการที่เลือกทั้งหมด?", parent=self):
            return
        self.sel.clear()
        self.done.clear()
        self._fill()

    def load_prev(self):
        p = filedialog.askopenfilename(parent=self, title="เลือกไฟล์ 'ถอดงาน…' ที่โปรแกรมทำไว้",
                                       filetypes=[("Excel", "*.xlsx")])
        if not p:
            return
        try:
            sel, done, miss = P.load_selection(self.rows, p)
        except ValueError as e:
            messagebox.showwarning("ดึงที่เลือกไว้", str(e), parent=self)
            return
        self.sel, self.done = set(sel), done
        self._fill()
        self.status(f"ดึงที่เลือกไว้ {len(sel)} บรรทัด" + (f" · หาไม่เจอ {miss} บรรทัด (ไฟล์ BOQ เปลี่ยน?)"
                                                           if miss else ""))

    def pick_pdf(self):
        srcs = sorted({self.rows[k].source for k in self.sel} or {x.source for x in self.rows})
        for src in srcs:
            p = filedialog.askopenfilename(parent=self, title=f"PDF ต้นฉบับของ {src} (กดยกเลิกถ้าไม่มี)",
                                           filetypes=[("PDF", "*.pdf")])
            if p:
                self.pdfs[src] = p
        self.status("PDF สำหรับไฮไลต์: " + (", ".join(f"{k} → {Path(v).name}" for k, v in self.pdfs.items())
                                             or "ยังไม่ได้เลือก"))

    def export(self):
        if not self.sel:
            messagebox.showinfo("ทำไฟล์", "ยังไม่ได้เลือกรายการ", parent=self)
            return
        job = self.job.get().strip() or "งาน"
        old = self.old.get().strip() or "ผู้รับเหมาเดิม"
        out = filedialog.askdirectory(parent=self, title="เลือกโฟลเดอร์ที่จะเก็บไฟล์ (จะสร้างโฟลเดอร์ 1 ส่งได้ / 2 ใช้ภายใน ให้)",
                                      initialdir=str(Path(self.files[0]).parent))
        if not out:
            return
        self.settings.update(pull_job=job, pull_old=old, pull_project=self.proj.get(), pull_mult=self.mult.get())
        try:
            res = P.export(self.rows, sorted(self.sel), self.done, job, old, out, _num(self.mult.get()),
                           project=self.proj.get().strip(), pdfs=self.pdfs, date=time.strftime("%y%m%d"))
        except PermissionError:
            messagebox.showerror("ทำไฟล์", "บันทึกไม่ได้ — ปิดไฟล์ Excel ชื่อเดียวกันที่เปิดค้างอยู่ก่อน", parent=self)
            return
        t = res["totals"]
        msg = (f"ทำไฟล์แล้ว\n\nส่งผู้รับเหมาใหม่ได้:\n  {Path(res['send']).name}\n\n"
               f"ใช้ภายใน ห้ามส่งผู้รับเหมา:\n  {Path(res['internal']).name}\n")
        for st in res["pdf"]:
            msg += f"  {Path(st['path']).name} (ไฮไลต์เจอ {st['found']}/{st['wanted']} บรรทัด)\n"
        msg += f"\nยอดถอด (ก่อน OH/VAT) {t['pull']:,.2f} บาท — ตัวคูณแก้ได้ในไฟล์ภายใน ชีท สรุปยอดหัก"
        if any(st["missing"] for st in res["pdf"]):
            msg += "\n\n⚠ บางบรรทัดหาใน PDF ไม่เจอ — ดูรายชื่อในชีท สรุปยอดหัก"
        log.info("pullout %s: %d lines, pull %.2f", job, t["n"], t["pull"])
        messagebox.showinfo("ทำไฟล์", msg, parent=self)
        self.open_file(res["internal_dir"])
