"""'ถอด BOQ อัตโนมัติ' wizard: pick sheets -> AI finds geometry -> core calculates -> review."""
import logging
import queue
import re
import threading
import tkinter as tk
from tkinter import ttk, messagebox

from ..core import ai
from ..core.scale import auto_scale_page

log = logging.getLogger("boqrobot")
SKIP = re.compile(r"KEY|MASTER|LAND|SITE|LAYOUT|PATTERN|DETAIL|SECTION|ELEVATION|COVER|LIST", re.I)


def default_pick(title):
    return bool(title) and "PLAN" in title.upper() and not SKIP.search(title)


class AIDialog(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app, self.proj = app, app.proj
        self.title("🤖 ถอด BOQ อัตโนมัติ (AI)")
        self.geometry("820x640")
        self.transient(app.root)
        st = app.settings
        f = ttk.Frame(self, padding=10)
        f.pack(fill="both", expand=True)
        ttk.Label(f, wraplength=780, justify="left", text=(
            "AI ดูแบบแล้วลากขอบห้อง/แนวผนัง/สัญลักษณ์ให้ • โปรแกรมคำนวณปริมาณเองจากสเกล (ไม่ใช้ตัวเลขจาก AI) "
            "• มุมทุกจุดดูดเข้ามุมเส้นจริงในแบบ • ประตู/หน้าต่างนับจากป้ายในแบบ (ไม่ใช้ AI)\n"
            "ผลที่ได้เป็น 'ร่าง' — ต้องเปิดดูบนแบบ แก้ที่ผิด แล้วติ๊กตรวจแล้วในแท็บ BOQ")).pack(anchor="w")
        g = ttk.Frame(f)
        g.pack(fill="x", pady=8)
        ttk.Label(g, text="Claude API key\n(ไม่ต้องใส่)").grid(row=0, column=0, sticky="w")
        self.key = tk.StringVar(value=st.get("api_key", ""))
        ttk.Entry(g, textvariable=self.key, show="•", width=60).grid(row=0, column=1, sticky="w", padx=6)
        ttk.Label(g, text="รุ่น AI").grid(row=1, column=0, sticky="w", pady=4)
        self.model = tk.StringVar(value=st.get("ai_model", ai.MODELS[0]))
        ttk.Combobox(g, textvariable=self.model, values=ai.MODELS, width=30).grid(row=1, column=1, sticky="w", padx=6)
        ttk.Label(g, foreground="#666", wraplength=640, justify="left",
                  text="เว้นว่างไว้ = ใช้ AI ที่รวมมากับ BOQ Robot (ไม่ต้องสมัครอะไรเพิ่ม) • "
                       "ใส่ key ของตัวเองก็ได้ (คิดค่าใช้จ่ายในบัญชีนั้น) — รุ่น AI ใช้เฉพาะเมื่อใส่ key เอง"
                  ).grid(row=2, column=1, sticky="w", padx=6)
        ttk.Label(f, text="เลือกแผ่นที่จะถอด (คลิกเพื่อติ๊ก/เอาออก) — แนะนำเลือกเฉพาะแปลนที่ใช้ถอดจริง ไม่เลือกแผ่นซ้ำกัน"
                  ).pack(anchor="w")
        self.tree = ttk.Treeview(f, columns=("pick", "title", "scale"), show="headings", height=14)
        for c, t, w in (("pick", "ถอด", 50), ("title", "แผ่น", 480), ("scale", "สเกล", 200)):
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor="center" if c == "pick" else "w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<ButtonRelease-1>", self._toggle)
        self.pages = {}
        for d in self.proj.drawings():
            for p in self.proj.pages(d["id"]):
                t = p["title"] or f"หน้า {p['page_no']}"
                pick = default_pick(p["title"])
                self.pages[f"g{p['id']}"] = [p["id"], d["id"], pick]
                self.tree.insert("", "end", iid=f"g{p['id']}", values=(
                    "✓" if pick else "", f"{p['page_no']}. {t}",
                    p["scale_label"].split(" ")[0] if p["mm_per_pt"] else "ยังไม่มี (จะหาให้อัตโนมัติ)"))
        o = ttk.Frame(f)
        o.pack(fill="x", pady=6)
        self.tags = tk.BooleanVar(value=True)
        ttk.Checkbutton(o, text="นับประตู/หน้าต่างจากป้าย D1, W1 ในแผ่นที่เลือก", variable=self.tags).pack(side="left")
        self.info = ttk.Label(f, text="")
        self.info.pack(anchor="w")
        b = ttk.Frame(f)
        b.pack(fill="x")
        self.go = ttk.Button(b, text="▶ เริ่มถอด", command=self.start)
        self.go.pack(side="right")
        ttk.Button(b, text="ปิด", command=self.destroy).pack(side="right", padx=6)
        self._count()

    def _toggle(self, e):
        iid = self.tree.identify_row(e.y)
        if iid in self.pages:
            self.pages[iid][2] = not self.pages[iid][2]
            self.tree.set(iid, "pick", "✓" if self.pages[iid][2] else "")
            self._count()

    def _count(self):
        n = sum(1 for v in self.pages.values() if v[2])
        self.info.config(text=f"เลือก {n} แผ่น • ใช้เวลาประมาณ {max(1, n)}–{max(2, n * 2)} นาที")

    def start(self):
        import fitz
        picked = [v for v in self.pages.values() if v[2]]
        if not picked:
            messagebox.showinfo("เลือกแผ่น", "กรุณาเลือกแผ่นอย่างน้อย 1 แผ่น", parent=self)
            return
        key = self.key.get().strip()
        if key and not key.startswith("sk-"):
            messagebox.showerror("API key", "Claude API key ต้องขึ้นต้นด้วย sk- (หรือเว้นว่างเพื่อใช้ AI ที่รวมมากับโปรแกรม)", parent=self)
            return
        self.app.settings["api_key"] = key
        self.app.settings["ai_model"] = self.model.get()
        self.app._save_settings()
        self.go.state(["disabled"])
        docs, jobs, skipped = {}, [], []
        for pid, did, _ in picked:
            p = self.proj.page(pid)
            doc = docs.get(did) or docs.setdefault(did, fitz.open(self.proj.drawing_path(did)))
            page = doc[p["page_no"] - 1]
            if not p["mm_per_pt"]:
                self.info.config(text=f"หาสเกล {p['title']} ...")
                self.update()
                mm, label, note, est = auto_scale_page(page)
                if not mm:
                    skipped.append(f"{p['page_no']}. {p['title']}: ไม่มีสเกลที่ยืนยันได้ — ตั้งสเกลเองก่อน ({note})")
                    continue
                self.proj.set_scale(pid, mm, label, "auto")
                p = self.proj.page(pid)
            # re-run replaces the previous automatic result for this sheet
            self.proj.con.execute("DELETE FROM measurements WHERE page_id=? AND source IN ('ai','tag')", (pid,))
            png, clip, z, (w, h) = ai.render_page(page)
            fields = dict(title=p["title"] or f"page {p['page_no']}", w=w, h=h, text=ai.sheet_text(page, clip))
            tags = ai.door_window_tags(page, clip) if self.tags.get() and not ai.skip_tag_count(p["title"]) else {}
            jobs.append(dict(pid=pid, did=did, png=png, clip=clip, z=z, fields=fields, tags=tags,
                             title=f"{p['page_no']}. {p['title']}"))
        for d in docs.values():
            d.close()
        self.proj.con.commit()
        if not jobs:
            self._finish([], skipped)
            return
        q = queue.Queue()
        settings = dict(self.app.settings)

        def work():
            for j in jobs:
                try:
                    text, usage = ai.run(settings, "takeoff", j["png"], j["fields"])
                    q.put((j, ai.parse_result(text), usage, None))
                except Exception as e:
                    log.exception("ai page")
                    q.put((j, None, {}, str(e)))
                    if isinstance(e, ai.AIError) and ("API key" in str(e) or "สิทธิ์" in str(e) or "ครบ" in str(e)):
                        break
            q.put(None)

        threading.Thread(target=work, daemon=True).start()
        report, state = [], {"n": 0}

        def poll():
            try:
                while True:
                    item = q.get_nowait()
                    if item is None:
                        self._finish(report, skipped)
                        return
                    j, res, usage, err = item
                    state["n"] += 1
                    report.append(self._apply(j, res, usage, err))
                    self.info.config(text=f"ถอดแล้ว {state['n']}/{len(jobs)} แผ่น ...")
            except queue.Empty:
                pass
            if self.winfo_exists():
                self.after(500, poll)

        self.info.config(text=f"กำลังส่งแบบให้ AI 0/{len(jobs)} แผ่น ... (ปิดหน้าต่างนี้ไม่ได้จนกว่าจะเสร็จ)")
        poll()

    def _apply(self, j, res, usage, err):
        import fitz
        page_row = self.proj.page(j["pid"])
        n_tags = 0
        if j["tags"]:
            n_tags = ai.apply_door_window_tags(self.proj, page_row, j["tags"])
        if err:
            return (j["title"], f"AI ผิดพลาด: {err}" + (f" • นับประตู/หน้าต่าง {n_tags}" if n_tags else ""))
        with fitz.open(self.proj.drawing_path(j["did"])) as doc:
            grid = ai.vertex_index(doc[page_row["page_no"] - 1])
        s = ai.apply_result(self.proj, page_row, res, j["clip"], j["z"], grid)
        tok = usage.get("input_tokens", 0) + usage.get("output_tokens", 0)
        msg = (f"รูปทรง {s['objects']} รายการ (ดูดเข้ามุมจริง {s['snapped']}/{s['points']} จุด)"
               f" • ประตู/หน้าต่าง {n_tags if not ai.skip_tag_count(page_row['title']) else 'ไม่นับ (แผ่นนี้ซ้ำกับแปลน)'}"
               f" • {tok:,} tokens")
        if s["warnings"]:
            msg += " • ⚠ " + " / ".join(s["warnings"])
        return (j["title"], msg)

    def _finish(self, report, skipped):
        self.app._after_change()
        self.app.refresh_boq()
        for w in self.winfo_children():
            w.destroy()
        f = ttk.Frame(self, padding=10)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="เสร็จแล้ว — ขั้นต่อไป: เปิดแต่ละแผ่นดูเส้นที่ AI ลากไว้ แก้มุมที่ผิด (คลิกเลือกแล้วลากจุดมุม) "
                          "แล้วไปแท็บ BOQ ติ๊กตรวจแล้ว", wraplength=780).pack(anchor="w", pady=(0, 6))
        t = ttk.Treeview(f, columns=("s", "r"), show="headings")
        t.heading("s", text="แผ่น")
        t.heading("r", text="ผล")
        t.column("s", width=260)
        t.column("r", width=520)
        for s, r in report:
            t.insert("", "end", values=(s, r))
        for s in skipped:
            t.insert("", "end", values=("ข้าม", s))
        t.pack(fill="both", expand=True)
        b = ttk.Frame(f)
        b.pack(fill="x", pady=6)
        ttk.Button(b, text="ไปหน้า BOQ", command=lambda: (self.app.nb.select(1), self.destroy())).pack(side="right")
        ttk.Button(b, text="ไปดูบนแบบ", command=self.destroy).pack(side="right", padx=6)
