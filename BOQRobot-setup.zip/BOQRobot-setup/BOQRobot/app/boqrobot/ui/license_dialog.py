"""Trial / activation window."""
import tkinter as tk
from tkinter import ttk, messagebox

from ..core import lic


def status_text(st):
    if st["mode"] == "licensed":
        return "เปิดใช้งานแล้ว" + ("" if st["expiry"] is None else f" (ถึง {st['expiry']:%d/%m/%Y})")
    if st["mode"] == "trial":
        return f"ทดลองใช้ฟรี เหลือ {st['days_left']} วัน"
    return "หมดช่วงทดลองใช้"


class LicenseDialog(tk.Toplevel):
    """blocking=True: trial ended — closing without a valid code closes the program."""

    def __init__(self, root, blocking=False, on_done=None):
        super().__init__(root)
        self.root, self.blocking, self.on_done, self.ok = root, blocking, on_done, False
        self.title("สิทธิ์ใช้งาน BOQ Robot")
        self.transient(root)
        self.resizable(False, False)
        st = lic.status()
        f = ttk.Frame(self, padding=16)
        f.pack(fill="both", expand=True)
        head = "หมดช่วงทดลองใช้ 3 เดือนแล้ว" if st["mode"] == "expired" else status_text(st)
        ttk.Label(f, text=head, style="Big.TLabel").pack(anchor="w")
        if st["mode"] != "licensed":
            ttk.Label(f, wraplength=460, justify="left", text=(
                f"ใช้ต่อได้โดยขอรหัสเปิดใช้: ส่ง 'รหัสเครื่อง' ด้านล่างมาที่ {lic.CONTACT} "
                "แล้วนำรหัสที่ได้มาวางในช่อง 'รหัสเปิดใช้'")).pack(anchor="w", pady=(6, 10))
        g = ttk.Frame(f)
        g.pack(fill="x")
        ttk.Label(g, text="รหัสเครื่อง").grid(row=0, column=0, sticky="w")
        mid = tk.StringVar(value=st["mid"])
        e = ttk.Entry(g, textvariable=mid, width=16, state="readonly", font=("Consolas", 12))
        e.grid(row=0, column=1, sticky="w", padx=6)
        ttk.Button(g, text="คัดลอก", command=lambda: self._copy(st["mid"])).grid(row=0, column=2, sticky="w")
        ttk.Label(g, text="รหัสเปิดใช้").grid(row=1, column=0, sticky="nw", pady=(10, 0))
        self.code = tk.Text(g, width=48, height=4, font=("Consolas", 10), wrap="char")
        self.code.grid(row=1, column=1, columnspan=2, sticky="w", padx=6, pady=(10, 0))
        b = ttk.Frame(f)
        b.pack(fill="x", pady=(12, 0))
        ttk.Button(b, text="เปิดใช้งาน", style="Accent.TButton", command=self._activate).pack(side="right")
        ttk.Button(b, text="ปิดโปรแกรม" if blocking else "ปิด", command=self._close).pack(side="right", padx=6)
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.grab_set()

    def _copy(self, s):
        self.clipboard_clear()
        self.clipboard_append(s)
        messagebox.showinfo("คัดลอกแล้ว", f"คัดลอกรหัสเครื่อง {s} แล้ว — วางในไลน์ได้เลย", parent=self)

    def _activate(self):
        ok, msg = lic.activate(self.code.get("1.0", "end").strip())
        if ok:
            self.ok = True
            messagebox.showinfo("สิทธิ์ใช้งาน", msg, parent=self)
            self.destroy()
            if self.on_done:
                self.on_done()
        else:
            messagebox.showerror("สิทธิ์ใช้งาน", msg, parent=self)

    def _close(self):
        self.destroy()
        if self.blocking and not self.ok:
            self.root.destroy()
        elif self.on_done:
            self.on_done()
