"""Small forms."""
import tkinter as tk
from tkinter import ttk, messagebox, colorchooser

from ..core import formula as fm
from ..core.library import FORMULA_PRESETS, MODE_LABEL, UNITS, DISCIPLINES


class Form(tk.Toplevel):
    """Generic label/field dialog. fields: list of (key, label, kind, default, options)."""

    def __init__(self, master, title, fields, note=None, validate=None):
        super().__init__(master)
        self.title(title)
        self.transient(master)
        self.resizable(False, False)
        self.result = None
        self._validate = validate
        self.vars = {}
        fr = ttk.Frame(self, padding=12)
        fr.pack(fill="both", expand=True)
        r = 0
        if note:
            ttk.Label(fr, text=note, foreground="#555", wraplength=420, justify="left").grid(
                row=r, column=0, columnspan=2, sticky="w", pady=(0, 8))
            r += 1
        first = None
        for key, label, kind, default, opts in fields:
            ttk.Label(fr, text=label).grid(row=r, column=0, sticky="w", padx=(0, 8), pady=3)
            if kind == "check":
                v = tk.BooleanVar(value=bool(default))
                w = ttk.Checkbutton(fr, variable=v)
            elif kind == "combo":
                v = tk.StringVar(value="" if default is None else str(default))
                w = ttk.Combobox(fr, textvariable=v, values=opts or [], width=40)
            elif kind == "readonly":
                v = tk.StringVar(value="" if default is None else str(default))
                w = ttk.Combobox(fr, textvariable=v, values=opts or [], width=40, state="readonly")
            elif kind == "text":
                v = tk.StringVar(value=default or "")
                w = ttk.Entry(fr, textvariable=v, width=44)
            else:  # number
                v = tk.StringVar(value="" if default in (None, "") else f"{default:g}")
                w = ttk.Entry(fr, textvariable=v, width=16)
            w.grid(row=r, column=1, sticky="w", pady=3)
            first = first or w
            self.vars[key] = (v, kind)
            r += 1
        b = ttk.Frame(fr)
        b.grid(row=r, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(b, text="ตกลง", command=self._ok).pack(side="left", padx=4)
        ttk.Button(b, text="ยกเลิก", command=self.destroy).pack(side="left")
        self.bind("<Return>", lambda e: self._ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        if first:
            first.focus_set()
        self.wait_visibility()
        self.geometry(f"+{master.winfo_rootx() + 120}+{master.winfo_rooty() + 80}")

    def _ok(self):
        out = {}
        for k, (v, kind) in self.vars.items():
            val = v.get()
            if kind == "number":
                s = str(val).replace(",", "").strip()
                if s == "":
                    val = None
                else:
                    try:
                        val = float(s)
                    except ValueError:
                        messagebox.showerror("ข้อมูลไม่ถูกต้อง", f"'{val}' ไม่ใช่ตัวเลข", parent=self)
                        return
            out[k] = val
        if self._validate:
            err = self._validate(out)
            if err:
                messagebox.showerror("ข้อมูลไม่ถูกต้อง", err, parent=self)
                return
        self.result = out
        self.destroy()


def ask(master, title, fields, note=None, validate=None):
    d = Form(master, title, fields, note, validate)
    master.wait_window(d)
    return d.result


def project_form(master, info=None, new=True):
    info = info or {}
    return ask(master, "โปรเจคใหม่" if new else "ข้อมูลโปรเจค", [
        ("name", "ชื่อโปรเจค *", "text", info.get("name", ""), None),
        ("client", "ลูกค้า / เจ้าของ", "text", info.get("client", ""), None),
        ("address", "ที่ตั้งโครงการ", "text", info.get("address", ""), None),
        ("number", "เลขที่โครงการ", "text", info.get("number", ""), None),
        ("notes", "หมายเหตุ", "text", info.get("notes", ""), None),
    ], validate=lambda o: None if o["name"].strip() else "กรุณาใส่ชื่อโปรเจค")


def drawing_form(master, d):
    return ask(master, "ข้อมูลแบบ", [
        ("number", "เลขที่แบบ (เช่น A-101)", "text", d["number"], None),
        ("title", "ชื่อแบบ", "text", d["title"], None),
        ("discipline", "หมวดแบบ", "readonly", d["discipline"], DISCIPLINES),
        ("revision", "Revision", "text", d["revision"], None),
    ])


def _check_formula(o):
    try:
        fm.validate(o["formula"])
    except fm.FormulaError as e:
        return str(e)
    if not o["name"].strip():
        return "กรุณาใส่ชื่อรายการ"
    return None


def item_form(master, categories, it=None):
    it = dict(it) if it else {"category": categories[0] if categories else "งานทั่วไป",
                              "name": "", "unit": "ตร.ม.", "mode": "AREA", "formula": "A",
                              "H": 0, "T": 0, "W": 0, "F": 1, "waste": 0, "mat_rate": 0,
                              "lab_rate": 0, "manual_qty": 0, "note": ""}
    modes = [f"{k} - {v}" for k, v in MODE_LABEL.items()]
    presets = sorted({f for v in FORMULA_PRESETS.values() for f in v})
    note = ("สูตรใช้ตัวแปร: " + ", ".join(f"{k}={v}" for k, v in fm.VARIABLES.items()) +
            "\nตัวอย่าง: ผนัง L*H • พื้นคอนกรีต A*T • คาน L*W*H • เหล็ก L*F (F=กก./ม.)")
    r = ask(master, "รายการถอดปริมาณ", [
        ("category", "หมวดงาน", "combo", it["category"], categories),
        ("name", "ชื่อรายการ *", "text", it["name"], None),
        ("mode", "วิธีวัดหลัก", "readonly",
         next(m for m in modes if m.startswith(it["mode"])), modes),
        ("formula", "สูตรคำนวณ", "combo", it["formula"], presets),
        ("unit", "หน่วย", "combo", it["unit"], UNITS),
        ("H", "H สูง (ม.)", "number", it["H"], None),
        ("T", "T หนา (ม.)", "number", it["T"], None),
        ("W", "W กว้าง (ม.)", "number", it["W"], None),
        ("F", "F ตัวคูณ", "number", it["F"], None),
        ("waste", "เผื่อเสียหาย (%)", "number", it["waste"], None),
        ("mat_rate", "ค่าวัสดุ / หน่วย (บาท)", "number", it["mat_rate"], None),
        ("lab_rate", "ค่าแรง / หน่วย (บาท)", "number", it["lab_rate"], None),
        ("manual_qty", "ปริมาณป้อนเอง (บวกเพิ่ม)", "number", it["manual_qty"], None),
        ("note", "หมายเหตุ", "text", it["note"], None),
    ], note=note, validate=_check_formula)
    if r:
        r["mode"] = r["mode"].split(" ")[0]
        for k in ("H", "T", "W", "waste", "mat_rate", "lab_rate", "manual_qty"):
            r[k] = r[k] or 0
        r["F"] = 1 if r["F"] is None else r["F"]
        r["category"] = r["category"].strip() or "งานทั่วไป"
    return r


def measurement_form(master, m, item):
    return ask(master, f"แก้ไขการวัด #{m['id']}", [
        ("H", f"H สูง (ม.)  [ค่าตั้งต้น {item['H']:g}]", "number", m["H"], None),
        ("T", f"T หนา (ม.)  [ค่าตั้งต้น {item['T']:g}]", "number", m["T"], None),
        ("W", f"W กว้าง (ม.)  [ค่าตั้งต้น {item['W']:g}]", "number", m["W"], None),
        ("repeat", "จำนวนซ้ำ / ตัวคูณ (เช่น ลาดเอียง)", "number", m["repeat"] or 1, None),
        ("deduct", "เป็นรายการหักออก (−)", "check", m["sign"] == -1, None),
        ("note", "หมายเหตุ (เช่น ชื่อห้อง/ตำแหน่ง)", "text", m["note"] or "", None),
    ], note="ช่องที่เว้นว่าง = ใช้ค่าตั้งต้นของรายการ")


def pick_color(master, initial):
    c = colorchooser.askcolor(initial, parent=master)
    return c[1] if c and c[1] else None
