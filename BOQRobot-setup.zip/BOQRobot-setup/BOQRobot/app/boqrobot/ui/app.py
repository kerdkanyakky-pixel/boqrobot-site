"""Main window."""
import json
import logging
import os
import sys
import time
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path
from tkinter import ttk, filedialog, messagebox

from .. import APP_NAME, VERSION
from ..core.project import Project
from ..core.geometry import calibrate, standard_scale_mm_per_pt, dist
from ..core.takeoff import compute, totals, KIND_LABEL
from ..core.qa import run_checks
from ..core.export import export_excel, export_csv, export_markup_pdf
from ..core.library import MODE_TOOL
from ..core.demo import create_demo
from . import dialogs
from .viewer import DrawingView

log = logging.getLogger("boqrobot")
HOME = Path.home() / "BOQRobot"
SETTINGS = HOME / "settings.json"
STD_SCALES = ["1:5", "1:10", "1:20", "1:25", "1:50", "1:75", "1:100", "1:125", "1:150",
              "1:200", "1:250", "1:500"]


def safe(fn):
    """Never crash: log + friendly message."""
    def wrap(self, *a, **k):
        try:
            return fn(self, *a, **k)
        except Exception as e:
            log.exception("error in %s", fn.__name__)
            messagebox.showerror("เกิดข้อผิดพลาด", f"{e}\n\n(รายละเอียดบันทึกไว้ใน {HOME / 'logs'})")
    wrap.__name__ = fn.__name__
    return wrap


def open_file(path):
    try:
        if sys.platform == "win32":
            os.startfile(path)  # noqa
    except Exception:
        pass


OVER_ONLY = "เอาคืนเฉพาะที่นับเกิน (ไม่แจ้งที่ไม่ได้เสนอ / นับขาด)"
ALL_ISSUES = "แจ้งทุกเรื่อง"


class App:
    def __init__(self, root):
        self.root = root
        self.proj = None
        self.docs = {}
        self.cur_did = self.cur_pid = self.cur_item = self.sel_mid = None
        self.rows = []
        self.settings = self._load_settings()
        self._fonts()
        root.title(f"{APP_NAME} {VERSION}")
        root.geometry(self._fit_geometry(self.settings.get("geometry", "1400x850")))
        root.minsize(1000, 600)
        self._build()
        root.protocol("WM_DELETE_WINDOW", self.quit)
        if not self._check_license():
            return
        last = self.settings.get("recent", [])
        if last and (Path(last[0]) / Project.DB).exists():
            root.after(200, lambda: self.open_project(last[0]))

    # ---------------- license ----------------
    def _check_license(self):
        from ..core import lic
        from .license_dialog import LicenseDialog, status_text
        try:
            st = lic.status()
        except Exception:
            log.exception("license")
            return True
        self.root.title(f"{APP_NAME} {VERSION} — {status_text(st)}")
        if st["mode"] == "expired":
            self.root.after(150, lambda: LicenseDialog(self.root, blocking=True, on_done=self._license_changed))
            return False
        return True

    def show_license(self):
        from .license_dialog import LicenseDialog
        LicenseDialog(self.root, on_done=self._license_changed)

    def _license_changed(self):
        from ..core import lic
        from .license_dialog import status_text
        self.root.title(f"{APP_NAME} {VERSION} — {status_text(lic.status())}")

    # ---------------- settings ----------------
    def _load_settings(self):
        try:
            return json.loads(SETTINGS.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_settings(self):
        try:
            HOME.mkdir(parents=True, exist_ok=True)
            self.settings["geometry"] = self.root.geometry()
            SETTINGS.write_text(json.dumps(self.settings, ensure_ascii=False, indent=1),
                                encoding="utf-8")
        except Exception:
            log.exception("settings")

    def _fonts(self):
        fams = set(tkfont.families())
        fam = next((f for f in ("Leelawadee UI", "Tahoma", "Noto Sans Thai", "Loma") if f in fams),
                   None)
        for n in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            if fam:
                tkfont.nametofont(n).configure(family=fam, size=10)
        st = ttk.Style()
        if "vista" in st.theme_names():
            st.theme_use("vista")
        elif "clam" in st.theme_names():
            st.theme_use("clam")
        st.configure("Treeview", rowheight=24)
        st.configure("Accent.TButton", font=(fam or "Tahoma", 10, "bold"))
        st.configure("Big.TLabel", font=(fam or "Tahoma", 12, "bold"))
        st.configure("Total.TLabel", font=(fam or "Tahoma", 11, "bold"))

    # ---------------- layout ----------------
    def _fit_geometry(self, geo):
        """Saved/default size, shrunk to the screen so the window's right edge (buttons) is never off-screen."""
        import re
        m = re.match(r"(\d+)x(\d+)(?:([+-]-?\d+)([+-]-?\d+))?$", str(geo or ""))
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        if not m:
            return f"{min(1400, sw)}x{min(850, sh - 80)}+0+0"
        w, h = min(int(m.group(1)), sw), min(int(m.group(2)), sh - 80)
        x = int((m.group(3) or "0").replace("+", ""))   # Windows saves "+-8+-8" when maximised
        y = int((m.group(4) or "0").replace("+", ""))
        w, h = max(w, min(1000, sw)), max(h, min(600, sh))
        x = max(0, min(x, sw - w))
        y = max(0, min(y, sh - h - 40))
        return f"{w}x{h}+{x}+{y}"

    def _build(self):
        # two rows so nothing is cut off on narrow screens:
        # row 1 = project, row 2 = tools + export
        top = ttk.Frame(self.root, padding=(6, 4, 6, 0))
        top.pack(fill="x")
        tools = ttk.Frame(self.root, padding=(6, 2, 6, 4))
        tools.pack(fill="x")
        for text, cmd in (("📁 โปรเจคใหม่", self.new_project), ("📂 เปิดโปรเจค", self.ask_open),
                          ("ℹ ข้อมูลโปรเจค", self.edit_project)):
            ttk.Button(top, text=text, command=cmd).pack(side="left", padx=2)
        ttk.Button(tools, text="🤖 ถอด BOQ (AI)", command=self.ai_takeoff,
                   style="Accent.TButton").pack(side="left", padx=2)
        ttk.Button(tools, text="🔍 ตรวจ BOQ ผู้รับเหมา", command=self.audit_contractor_boq).pack(side="left", padx=2)
        ttk.Button(tools, text="📑 เทียบใบเสนอ", command=self.compare_quotes).pack(side="left", padx=2)
        ttk.Button(tools, text="✂ ถอดงานจากผู้รับเหมาเดิม", command=self.pullout).pack(side="left", padx=2)
        self.recent_var = tk.StringVar(value="โปรเจคล่าสุด / ตัวอย่าง ▾")
        self.recent_btn = ttk.Combobox(top, textvariable=self.recent_var, state="readonly", width=28)
        self.recent_btn.pack(side="left", padx=2)
        self.recent_btn.bind("<<ComboboxSelected>>", self._recent_chosen)
        ttk.Button(top, text="🔑 สิทธิ์ใช้งาน", command=self.show_license).pack(side="right", padx=2)
        self.proj_lbl = ttk.Label(top, text="ยังไม่ได้เปิดโปรเจค", style="Big.TLabel")
        self.proj_lbl.pack(side="left", padx=16)
        for text, cmd in (("💾 สำรอง", self.backup), ("📄 PDF เส้นวัด", self.export_pdf),
                          ("CSV", self.export_csv), ("📊 ส่งออก Excel", self.export_excel)):
            ttk.Button(tools, text=text, command=cmd).pack(side="right", padx=2)
        self._fill_recent()

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True)
        self.tab_take = ttk.Frame(self.nb)
        self.tab_boq = ttk.Frame(self.nb)
        self.tab_qa = ttk.Frame(self.nb)
        self.nb.add(self.tab_take, text="  ถอดแบบ (Takeoff)  ")
        self.nb.add(self.tab_boq, text="  BOQ  ")
        self.nb.add(self.tab_qa, text="  ตรวจสอบ (QA)  ")
        self.nb.bind("<<NotebookTabChanged>>", self._tab_changed)

        self.status_var = tk.StringVar(value="พร้อมใช้งาน — เริ่มจาก 'โปรเจคใหม่' หรือ 'โปรเจคล่าสุด / ตัวอย่าง'")
        ttk.Label(self.root, textvariable=self.status_var, relief="sunken", anchor="w",
                  padding=(6, 2)).pack(fill="x", side="bottom")
        self._build_takeoff()
        self._build_boq()
        self._build_qa()

    def status(self, s):
        self.status_var.set(s)

    DEMO_LABEL = "★ เปิดโปรเจคตัวอย่าง (Demo)"

    def _fill_recent(self):
        self.recent_btn["values"] = [self.DEMO_LABEL] + self.settings.get("recent", [])[:10]

    def _recent_chosen(self, e=None):
        v = self.recent_var.get()
        self.recent_var.set("โปรเจคล่าสุด / ตัวอย่าง ▾")
        self.root.focus_set()
        if v == self.DEMO_LABEL:
            self.open_demo()
        elif v:
            self.open_project(v)

    def _build_takeoff(self):
        pw = ttk.PanedWindow(self.tab_take, orient="horizontal")
        pw.pack(fill="both", expand=True)
        # left: drawings
        left = ttk.Frame(pw, padding=4)
        ttk.Label(left, text="แบบก่อสร้าง (พิมพ์ค้นหา เช่น A-102)").pack(anchor="w")
        self.dfilter = tk.StringVar()
        ttk.Entry(left, textvariable=self.dfilter).pack(fill="x")
        self.dfilter.trace_add("write", lambda *a: self.refresh_drawings())
        self.dtree = ttk.Treeview(left, show="tree", selectmode="browse")
        self.dtree.pack(fill="both", expand=True)
        self.dtree.bind("<<TreeviewSelect>>", self._drawing_selected)
        self.dtree.bind("<Double-1>", lambda e: self.edit_drawing())
        b = ttk.Frame(left)
        b.pack(fill="x", pady=4)
        ttk.Button(b, text="+ นำเข้าแบบ", command=self.import_drawings).pack(side="left")
        ttk.Button(b, text="แก้ไข", command=self.edit_drawing).pack(side="left", padx=2)
        b = ttk.Frame(left)
        b.pack(fill="x", pady=(0, 4))
        ttk.Button(b, text="▲", width=3, command=lambda: self.move_drawing(-1)).pack(side="left")
        ttk.Button(b, text="▼", width=3, command=lambda: self.move_drawing(1)).pack(side="left")
        ttk.Button(b, text="ลบ", command=self.delete_drawing).pack(side="left", padx=2)
        ttk.Button(left, text="🔍 ตั้งสเกลอัตโนมัติ (ทุกหน้า)",
                   command=self.auto_scale).pack(fill="x")
        ttk.Button(left, text="📐 ตั้งสเกลมาตรฐาน (1:100 ฯลฯ)",
                   command=self.standard_scale).pack(fill="x", pady=(2, 0))
        pw.add(left, weight=1)
        # center: viewer
        self.view = DrawingView(pw, on_done=self._measure_done, on_calib=self._calibrated,
                                on_select=self._canvas_selected, on_delete=self.delete_measurement,
                                status=self.status, on_edit=self._vertex_edited)
        self.view.on_page_change = self._goto_page
        pw.add(self.view, weight=5)
        for key, tool in (("l", "line"), ("a", "poly"), ("r", "rect"), ("c", "count"),
                          ("s", "calib"), ("space", "pan")):
            self.view.cv.bind(f"<KeyPress-{key}>", lambda e, t=tool: self.view.set_tool(t))
        # right: items + measurements
        right = ttk.PanedWindow(pw, orient="vertical")
        top = ttk.Frame(right, padding=4)
        ttk.Label(top, text="รายการถอดปริมาณ — เลือกรายการก่อนวัด").pack(anchor="w")
        self.search_var = tk.StringVar()
        se = ttk.Entry(top, textvariable=self.search_var)
        se.pack(fill="x")
        self.search_var.trace_add("write", lambda *a: self.refresh_items())
        self.itree = ttk.Treeview(top, columns=("qty", "unit"), selectmode="browse")
        self.itree.heading("#0", text="รายการ")
        self.itree.heading("qty", text="ปริมาณ")
        self.itree.heading("unit", text="หน่วย")
        self.itree.column("#0", width=210)
        self.itree.column("qty", width=80, anchor="e")
        self.itree.column("unit", width=50, anchor="center")
        self.itree.pack(fill="both", expand=True)
        self.itree.bind("<<TreeviewSelect>>", self._item_selected)
        self.itree.bind("<Double-1>", lambda e: self.edit_item())
        b = ttk.Frame(top)
        b.pack(fill="x", pady=4)
        ttk.Button(b, text="+ เพิ่ม", command=self.add_item).pack(side="left")
        ttk.Button(b, text="แก้ไข/ราคา", command=self.edit_item).pack(side="left", padx=2)
        ttk.Button(b, text="สี", command=self.item_color).pack(side="left")
        ttk.Button(b, text="ลบ", command=self.delete_item).pack(side="left", padx=2)
        right.add(top, weight=3)
        bot = ttk.Frame(right, padding=4)
        ttk.Label(bot, text="การวัดในหน้านี้").pack(anchor="w")
        self.mtree = ttk.Treeview(bot, columns=("item", "val", "qty"), show="headings",
                                  selectmode="browse", height=8)
        for c, t, w in (("item", "รายการ", 120), ("val", "ค่าที่วัด", 110), ("qty", "ปริมาณ", 70)):
            self.mtree.heading(c, text=t)
            self.mtree.column(c, width=w, anchor="w" if c == "item" else "e")
        self.mtree.pack(fill="both", expand=True)
        self.mtree.bind("<<TreeviewSelect>>", self._mlist_selected)
        self.mtree.bind("<Double-1>", lambda e: self.edit_measurement())
        b = ttk.Frame(bot)
        b.pack(fill="x", pady=4)
        ttk.Button(b, text="แก้ไข (สูง/ซ้ำ/ตัวคูณ/หัก)", command=self.edit_measurement).pack(side="left")
        ttk.Button(b, text="ย้ายไปรายการที่เลือก", command=self.reassign_measurement).pack(side="left", padx=2)
        ttk.Button(b, text="ลบ", command=lambda: self.delete_measurement(self.sel_mid)).pack(side="left")
        right.add(bot, weight=2)
        pw.add(right, weight=2)
        self._pw = pw
        self.root.after(300, self._init_sashes)

    def _init_sashes(self):
        try:
            w = self._pw.winfo_width()
            self._pw.sashpos(0, 310)
            self._pw.sashpos(1, max(600, w - 400))
        except Exception:
            pass

    def _build_boq(self):
        f = self.tab_boq
        bar = ttk.Frame(f, padding=4)
        bar.pack(fill="x")
        ttk.Button(bar, text="✓ ติ๊ก/ยกเลิก ตรวจแล้ว", command=self.toggle_verified).pack(side="left")
        ttk.Button(bar, text="แก้ไข/ใส่ราคา", command=lambda: self.edit_item(self._boq_sel())).pack(side="left", padx=4)
        self.show_all = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text="แสดงรายการที่ยังไม่มีปริมาณด้วย", variable=self.show_all,
                        command=self.refresh_boq).pack(side="left", padx=8)
        self.total_lbl = ttk.Label(bar, text="", style="Total.TLabel")
        self.total_lbl.pack(side="right")
        pw = ttk.PanedWindow(f, orient="vertical")
        pw.pack(fill="both", expand=True)
        cols = [("code", "รหัส", 55, "w"), ("cat", "หมวดงาน", 110, "w"), ("name", "รายการ", 280, "w"),
                ("qty", "ปริมาณ", 90, "e"), ("unit", "หน่วย", 55, "center"),
                ("mat", "ค่าวัสดุ/หน่วย", 95, "e"), ("matt", "ค่าวัสดุรวม", 105, "e"),
                ("lab", "ค่าแรง/หน่วย", 95, "e"), ("labt", "ค่าแรงรวม", 105, "e"),
                ("tot", "รวมเงิน", 115, "e"), ("ver", "ตรวจ", 45, "center"),
                ("ref", "ที่มา (แบบ/หน้า)", 200, "w")]
        fr = ttk.Frame(pw)
        self.btree = ttk.Treeview(fr, columns=[c[0] for c in cols], show="headings")
        for c, t, w, a in cols:
            self.btree.heading(c, text=t)
            self.btree.column(c, width=w, anchor=a, stretch=c in ("name", "ref"))
        sb = ttk.Scrollbar(fr, orient="vertical", command=self.btree.yview)
        self.btree.configure(yscrollcommand=sb.set)
        self.btree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.btree.tag_configure("unver", background="#FFF8E1")
        self.btree.bind("<<TreeviewSelect>>", lambda e: self._show_trace())
        self.btree.bind("<Double-1>", lambda e: self.edit_item(self._boq_sel()))
        pw.add(fr, weight=3)
        fr2 = ttk.Frame(pw, padding=(0, 4))
        ttk.Label(fr2, text="ที่มาของปริมาณ — ดับเบิลคลิกเพื่อไปดูจุดที่วัดบนแบบ").pack(anchor="w")
        tcols = [("dwg", "แบบ", 130, "w"), ("pg", "หน้า", 45, "center"), ("kind", "วิธีวัด", 140, "w"),
                 ("f", "สูตร / การแทนค่า", 420, "w"), ("q", "ปริมาณ", 90, "e"), ("n", "หมายเหตุ", 200, "w")]
        self.ttree = ttk.Treeview(fr2, columns=[c[0] for c in tcols], show="headings", height=7)
        for c, t, w, a in tcols:
            self.ttree.heading(c, text=t)
            self.ttree.column(c, width=w, anchor=a, stretch=c in ("f", "n"))
        self.ttree.pack(fill="both", expand=True)
        self.ttree.bind("<Double-1>", lambda e: self._jump_trace())
        pw.add(fr2, weight=2)

    def _build_qa(self):
        f = self.tab_qa
        bar = ttk.Frame(f, padding=4)
        bar.pack(fill="x")
        ttk.Button(bar, text="ตรวจสอบอีกครั้ง", command=self.refresh_qa).pack(side="left")
        self.qa_lbl = ttk.Label(bar, text="")
        self.qa_lbl.pack(side="left", padx=10)
        self.qtree = ttk.Treeview(f, columns=("lv", "where", "msg"), show="headings")
        for c, t, w in (("lv", "ระดับ", 80), ("where", "ตำแหน่ง/รายการ", 300), ("msg", "รายละเอียด", 700)):
            self.qtree.heading(c, text=t)
            self.qtree.column(c, width=w, stretch=c == "msg")
        self.qtree.tag_configure("ผิดพลาด", background="#FDE2E2")
        self.qtree.tag_configure("เตือน", background="#FFF4D6")
        self.qtree.pack(fill="both", expand=True, padx=4, pady=4)

    # ---------------- project ----------------
    def _need(self):
        if not self.proj:
            messagebox.showinfo("ยังไม่มีโปรเจค", "กรุณาสร้างหรือเปิดโปรเจคก่อน")
            return False
        return True

    @safe
    def new_project(self):
        r = dialogs.project_form(self.root)
        if not r:
            return
        base = Path(self.settings.get("project_dir", Path.home() / "Documents" / "BOQ Projects"))
        base.mkdir(parents=True, exist_ok=True)
        parent = filedialog.askdirectory(title="เลือกโฟลเดอร์ที่จะเก็บโปรเจค", initialdir=base)
        if not parent:
            return
        self.settings["project_dir"] = parent
        name = "".join(c if c.isalnum() or c in " -_" else "_" for c in r["name"]).strip()
        folder = Path(parent) / name
        p = Project.create(folder, r["name"], r["client"], r["address"], r["number"])
        p.set_info(notes=r["notes"])
        p.close()
        self.open_project(folder)

    def ask_open(self):
        d = filedialog.askdirectory(title="เลือกโฟลเดอร์โปรเจค (ที่มีไฟล์ project.db)",
                                    initialdir=self.settings.get("project_dir"))
        if d:
            self.open_project(d)

    @safe
    def open_demo(self):
        base = Path(self.settings.get("project_dir", Path.home() / "Documents" / "BOQ Projects"))
        base.mkdir(parents=True, exist_ok=True)
        p = create_demo(base)
        folder = p.folder
        p.close()
        self.open_project(folder)

    @safe
    def open_project(self, folder):
        folder = Path(folder)
        if not (folder / Project.DB).exists():
            messagebox.showerror("เปิดไม่ได้", f"ไม่พบ project.db ใน\n{folder}")
            return
        self.close_project()
        self.proj = Project(folder)
        rec = [str(folder)] + [p for p in self.settings.get("recent", []) if p != str(folder)]
        self.settings["recent"] = rec[:10]
        self._save_settings()
        self._fill_recent()
        self.proj_lbl.config(text=self.proj.info().get("name", folder.name))
        log.info("open project %s", folder)
        for d in self.proj.drawings():
            pages = self.proj.pages(d["id"])
            if pages and not any(p["title"] for p in pages):
                def prog(i, n):
                    self.status(f"อ่านเลขที่/ชื่อแผ่นจากหัวกระดาษ {i}/{n} ...")
                    self.root.update()
                try:
                    self.proj.fill_page_titles(d["id"], prog)
                except Exception:
                    log.exception("fill titles")
        self.refresh_all()
        first = self.dtree.get_children()
        if first:
            kids = self.dtree.get_children(first[0])
            self.dtree.selection_set(kids[0] if kids else first[0])
        items = [i for c in self.itree.get_children() for i in self.itree.get_children(c)]
        if items:
            self.itree.selection_set(items[0])
            self.itree.see(items[0])
        self.status(f"เปิดโปรเจค {folder}  (บันทึกอัตโนมัติทุกครั้งที่แก้ไข)")

    def close_project(self):
        for d in self.docs.values():
            d.close()
        self.docs = {}
        if self.proj:
            self.proj.close()
        self.proj = None
        self.cur_did = self.cur_pid = self.cur_item = self.sel_mid = None
        self.view.clear()

    @safe
    def edit_project(self):
        if not self._need():
            return
        r = dialogs.project_form(self.root, self.proj.info(), new=False)
        if r:
            self.proj.set_info(**r)
            self.proj_lbl.config(text=r["name"])

    @safe
    def backup(self):
        if self._need():
            p = self.proj.backup()
            self.status(f"สำรองข้อมูลแล้ว: {p}")

    def quit(self):
        self._save_settings()
        self.close_project()
        self.root.destroy()

    # ---------------- refresh ----------------
    def refresh_all(self):
        self.refresh_drawings()
        self.refresh_items()
        self.refresh_page()

    def refresh_drawings(self):
        sel = self.dtree.selection()
        self.dtree.delete(*self.dtree.get_children())
        if not self.proj:
            return
        q = self.dfilter.get().strip().lower()
        counts = dict(self.proj.con.execute(
            "SELECT page_id, COUNT(*) FROM measurements GROUP BY page_id").fetchall())
        for d in self.proj.drawings():
            name = " ".join(x for x in (d["number"], d["title"]) if x) or d["file_name"]
            node = self.dtree.insert("", "end", iid=f"d{d['id']}", open=True,
                                     text=f"[{d['discipline']}] {name}" +
                                          (f"  rev.{d['revision']}" if d["revision"] else ""))
            for p in self.proj.pages(d["id"]):
                label = f"{p['page_no']}. {p['title'] or 'หน้า ' + str(p['page_no'])}"
                if q and q not in label.lower():
                    continue
                n = counts.get(p["id"], 0)
                sc = f"✓ {p['scale_label'].split(' ')[0]}" if p["mm_per_pt"] else "⚠ ไม่มีสเกล"
                self.dtree.insert(node, "end", iid=f"p{p['id']}",
                                  text=f"{label}   {sc}" + (f"   ({n} วัด)" if n else ""))
        for s in sel:
            if self.dtree.exists(s):
                self.dtree.selection_set(s)

    def refresh_items(self):
        sel = self.cur_item
        self.itree.delete(*self.itree.get_children())
        if not self.proj:
            return
        self.rows = compute(self.proj)
        q = self.search_var.get().strip().lower()
        cats = {}
        for r in self.rows:
            it = r.item
            if q and q not in f"{it['code']} {it['name']} {it['category']}".lower():
                continue
            c = it["category"]
            if c not in cats:
                cats[c] = self.itree.insert("", "end", iid=f"c{len(cats)}", text=c, open=True)
            tag = f"col{it['id']}"
            self.itree.tag_configure(tag, foreground=it["color"])
            self.itree.insert(cats[c], "end", iid=f"i{it['id']}", tags=(tag,),
                              text=f"{it['code']} {it['name']}" + (" ✓" if it["verified"] else ""),
                              values=(f"{r.qty:,.2f}" if r.lines else "", it["unit"]))
        if sel and self.itree.exists(f"i{sel}"):
            self.itree.selection_set(f"i{sel}")

    def _page_doc(self):
        if self.cur_did not in self.docs:
            import fitz
            self.docs[self.cur_did] = fitz.open(self.proj.drawing_path(self.cur_did))
        return self.docs[self.cur_did]

    def refresh_page(self, keep_view=True):
        self.mtree.delete(*self.mtree.get_children())
        if not (self.proj and self.cur_pid):
            self.view.set_overlays([])
            return
        pg = self.proj.page(self.cur_pid)
        if self.view.doc is not self._page_doc() or self.view.page_no != pg["page_no"]:
            keep_view = False
        self.view.mm_per_pt = pg["mm_per_pt"]
        if not keep_view:
            self.view.load(self._page_doc(), pg["page_no"], pg["mm_per_pt"])
        items = {r.item["id"]: r for r in self.rows}
        ov = []
        for m in self.proj.measurements(page_id=self.cur_pid):
            r = items.get(m["item_id"])
            if not r:
                continue
            it = r.item
            ln = next((x for x in r.lines if x.measurement_id == m["id"]), None)
            pts = json.loads(m["points"])
            ov.append(dict(id=m["id"], kind=m["kind"], pts=pts, color=it["color"],
                           sign=m["sign"], label=it["code"] if it["id"] == self.cur_item else ""))
            if ln:
                if m["kind"] == "count":
                    val = f"{ln.N:g} จุด"
                elif m["kind"] == "line":
                    val = f"{ln.L:,.2f} ม."
                else:
                    val = f"{ln.A:,.2f} ตร.ม."
                src = {"ai": "AI ", "tag": "ป้าย ", "ai-edited": "AI✎ "}.get(
                    m["source"] if "source" in m.keys() else "", "")
                self.mtree.insert("", "end", iid=f"m{m['id']}",
                                  values=(f"{'(−) ' if m['sign'] == -1 else ''}{src}{it['code']} {m['note'] or it['name']}",
                                          val, f"{ln.qty:,.2f}"))
        self.view.set_overlays(ov, self.sel_mid)
        if self.sel_mid and self.mtree.exists(f"m{self.sel_mid}"):
            self.mtree.selection_set(f"m{self.sel_mid}")
        if pg["mm_per_pt"] and not keep_view:
            self.status(f"หน้า {pg['page_no']} {pg['title'] or ''} • สเกล {pg['scale_label']}")
        if not pg["mm_per_pt"]:
            hint = f"(พบในแบบ {pg['scale_label']}) " if pg["scale_label"] else ""
            self.status(f"⚠ หน้านี้ยังไม่ได้ตั้งสเกล {hint}— กด 'ตั้งสเกล' แล้วคลิก 2 จุดบนเส้นบอกระยะ "
                        f"หรือกด 'ตั้งสเกลมาตรฐาน'")

    def _after_change(self):
        self.refresh_items()
        self.refresh_drawings()
        self.refresh_page()

    # ---------------- drawings ----------------
    def _drawing_selected(self, e=None):
        s = self.dtree.selection()
        if not s:
            return
        iid = s[0]
        if iid.startswith("d"):
            kids = self.dtree.get_children(iid)
            if kids:
                self.dtree.selection_set(kids[0])
            return
        pid = int(iid[1:])
        if pid == self.cur_pid:
            return
        self.cur_pid = pid
        self.cur_did = self.proj.page(pid)["drawing_id"]
        self.sel_mid = None
        self.refresh_page(keep_view=False)

    def _goto_page(self, n):
        for p in self.proj.pages(self.cur_did):
            if p["page_no"] == n:
                self.dtree.selection_set(f"p{p['id']}")
                self.dtree.see(f"p{p['id']}")

    @safe
    def import_drawings(self):
        if not self._need():
            return
        files = filedialog.askopenfilenames(
            title="เลือกไฟล์แบบ", filetypes=[("แบบก่อสร้าง", "*.pdf *.jpg *.jpeg *.png"),
                                           ("ทุกไฟล์", "*.*")])
        if not files:
            return
        ok, bad = 0, []
        for f in files:
            self.status(f"กำลังนำเข้า {Path(f).name} ...")
            self.root.update_idletasks()
            try:
                name = Path(f).name

                def prog(i, n, name=name):
                    self.status(f"กำลังนำเข้า {name} — อ่านหัวกระดาษหน้า {i}/{n} ...")
                    self.root.update()
                self.proj.import_drawing(f, progress=prog)
                ok += 1
            except Exception as e:
                log.warning("import failed %s: %s", f, e)
                bad.append(f"{Path(f).name}: {e}")
        self.refresh_drawings()
        self.status(f"นำเข้าแบบสำเร็จ {ok} ไฟล์ — ต่อไปกด '🔍 ตั้งสเกลอัตโนมัติ' (ไฟล์ต้นฉบับไม่ถูกแก้ไข)")
        if bad:
            messagebox.showwarning("นำเข้าไม่ได้บางไฟล์", "\n".join(bad))

    def _sel_drawing(self):
        s = self.dtree.selection()
        if not s:
            return None
        iid = s[0]
        return int(iid[1:]) if iid.startswith("d") else self.proj.page(int(iid[1:]))["drawing_id"]

    @safe
    def edit_drawing(self):
        did = self._sel_drawing()
        if did:
            r = dialogs.drawing_form(self.root, self.proj.drawing(did))
            if r:
                self.proj.update_drawing(did, **r)
                self.refresh_all()

    @safe
    def move_drawing(self, delta):
        did = self._sel_drawing()
        if did:
            self.proj.move_drawing(did, delta)
            self.refresh_drawings()

    @safe
    def delete_drawing(self):
        did = self._sel_drawing()
        if not did:
            return
        n = sum(len(self.proj.measurements(page_id=p["id"])) for p in self.proj.pages(did))
        if not messagebox.askyesno("ลบแบบ", f"ลบแบบนี้ออกจากโปรเจค?\n(การวัดบนแบบนี้ {n} รายการจะถูกลบด้วย)"):
            return
        if did in self.docs:
            self.docs.pop(did).close()
        if did == self.cur_did:
            self.cur_did = self.cur_pid = None
            self.view.clear()
        self.proj.delete_drawing(did)
        self._after_change()

    # ---------------- scale ----------------
    def _apply_scale(self, mm_per_pt, label, source, all_pages):
        pids = [p["id"] for p in self.proj.pages(self.cur_did)] if all_pages else [self.cur_pid]
        for pid in pids:
            self.proj.set_scale(pid, mm_per_pt, label, source)
        self._after_change()
        self.status(f"ตั้งสเกล {label} แล้ว — แนะนำ: วัดระยะที่รู้ค่าอีกเส้นเพื่อตรวจสอบ")

    @safe
    def _calibrated(self, a, b):
        pg = self.proj.page(self.cur_pid)
        many = len(self.proj.pages(self.cur_did)) > 1
        fields = [("mm", "ระยะจริงของเส้นที่คลิก (มม.)", "number", None, None)]
        if many:
            fields.append(("all", "ใช้กับทุกหน้าในแบบนี้", "check", False, None))
        r = dialogs.ask(self.root, "ตั้งสเกลจากระยะจริง", fields,
            note=f"ระยะบนแบบ = {dist(a, b):.1f} pt\nเช่น เส้นบอกระยะเขียน 3000 ให้กรอก 3000"
                 + (f"\nแบบนี้เขียนสเกลไว้: {pg['scale_label']}" if pg["scale_label"] else ""),
            validate=lambda o: None if (o["mm"] or 0) > 0 else "กรอกระยะจริงเป็นตัวเลขมากกว่า 0")
        if r:
            k = calibrate(a, b, r["mm"])
            ratio = k / standard_scale_mm_per_pt(1)
            self._apply_scale(k, f"เทียบระยะ ≈1:{ratio:,.0f}", "manual", r.get("all", False))
            self.view.set_tool("pan")

    @safe
    def auto_scale(self):
        """Background: read title-block scale + check it against dimension lines, per page."""
        if not self._need():
            return
        todo = [(d["id"], p["id"], p["page_no"], p["title"]) for d in self.proj.drawings()
                for p in self.proj.pages(d["id"]) if not p["mm_per_pt"]]
        if not todo:
            messagebox.showinfo("ตั้งสเกลอัตโนมัติ", "ทุกหน้ามีสเกลแล้ว")
            return
        if getattr(self, "_auto_running", False):
            return
        self._auto_running = True
        import os
        from concurrent.futures import ProcessPoolExecutor
        from ..core.scale import auto_scale_task
        paths = {did: str(self.proj.drawing_path(did)) for did, *_ in todo}
        ex = ProcessPoolExecutor(max_workers=max(1, min(4, (os.cpu_count() or 2) - 1)))
        futs = [(ex.submit(auto_scale_task, paths[did], no), pid, no, title)
                for did, pid, no, title in todo]
        state = {"i": 0}
        results = []

        def poll():
            try:
                while state["i"] < len(futs) and futs[state["i"]][0].done():
                    f, pid, no, title = futs[state["i"]]
                    state["i"] += 1
                    try:
                        mm, label, note, est = f.result()
                    except Exception as e:
                        mm, label, note, est = None, "", f"อ่านหน้านี้ไม่ได้: {e}", None
                    if mm:
                        self.proj.set_scale(pid, mm, label, "auto")
                    results.append((pid, no, title, mm, label, note, est))
                    self.status(f"ตั้งสเกลอัตโนมัติ... {state['i']}/{len(futs)} หน้า (ใช้งานอย่างอื่นต่อได้)")
                if state["i"] >= len(futs):
                    ex.shutdown(wait=False)
                    self._auto_running = False
                    self._after_change()
                    self._auto_report(results)
                    return
            except Exception:
                log.exception("auto scale")
                self._auto_running = False
                ex.shutdown(wait=False, cancel_futures=True)
                return
            self.root.after(300, poll)

        poll()

    def _auto_report(self, results):
        ok = [r for r in results if r[3]]
        conflict = [r for r in results if not r[3] and r[6]]
        w = tk.Toplevel(self.root)
        w.title("ผลตั้งสเกลอัตโนมัติ")
        w.geometry("900x500")
        ttk.Label(w, padding=8, text=f"ตั้งได้ {len(ok)} หน้า (สเกลในหัวกระดาษตรงกับเส้นบอกระยะ)   •   "
                  f"ต้องดูเอง {len(results) - len(ok)} หน้า").pack(anchor="w")
        t = ttk.Treeview(w, columns=("pg", "title", "res"), show="headings")
        for c, h, wd in (("pg", "หน้า", 50), ("title", "แผ่น", 260), ("res", "ผล", 560)):
            t.heading(c, text=h)
            t.column(c, width=wd, stretch=c == "res")
        t.tag_configure("bad", background="#FDE2E2")
        t.tag_configure("warn", background="#FFF4D6")
        for pid, no, title, mm, label, note, est in sorted(results, key=lambda r: (2 if r[3] else (0 if r[6] else 1), r[1])):
            t.insert("", "end", values=(no, title, label if mm else note),
                     tags=() if mm else ("bad" if est else "warn",))
        t.pack(fill="both", expand=True, padx=8)
        b = ttk.Frame(w, padding=8)
        b.pack(fill="x")
        if conflict:
            def use_dims():
                for pid, no, title, mm, label, note, est in conflict:
                    self.proj.set_scale(pid, est["mm_per_pt"],
                                        f"1:{est['ratio']:g} (ตามเส้นบอกระยะ — หัวกระดาษเขียนต่าง)",
                                        "auto-dims")
                self._after_change()
                w.destroy()
            ttk.Button(b, text=f"ใช้สเกลตามเส้นบอกระยะ กับ {len(conflict)} หน้าที่ขัดแย้ง (แถวสีแดง)",
                       command=use_dims).pack(side="left")
        ttk.Button(b, text="ปิด", command=w.destroy).pack(side="right")

    @safe
    def standard_scale(self):
        if not (self.proj and self.cur_pid):
            messagebox.showinfo("ตั้งสเกล", "เลือกหน้าแบบก่อน")
            return
        pg = self.proj.page(self.cur_pid)
        guess = next((s for s in STD_SCALES if pg["scale_label"].startswith(s + " ")), "1:100")
        r = dialogs.ask(self.root, "ตั้งสเกลมาตรฐาน", [
            ("s", "สเกลของแบบ", "combo", guess, STD_SCALES),
            ("all", "ใช้กับทุกหน้าในแบบนี้", "check", True, None)],
            note="ใช้ได้เฉพาะไฟล์ PDF ที่ export จาก CAD ขนาดกระดาษจริง (ไม่ใช่ภาพสแกน/ภาพถ่าย)\n"
                 "ถ้าไม่แน่ใจ ให้ใช้ปุ่ม 'ตั้งสเกล' แล้วคลิกเทียบเส้นบอกระยะ จะแม่นกว่า",
            validate=lambda o: None if o["s"].replace(" ", "").startswith("1:") and
            o["s"].split(":")[1].replace(",", "").strip().replace(".", "", 1).isdigit()
            else "รูปแบบสเกลต้องเป็น 1:N เช่น 1:100")
        if r:
            n = float(r["s"].split(":")[1].replace(",", ""))
            self._apply_scale(standard_scale_mm_per_pt(n), f"1:{n:g}", "standard", r["all"])

    # ---------------- items ----------------
    def _item_selected(self, e=None):
        s = self.itree.selection()
        if not s or not s[0].startswith("i"):
            return
        iid = int(s[0][1:])
        if iid == self.cur_item:
            return
        self.cur_item = iid
        it = self.proj.item(iid)
        self.view.cur_color = it["color"]
        if self.view.tool.get() not in ("calib",) and self.view.page:
            self.view.set_tool(MODE_TOOL.get(it["mode"], "line"))
        self.refresh_page()
        self.status(f"รายการที่เลือก: {it['code']} {it['name']}  •  สูตร {it['formula']}  •  "
                    f"H={it['H']:g} T={it['T']:g} W={it['W']:g} F={it['F']:g}")

    @safe
    def add_item(self):
        if not self._need():
            return
        r = dialogs.item_form(self.root, self.proj.categories())
        if r:
            manual = r.pop("manual_qty")
            iid = self.proj.add_item(**r)
            self.proj.update_item(iid, manual_qty=manual)
            self.cur_item = iid
            self.refresh_items()

    @safe
    def edit_item(self, iid=None):
        iid = iid or self.cur_item
        if not (self.proj and iid):
            return
        r = dialogs.item_form(self.root, self.proj.categories(), self.proj.item(iid))
        if r:
            self.proj.update_item(iid, **r)
            self._after_change()
            self.refresh_boq()

    @safe
    def item_color(self):
        if self.cur_item:
            c = dialogs.pick_color(self.root, self.proj.item(self.cur_item)["color"])
            if c:
                self.proj.update_item(self.cur_item, color=c)
                self.view.cur_color = c
                self._after_change()

    @safe
    def delete_item(self):
        if not self.cur_item:
            return
        it = self.proj.item(self.cur_item)
        n = len(self.proj.measurements(item_id=self.cur_item))
        if messagebox.askyesno("ลบรายการ", f"ลบ '{it['name']}'?\n(การวัด {n} รายการของรายการนี้จะถูกลบด้วย)"):
            self.proj.delete_item(self.cur_item)
            self.cur_item = None
            self._after_change()

    # ---------------- measurements ----------------
    @safe
    def _measure_done(self, kind, pts, sign):
        if not (self.proj and self.cur_pid):
            return
        if not self.cur_item:
            messagebox.showinfo("เลือกรายการก่อน", "กรุณาเลือกรายการถอดปริมาณทางขวาก่อนวัด")
            return
        mid = self.proj.add_measurement(self.cur_item, self.cur_pid, kind, pts, sign)
        self.sel_mid = mid
        self._after_change()
        r = next(x for x in self.rows if x.item["id"] == self.cur_item)
        ln = next((x for x in r.lines if x.measurement_id == mid), None)
        if ln:
            self.status(f"บันทึกแล้ว: {r.item['code']} {r.item['name']} = {ln.qty:,.3f} {r.item['unit']}  "
                        f"({ln.formula_text})   รวมรายการ {r.qty:,.2f} {r.item['unit']}")

    def _canvas_selected(self, mid):
        self.sel_mid = mid
        if mid and self.mtree.exists(f"m{mid}"):
            self.mtree.selection_set(f"m{mid}")
            self.mtree.see(f"m{mid}")
            m = self.proj.measurement(mid)
            if self.itree.exists(f"i{m['item_id']}"):
                self.itree.see(f"i{m['item_id']}")

    def _mlist_selected(self, e=None):
        s = self.mtree.selection()
        if not s:
            return
        mid = int(s[0][1:])
        if mid != self.sel_mid:
            self.sel_mid = mid
            m = self.proj.measurement(mid)
            self.view.selected = mid
            self.view.show(json.loads(m["points"]))

    @safe
    def _vertex_edited(self, mid, pts):
        m = self.proj.measurement(mid)
        src = m["source"] if "source" in m.keys() else "manual"
        self.proj.update_measurement(mid, points=pts,
                                     **({"source": "ai-edited"} if src == "ai" else {}))
        self.sel_mid = mid
        self._after_change()

    @safe
    def ai_takeoff(self):
        if not self._need():
            return
        from .ai_dialog import AIDialog
        AIDialog(self)

    @safe
    def edit_measurement(self):
        if not self.sel_mid:
            return
        m = self.proj.measurement(self.sel_mid)
        r = dialogs.measurement_form(self.root, m, self.proj.item(m["item_id"]))
        if r:
            self.proj.update_measurement(self.sel_mid, H=r["H"], T=r["T"], W=r["W"],
                                         repeat=r["repeat"] or 1, sign=-1 if r["deduct"] else 1,
                                         note=r["note"])
            self._after_change()

    @safe
    def reassign_measurement(self):
        if self.sel_mid and self.cur_item:
            self.proj.update_measurement(self.sel_mid, item_id=self.cur_item)
            self._after_change()

    @safe
    def delete_measurement(self, mid):
        if not mid:
            return
        self.proj.delete_measurement(mid)
        self.sel_mid = None
        self._after_change()
        self.status("ลบการวัดแล้ว")

    # ---------------- BOQ ----------------
    def _tab_changed(self, e=None):
        i = self.nb.index("current")
        if i == 1:
            self.refresh_boq()
        elif i == 2:
            self.refresh_qa()

    def refresh_boq(self):
        sel = self.btree.selection()
        self.btree.delete(*self.btree.get_children())
        self.ttree.delete(*self.ttree.get_children())
        if not self.proj:
            return
        self.rows = compute(self.proj)
        shown = [r for r in self.rows if r.lines or self.show_all.get()]
        for r in shown:
            it = r.item
            self.btree.insert("", "end", iid=f"b{it['id']}", tags=() if it["verified"] else ("unver",),
                              values=(it["code"], it["category"], it["name"], f"{r.qty:,.2f}",
                                      it["unit"], f"{it['mat_rate']:,.2f}", f"{r.mat_total:,.2f}",
                                      f"{it['lab_rate']:,.2f}", f"{r.lab_total:,.2f}",
                                      f"{r.total:,.2f}", "✓" if it["verified"] else "", r.refs))
        t = totals(shown)
        nv = sum(1 for r in shown if r.lines and not r.item["verified"])
        self.total_lbl.config(text=f"ค่าวัสดุ {t['mat']:,.2f}   ค่าแรง {t['lab']:,.2f}   "
                                   f"รวม {t['total']:,.2f} บาท" + (f"   •  ยังไม่ตรวจ {nv} รายการ" if nv else ""))
        for s in sel:
            if self.btree.exists(s):
                self.btree.selection_set(s)

    def _boq_sel(self):
        s = self.btree.selection()
        return int(s[0][1:]) if s else None

    def _show_trace(self):
        self.ttree.delete(*self.ttree.get_children())
        iid = self._boq_sel()
        r = next((x for x in self.rows if x.item["id"] == iid), None)
        if not r:
            return
        for k, ln in enumerate(r.lines):
            self.ttree.insert("", "end", iid=f"t{k}_{ln.measurement_id or 0}",
                              values=(ln.drawing, ln.page_no or "", KIND_LABEL.get(ln.kind, ln.kind),
                                      ln.formula_text, f"{ln.qty:,.3f}",
                                      "; ".join(x for x in (ln.note, ln.error) if x)))
        w = r.item["waste"]
        self.ttree.insert("", "end", values=("", "", "รวม", f"สุทธิ {r.net_qty:,.3f}" +
                                              (f" + เผื่อ {w:g}%" if w else ""),
                                              f"{r.qty:,.2f}", r.item["unit"]))

    @safe
    def _jump_trace(self):
        s = self.ttree.selection()
        if not s or not s[0].startswith("t"):
            return
        mid = int(s[0].split("_")[1])
        if not mid:
            return
        m = self.proj.measurement(mid)
        self.nb.select(0)
        self.cur_item = None
        self.itree.selection_set(f"i{m['item_id']}")
        self.itree.see(f"i{m['item_id']}")
        self.dtree.selection_set(f"p{m['page_id']}")
        self.dtree.see(f"p{m['page_id']}")
        self.root.update_idletasks()
        self.sel_mid = mid
        self.view.set_tool("pan")
        self.refresh_page()
        self.root.after(150, lambda: self.view.show(json.loads(m["points"])))

    @safe
    def toggle_verified(self):
        iid = self._boq_sel()
        if iid:
            it = self.proj.item(iid)
            self.proj.update_item(iid, verified=0 if it["verified"] else 1)
            self.proj.audit("verify", f"{it['code']} -> {0 if it['verified'] else 1}")
            self.refresh_boq()
            self.refresh_items()

    # ---------------- QA ----------------
    def refresh_qa(self):
        self.qtree.delete(*self.qtree.get_children())
        if not self.proj:
            return
        issues = run_checks(self.proj)
        for lv, where, msg in issues:
            self.qtree.insert("", "end", values=(lv, where, msg), tags=(lv,))
        ne = sum(1 for i in issues if i[0] == "ผิดพลาด")
        nw = sum(1 for i in issues if i[0] == "เตือน")
        self.qa_lbl.config(text=f"ผิดพลาด {ne}  •  เตือน {nw}  •  ข้อมูล {len(issues) - ne - nw}"
                           if issues else "✓ ไม่พบปัญหา")

    # ---------------- export ----------------
    def _export_path(self, ext, label):
        name = "".join(c if c.isalnum() or c in "-_" else "_" for c in self.proj.info().get("name", "BOQ"))
        return filedialog.asksaveasfilename(
            title=label, initialdir=self.proj.folder / "exports", defaultextension=ext,
            initialfile=f"BOQ_{name}_{time.strftime('%Y%m%d')}{ext}", filetypes=[(label, f"*{ext}")])

    @safe
    def audit_contractor_boq(self):
        """ตรวจ BOQ/ใบเสนอราคาผู้รับเหมาแบบคิดย้อน — works with or without an open project."""
        from ..core import audit
        files = filedialog.askopenfilenames(
            title="เลือกไฟล์ BOQ / ใบเสนอราคาผู้รับเหมา (Excel) — เลือกได้หลายไฟล์เพื่อหางานซ้ำ",
            filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not files:
            return
        self.status("กำลังตรวจ BOQ ผู้รับเหมา ...")
        self.root.update_idletasks()
        res = audit.run_audit(list(files))
        if not res["rows"]:
            messagebox.showwarning("ตรวจ BOQ", "อ่านรายการไม่ได้ — ไม่พบแถวหัวตาราง (รายการ / จำนวน / หน่วย)")
            return
        ours = audit.match_project(res, self.proj) if self.proj else {}
        base = (self.proj.folder / "exports") if self.proj else Path(files[0]).parent
        base.mkdir(parents=True, exist_ok=True)
        out = filedialog.asksaveasfilename(
            title="บันทึกผลตรวจ", initialdir=base, defaultextension=".xlsx",
            initialfile=f"ตรวจ BOQ ผู้รับเหมา_{Path(files[0]).stem[:40]}_{time.strftime('%y%m%d')}.xlsx",
            filetypes=[("Excel", "*.xlsx")])
        if not out:
            return
        audit.export_audit(res, out, ours)
        n_err = sum(1 for r in res["rows"] if any(f[0] == audit.ERR for f in r.flags))
        n_warn = sum(1 for r in res["rows"] if any(f[0] == audit.WARN for f in r.flags))
        self.status(f"ตรวจแล้ว {len(res['rows'])} แถว: สงสัยมาก {n_err} · สงสัย {n_warn} · "
                    f"Lot {len(res['lots'])} · อาจซ้ำ {len(res['dups'])} กลุ่ม → {out}")
        open_file(out)

    def _ensure_scanned(self, files):
        """Scanned PDFs among files are read by AI once (cached). False = user cancelled / no key."""
        import threading
        from ..core import pdfscan, ai
        todo = [f for f in files if str(f).lower().endswith(".pdf") and pdfscan.is_scanned(f)
                and not pdfscan.load_cache(f)]
        if not todo:
            return True
        settings = dict(self.settings)
        names = "\n".join("  " + Path(f).name for f in todo)
        pages = {f: pdfscan.render_scanned(f) for f in todo}
        n = sum(len(v) for v in pages.values())
        if not messagebox.askyesno("PDF ภาพสแกน", f"ไฟล์นี้เป็นภาพสแกน {n} หน้า:\n{names}\n\n"
                                   f"ให้ AI อ่านตารางไหม (ประมาณ {max(1, round(n * 0.7))} นาที · ต้องต่ออินเทอร์เน็ต · "
                                   "อ่านครั้งเดียว ครั้งต่อไปใช้ผลเดิม)\n\n"
                                   "AI แค่คัดลอกตัวเลขในใบ โปรแกรมตรวจเลขให้อีกชั้น แต่ต้องเทียบกับใบจริงก่อนสรุปทุกครั้ง"):
            return False
        st = {"done": 0, "err": None, "end": False, "res": {f: [] for f in todo}}

        def work():
            try:
                for f, pp in pages.items():
                    for no, png in pp:
                        st["res"][f].append(pdfscan.read_page(settings, no, png))
                        st["done"] += 1
            except Exception as e:  # noqa: BLE001
                st["err"] = e
            st["end"] = True
        win = tk.Toplevel(self.root)
        win.title("AI กำลังอ่าน PDF")
        win.transient(self.root)
        lab = ttk.Label(win, text="", padding=20, width=50)
        lab.pack()
        win.protocol("WM_DELETE_WINDOW", lambda: None)
        threading.Thread(target=work, daemon=True).start()

        def poll():
            lab.config(text=f"AI กำลังอ่านหน้า {min(st['done'] + 1, n)} / {n} ...")
            if st["end"]:
                win.destroy()
            else:
                win.after(500, poll)
        poll()
        self.root.wait_window(win)
        if st["err"]:
            raise st["err"]
        for f in todo:
            pdfscan.save_cache(f, st["res"][f], settings.get("ai_model", ai.MODELS[0]) if settings.get("api_key") else ai.SERVICE_MODEL)
        log.info("AI read %d scanned pages", n)
        return True

    @safe
    def compare_quotes(self):
        """เทียบใบเสนอราคาผู้รับเหมาใหม่กับ BOQ เดิม — works with or without an open project."""
        from ..core import compare
        files = filedialog.askopenfilenames(
            title="เลือกใบเสนอราคาผู้รับเหมาใหม่ (Excel หรือ PDF) — เลือกได้หลายไฟล์",
            filetypes=[("Excel / PDF", "*.xlsx *.xlsm *.pdf"), ("Excel", "*.xlsx *.xlsm"), ("PDF", "*.pdf")])
        if not files:
            return
        own = "ไม่มี — ในใบเสนอราคามีช่อง มูลค่า BOQ อยู่แล้ว"
        other = "มี — เลือกไฟล์ BOQ เดิม / BOQ ที่ส่งไปขอราคา"
        mults = ["1 (ไม่คูณ)", "1.07 (VAT 7%)", "1.10 (OH 10%)", "1.15 (OH 15%)",
                 "1.177 (OH 10% + VAT)", "1.2305 (OH 15% + VAT)"]
        o = dialogs.ask(self.root, "เทียบใบเสนอราคาใหม่ กับ BOQ เดิม", [
            ("orig", "BOQ เดิมแยกเป็นอีกไฟล์ไหม", "readonly", own, [own, other]),
            ("ref_mult", "ตัวคูณราคาเดิม (เงินที่จ่ายจริงของสัญญาเดิม)", "combo", mults[3], mults),
            ("new_mult", "ตัวคูณราคาใหม่", "combo", mults[0], mults),
            ("mode", "แจ้งรายการไหน (เมื่อมี BOQ เดิม)", "readonly", OVER_ONLY, [OVER_ONLY, ALL_ISSUES]),
        ], note="ตัวคูณใช้แปลงเป็นเงินที่จ่ายจริง เช่น สัญญาเดิมราคาก่อน OH ให้เลือก 1.15 · "
                "ใบใหม่ที่ราคารวม OH และ VAT แล้วให้เลือก 1 (ไม่คูณ) · พิมพ์ตัวเลขเองได้")
        if not o:
            return

        def num(t):
            try:
                return float(str(t).split()[0].replace(",", ""))
            except (ValueError, IndexError):
                return 1.0
        originals = []
        if o["orig"] == other:
            originals = list(filedialog.askopenfilenames(
                title="เลือกไฟล์ BOQ เดิม (Excel หรือ PDF)",
                filetypes=[("Excel / PDF", "*.xlsx *.xlsm *.pdf"), ("Excel", "*.xlsx *.xlsm"), ("PDF", "*.pdf")]))
            if not originals:
                return
        if not self._ensure_scanned(list(files) + originals):
            return
        self.status("กำลังเทียบใบเสนอราคา ...")
        self.root.update_idletasks()
        res = compare.run_compare(list(files), originals, num(o["ref_mult"]), num(o["new_mult"]),
                                  only_over=o["mode"] == OVER_ONLY)
        if not res["lines"]:
            messagebox.showwarning("เทียบใบเสนอราคา", "อ่านรายการไม่ได้ — ไม่พบแถวหัวตาราง (รายการ / จำนวน / หน่วย)")
            return
        base = (self.proj.folder / "exports") if self.proj else Path(files[0]).parent
        base.mkdir(parents=True, exist_ok=True)
        out = filedialog.asksaveasfilename(
            title="บันทึกผลเทียบ (ไฟล์ภายใน มีราคาเดิม)", initialdir=base, defaultextension=".xlsx",
            initialfile=f"เทียบใบเสนอราคา {Path(files[0]).stem[:40]}_{time.strftime('%y%m%d')}.xlsx",
            filetypes=[("Excel", "*.xlsx")])
        if not out:
            return
        ask = str(Path(out).with_name(f"เรื่องที่ต้องถามผู้รับเหมา (ส่งได้)_{time.strftime('%y%m%d')}.xlsx"))
        compare.export_compare(res, out, ask)
        t = res["totals"]
        self.status(f"เทียบแล้ว {t['n_lines']} บรรทัด: ใส่ราคา {t['n_priced']} · ไม่ใส่ราคา {t['n_unpriced']} · "
                    f"ขอเพิ่ม {t['extra_total']:,.2f} · บรรทัดเดียวกัน ต่าง {t['diff_cash']:,.2f} → {out}")
        open_file(out)

    @safe
    def pullout(self):
        """ถอดงานออกจากผู้รับเหมาเดิม — works with or without an open project."""
        from .pullout_dialog import PulloutDialog
        files = filedialog.askopenfilenames(
            title="เลือก BOQ เดิม / ใบเสนองานเพิ่มของผู้รับเหมาเดิม (Excel หรือ PDF) — เลือกได้หลายไฟล์",
            filetypes=[("Excel / PDF", "*.xlsx *.xlsm *.pdf"), ("Excel", "*.xlsx *.xlsm"), ("PDF", "*.pdf")])
        if not files:
            return
        if not self._ensure_scanned(list(files)):
            return
        self.status("กำลังอ่าน BOQ เดิม ...")
        self.root.update_idletasks()
        dlg = PulloutDialog(self.root, list(files), self.settings, open_file)
        if not dlg.rows:
            dlg.destroy()
            messagebox.showwarning("ถอดงาน", "อ่านรายการไม่ได้ — ไม่พบแถวหัวตาราง (รายการ / จำนวน / หน่วย)")
            return
        self.status(f"อ่าน BOQ เดิมแล้ว {sum(1 for x in dlg.rows if x.kind == 'item')} บรรทัด")

    @safe
    def export_excel(self):
        if not self._need():
            return
        errs = [i for i in run_checks(self.proj) if i[0] == "ผิดพลาด"]
        if errs and not messagebox.askyesno(
                "พบข้อผิดพลาด", f"พบข้อผิดพลาด {len(errs)} รายการ (ดูแท็บ ตรวจสอบ)\nส่งออกต่อหรือไม่?"):
            return
        p = self._export_path(".xlsx", "Excel")
        if p:
            export_excel(self.proj, p)
            self.status(f"ส่งออก Excel แล้ว: {p}")
            open_file(p)

    @safe
    def export_csv(self):
        if self._need():
            p = self._export_path(".csv", "CSV")
            if p:
                export_csv(self.proj, p)
                self.status(f"ส่งออก CSV แล้ว: {p}")

    @safe
    def export_pdf(self):
        if self._need():
            p = self._export_path(".pdf", "PDF แบบพร้อมเส้นวัด")
            if p:
                export_markup_pdf(self.proj, p)
                self.status(f"ส่งออก PDF แล้ว: {p}")
                open_file(p)
