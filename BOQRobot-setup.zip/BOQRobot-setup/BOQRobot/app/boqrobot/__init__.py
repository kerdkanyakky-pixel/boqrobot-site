APP_NAME = "BOQ Quantity Takeoff Robot"
VERSION = "1.9.0"
