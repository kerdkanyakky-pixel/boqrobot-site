"""ถอดงานออกจากผู้รับเหมาเดิม — pull a scope of work out of the original contractor's BOQ.

Input : the original BOQ / VO workbooks (Excel, or text PDF), the lines the user picked, and how much of each
        line the old contractor has already done (%).
Output: 1. "BOQ ขอราคา <งาน>"           — for the new contractor: no prices, yellow cells to fill, formulas
        2. "ถอดงาน<งาน>ออกจาก<ผรม>"     — internal: original prices, done / pulled-out amounts, total by group
                                          with an editable OH/VAT multiplier per group (formulas)
        3. "ไฮไลต์รายการที่ถอดจาก<ผรม>" — the original PDF with the picked lines boxed (optional)
Rules: no invented prices; every figure keeps its file / sheet / row; a summary line and its detail lines
are never both counted.
"""
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from .compare import find_columns, open_book, _s, _num, _code_from_float, _unit_key, _norm

SEND_DIR = "1 ส่งผู้รับเหมาได้"
INTERNAL_DIR = "2 ใช้ภายใน ห้ามส่งผู้รับเหมา"


@dataclass
class Row:
    idx: int
    source: str          # file stem
    path: str            # full path
    sheet: str
    row: int
    kind: str            # "head" | "item"
    code: str
    desc: str
    unit: str = ""
    qty: float | None = None
    mat: float | None = None
    lab: float | None = None
    rate: float | None = None
    amount: float | None = None
    check_qty: float | None = None
    group: str = ""
    page: int | None = None
    remark: str = ""
    level: int = 9
    parent: int | None = None       # idx of the innermost heading above
    end: int | None = None          # heading: idx after the last row it covers
    summary_of: list = field(default_factory=list)   # item: idxs of the detail lines it sums up

    @property
    def where(self):
        pg = f" หน้า {self.page}" if self.page else ""
        return f"{self.source} / {self.sheet} แถว {self.row}{pg}"

    @property
    def value(self):
        if self.amount is not None:
            return self.amount
        if self.qty is not None and (self.mat is not None or self.lab is not None or self.rate is not None):
            r = self.rate if self.rate is not None else (self.mat or 0) + (self.lab or 0)
            return self.qty * r
        return None


def _level(code):
    c = (code or "").strip().rstrip(".")
    if not c:
        return None
    if re.fullmatch(r"[A-Za-zก-ฮ]", c):
        return 0
    if re.fullmatch(r"\d+(\.\d+)*", c):
        return c.count(".") + 1
    return None


def read_boq(paths, sheets=None):
    """All rows (headings and items) of every priced sheet, in order."""
    rows = []
    skipped = []
    for p in paths:
        wb = open_book(p)
        skipped += getattr(wb, "boq_notes", [])
        stem = Path(p).stem
        for ws in wb.worksheets:
            if sheets and ws.title.strip() not in [x.strip() for x in sheets]:
                continue
            hr, c = find_columns(ws)
            if not hr:
                skipped.append(f"{stem}: {ws.title}")
                continue
            for r in range(hr + 1, ws.max_row + 1):
                desc = _s(ws.cell(r, c["desc"]).value)
                cv = ws.cell(r, c["code"]).value if c["code"] else None
                code = _code_from_float(cv, ws.cell(r, c["code"]).number_format) if isinstance(cv, float) else _s(cv)
                if not desc and not code:
                    continue
                q = _num(ws.cell(r, c["qty"]).value)
                g = lambda k: ws.cell(r, c[k]).value if c.get(k) else None  # noqa: E731
                page = _num(g("page"))
                if page is None and ws.title.startswith("หน้า "):
                    page = _num(ws.title[5:])
                unit = _s(g("unit"))
                if q == 0 and not unit:
                    q = None          # "3.1 MAIN BOARD  0  112,934.70" = a heading with its subtotal
                x = Row(len(rows), stem, str(p), ws.title.strip(), r, "item" if q is not None else "head",
                        code, desc, unit=unit, qty=q, mat=_num(g("mat")), lab=_num(g("lab")),
                        rate=_num(g("rate")), amount=_num(g("amount")), check_qty=_num(g("check_qty")),
                        group=_s(g("group")), page=int(page) if page else None, remark=_s(g("remark")))
                if x.kind == "item" and not desc:
                    continue
                rows.append(x)
    _structure(rows)
    _summaries(rows)
    return rows, skipped


def _structure(rows):
    """Give every heading the range of rows it covers and every row its parent heading."""
    n = len(rows)
    for i, h in enumerate(rows):
        if h.kind != "head":
            continue
        lv = _level(h.code)
        h.level = lv if lv is not None else 9
        j = i + 1
        while j < n and (rows[j].source, rows[j].sheet) == (h.source, h.sheet):
            y = rows[j]
            if y.kind == "head":
                ly = _level(y.code)
                if lv is not None and ly is not None and ly <= lv:
                    break
                if lv is None and (ly is not None or rows[j - 1].kind == "item"):
                    # an un-numbered heading ends at the next numbered heading or at a sibling heading
                    break
            j += 1
        h.end = j
    for i, x in enumerate(rows):
        best = None
        for h in rows[:i]:
            if h.kind == "head" and h.end and h.end > i and (h.source, h.sheet) == (x.source, x.sheet):
                if best is None or h.idx > best.idx:
                    best = h
        x.parent = best.idx if best else None


def _summaries(rows):
    """A 1-lot item whose amount equals the sum of a heading's items (elsewhere) is a summary of them."""
    heads = [h for h in rows if h.kind == "head" and h.end]
    sums = {}
    for h in heads:
        its = [rows[k] for k in range(h.idx + 1, h.end) if rows[k].kind == "item"]
        if len(its) >= 2 and all(x.value is not None for x in its):
            sums.setdefault(round(sum(x.value for x in its) * 100), []).append((h, its))
        if h.amount and its:      # some BOQs print the heading's own subtotal
            sums.setdefault(round(h.amount * 100), []).append((h, its))
    by_name = {}
    for h in heads:
        by_name.setdefault((h.code, _norm(h.desc)), h)
    for x in rows:
        if x.kind == "item" and x.value is None and x.code:
            # "4 ELECTRICAL SYSTEM WORKS 1 งาน" with no amount on a summary page = the heading of the same name
            h = by_name.get((x.code, _norm(x.desc)))
            if h is not None and h.idx != x.parent:
                its = [k for k in range(h.idx + 1, h.end) if rows[k].kind == "item"]
                if its:
                    x.summary_of = its
                    continue
        if x.kind != "item" or x.value is None or not x.qty or abs(x.qty - 1) > 1e-9 or _unit_key(x.unit) not in (
                "lot", "set", "") and "งาน" not in x.unit:
            continue
        for h, its in sums.get(round(x.value * 100), []):
            if x in its or h.idx == x.parent:
                continue
            tot = sum(v.value or 0 for v in its)
            if (tot and abs(tot - x.value) < 1) or (h.amount and abs(h.amount - x.value) < 1):
                x.summary_of = [v.idx for v in its]
                break


# ---------------------------------------------------------------- selecting
def items_under(rows, idx):
    x = rows[idx]
    if x.kind == "item":
        return [idx]
    return [k for k in range(idx + 1, x.end or idx + 1) if rows[k].kind == "item"]


def path_text(rows, x, short=False):
    """Heading path of a row. short=True: no top-level (A/B ARCHITECTURAL WORKS) part, last two levels,
    with the BOQ's group (building) in front."""
    heads = []
    p = x.parent
    while p is not None:
        heads.append(rows[p])
        p = rows[p].parent
    heads.reverse()
    if not short:
        return " / ".join(h.desc for h in heads)
    if len(heads) > 1:
        heads = [h for h in heads if h.level != 0] or heads[-1:]
    parts = [h.desc for h in heads[-2:]]
    if x.group and not any(x.group.lower() in t.lower() for t in parts):
        parts.insert(0, x.group)
    return " / ".join(parts)


def search(rows, text):
    """Items whose description, heading path, group or code match any keyword (comma separated)."""
    keys = [_norm(k) for k in re.split(r"[,;\n]", text or "") if _norm(k)]
    if not keys:
        return []
    hit = set()
    for x in rows:
        hay = _norm(" ".join([x.code, x.desc, x.group, x.remark]))
        if any(k in hay for k in keys):
            hit.update(items_under(rows, x.idx))
    return sorted(hit)


def selection_issues(rows, selected):
    """Summary lines picked together with their detail lines -> counted once (the summary is dropped)."""
    sel = set(selected)
    dropped, notes = set(), []
    for k in sel:
        x = rows[k]
        if x.summary_of and sel & set(x.summary_of):
            dropped.add(k)
            notes.append(f"{x.code} {x.desc[:40]} ({x.where}) เป็นยอดรวมของรายการย่อยที่เลือกแล้ว — ไม่นับซ้ำ")
    return dropped, notes


def group_of(rows, x):
    if x.group:
        return x.group
    p, top = x.parent, None
    while p is not None:
        if rows[p].level <= 1:
            top = rows[p]
        p = rows[p].parent
    if top is not None:
        return f"{x.source} — {top.code} {top.desc}".strip()[:60]
    return f"{x.source} — {x.sheet}"


def totals(rows, selected, done=None):
    done = done or {}
    dropped, notes = selection_issues(rows, selected)
    use = [k for k in sorted(set(selected)) if k not in dropped]
    t = {"n": len(use), "base": 0.0, "done": 0.0, "pull": 0.0, "groups": {}, "notes": notes,
         "dropped": dropped, "no_price": []}
    for k in use:
        x = rows[k]
        v = x.value
        if v is None:
            t["no_price"].append(k)
            v = 0.0
        d = v * min(100.0, max(0.0, done.get(k, 0.0))) / 100
        g = t["groups"].setdefault(group_of(rows, x), {"n": 0, "base": 0.0, "done": 0.0, "pull": 0.0,
                                                       "rows": []})
        for tgt in (t, g):
            tgt["base"] += v
            tgt["done"] += d
            tgt["pull"] += v - d
        g["n"] += 1
        g["rows"].append(x.row)
    for key in ("base", "done", "pull"):
        t[key] = round(t[key] + 1e-9, 2)
        for g in t["groups"].values():
            g[key] = round(g[key] + 1e-9, 2)
    return t


# ---------------------------------------------------------------- export
def send_desc(rows, x):
    """A line a new contractor can read on its own ("- Ø 4"" -> "FLOOR CLEAN OUT – Ø 4")."""
    d = re.sub(r"^\s*[-–•]\s*", "", x.desc).strip()
    if x.parent is not None and (len(d) < 25 or not re.match(r"[A-Za-zก-๙]", d)):
        head = re.sub(r"^\s*[-–•]\s*", "", rows[x.parent].desc).strip()
        if head and head.lower() not in d.lower():
            return f"{head} – {d}"
    return d


def _short(job):
    """'งานไฟฟ้า' -> 'ไฟฟ้า' so the file reads 'ถอดงานไฟฟ้า…' not 'ถอดงานงานไฟฟ้า…'."""
    j = (job or "").strip()
    return j[3:].strip() if j.startswith("งาน") and len(j) > 3 else j


def _ranges(nums):
    nums = sorted(set(nums))
    out, start, prev = [], None, None
    for n in nums:
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append(f"{start}" if start == prev else f"{start}-{prev}")
            start = prev = n
    if start is not None:
        out.append(f"{start}" if start == prev else f"{start}-{prev}")
    return ", ".join(out)


def export(rows, selected, done, job, old_name, out_dir, mult=1.0, project="", pdfs=None, date=None):
    """Write the package. Returns dict of paths + highlight stats."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter as CL
    date = date or time.strftime("%y%m%d")
    done = done or {}
    out_dir = Path(out_dir)
    send_dir = out_dir / f"{SEND_DIR}_{date}"
    int_dir = out_dir / f"{INTERNAL_DIR}_{date}"
    send_dir.mkdir(parents=True, exist_ok=True)
    int_dir.mkdir(parents=True, exist_ok=True)
    t = totals(rows, selected, done)
    use = [k for k in sorted(set(selected)) if k not in t["dropped"]]
    f = Font(name="Tahoma", size=10)
    fb = Font(name="Tahoma", size=10, bold=True)
    fh = Font(name="Tahoma", size=10, bold=True, color="FFFFFF")
    ft = Font(name="Tahoma", size=13, bold=True)
    head = PatternFill("solid", fgColor="2F5597")
    sec = PatternFill("solid", fgColor="DDEBF7")
    yel = PatternFill("solid", fgColor="FFF2CC")
    org = PatternFill("solid", fgColor="F8CBAD")
    bd = Border(*(Side(style="thin", color="BFBFBF"),) * 4)
    MF = '#,##0.00;[Red]-#,##0.00'
    QF = '#,##0.00'

    def header(ws, r, cols, widths):
        for i, (name, w) in enumerate(zip(cols, widths), 1):
            c = ws.cell(r, i, name)
            c.font, c.fill, c.border = fh, head, bd
            c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
            ws.column_dimensions[CL(i)].width = w
        ws.row_dimensions[r].height = 34

    def style_row(ws, r, n, bold=False, fill=None):
        for i in range(1, n + 1):
            c = ws.cell(r, i)
            c.font, c.border = (fb if bold else f), bd
            c.alignment = Alignment(vertical="top", wrap_text=True)
            if fill:
                c.fill = fill

    # ---- 1. BOQ ขอราคา (send) — grouped by heading, no prices
    has_check = any(rows[k].check_qty is not None for k in use)
    wb = Workbook()
    ws = wb.active
    ws.title = (job or "ขอราคา")[:30]
    ws["A1"] = f"BOQ ขอราคา — {job}"
    ws["A1"].font = ft
    ws["A2"] = (f"{project} — " if project else "") + "กรอกราคาต่อหน่วยในช่องสีเหลือง (วัสดุ / ค่าแรง แยกกัน)"
    ws["A2"].font = f
    cols = ["ลำดับ", "รายการ", "หน่วย", "จำนวน"] + (["จำนวน (ตรวจแล้ว)"] if has_check else []) + [
        "ราคาต่อหน่วย\nวัสดุ (บาท)", "ราคาต่อหน่วย\nค่าแรง (บาท)", "รวม (บาท)", "หมายเหตุให้ผู้รับเหมา"]
    widths = [7, 60, 8, 10] + ([11] if has_check else []) + [14, 14, 15, 36]
    header(ws, 4, cols, widths)
    nc = len(cols)
    cq = 5 if has_check else 4
    cm, cl, ca, cr = cq + 1, cq + 2, cq + 3, cq + 4
    r, n, last_head, first_item = 5, 0, None, None
    for k in use:
        x = rows[k]
        if done.get(k, 0) >= 100:
            continue
        hp = path_text(rows, x, short=True)
        if hp != last_head:
            ws.cell(r, 2, hp or x.sheet)
            style_row(ws, r, nc, bold=True, fill=sec)
            r += 1
            last_head = hp
        n += 1
        ws.cell(r, 1, n)
        ws.cell(r, 2, send_desc(rows, x))
        ws.cell(r, 3, x.unit)
        ws.cell(r, 4, x.qty)
        q_col = CL(4)
        if has_check:
            ws.cell(r, 5, x.check_qty)
            if x.check_qty is not None:
                q_col = CL(5)
        ws.cell(r, ca, f"={q_col}{r}*(N({CL(cm)}{r})+N({CL(cl)}{r}))")
        note = []
        if 0 < done.get(k, 0) < 100:
            note.append("ผู้รับเหมาเดิมทำไปแล้วบางส่วน — ตีราคาเฉพาะส่วนที่เหลือ (ดูหน้างาน)")
        style_row(ws, r, nc)
        for c in (cm, cl):
            ws.cell(r, c).fill = yel
        if has_check and x.check_qty is not None and x.qty and abs(x.check_qty - x.qty) > 0.01 * abs(x.qty):
            ws.cell(r, 5).fill = org
            note.append(f"จำนวนตรวจแล้วต่างจาก BOQ เดิม ({x.qty:g}) — ใช้จำนวนตรวจแล้ว")
        ws.cell(r, cr, " / ".join(note) or None)
        for c in range(4, ca + 1):
            ws.cell(r, c).number_format = QF if c <= cq else MF
        first_item = first_item or r
        r += 1
    ws.cell(r, 2, "รวม")
    ws.cell(r, ca, f"=SUM({CL(ca)}5:{CL(ca)}{r - 1})")
    style_row(ws, r, nc, bold=True)
    ws.cell(r, ca).number_format = MF
    ws.freeze_panes = "C5"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = "4:4"
    send_path = send_dir / f"BOQ ขอราคา {job}_{date}.xlsx"
    wb.save(send_path)

    # ---- 2. internal
    wb = Workbook()
    s = wb.active
    s.title = "สรุปยอดหัก"
    d = wb.create_sheet("รายการที่ถอด")
    dcols = ["ลำดับ", "กลุ่ม", "หมวด", "ข้อ", "รายการ (ตาม BOQ เดิม)", "หน่วย", "จำนวน", "ค่าวัสดุ/หน่วย",
             "ค่าแรง/หน่วย", "รวมเงิน (บาท)", "ทำแล้ว %", "ยอดทำแล้ว (ไม่หัก)", "ยอดถอด (บาท)", "หมายเหตุ", "ที่มา"]
    header(d, 1, dcols, [6, 22, 28, 7, 50, 7, 10, 12, 12, 14, 9, 14, 14, 30, 34])
    r = 2
    for i, k in enumerate(use, 1):
        x = rows[k]
        rate_note = []
        if x.value is None:
            rate_note.append("ไม่มีราคาใน BOQ เดิม")
        if x.mat is None and x.lab is None and x.rate is not None:
            mat, lab = x.rate, None
        else:
            mat, lab = x.mat, x.lab
        vals = [i, group_of(rows, x), path_text(rows, x, short=True), x.code, x.desc, x.unit, x.qty, mat, lab,
                x.value if x.value is not None else 0, (done.get(k, 0) or 0) / 100,
                f"=J{r}*K{r}", f"=J{r}-L{r}", " / ".join(rate_note) or None, x.where]
        for c, v in enumerate(vals, 1):
            d.cell(r, c, v)
        style_row(d, r, len(dcols))
        for c in (7, 8, 9, 10, 12, 13):
            d.cell(r, c).number_format = MF if c != 7 else QF
        d.cell(r, 11).number_format = "0%"
        if done.get(k, 0):
            for c in (11, 12):
                d.cell(r, c).fill = org
        r += 1
    last = r - 1
    d.cell(r, 5, "รวม")
    for c in (10, 12, 13):
        d.cell(r, c, f"=SUM({CL(c)}2:{CL(c)}{max(2, last)})")
        d.cell(r, c).number_format = MF
    style_row(d, r, len(dcols), bold=True)
    d.freeze_panes = "F2"
    d.auto_filter.ref = f"A1:{CL(len(dcols))}{max(2, last)}"

    s["A1"] = f"ถอดงาน{_short(job)}ออกจาก{old_name}"
    s["A1"].font = ft
    s["A2"] = (f"{project} — " if project else "") + "ใช้ภายใน ห้ามส่งผู้รับเหมา · ช่องสีเหลือง (ตัวคูณ) แก้ได้"
    s["A2"].font = f
    scols = ["กลุ่ม", "บรรทัด", "ยอดตาม BOQ เดิม", "ทำแล้ว (ไม่หัก)", "ยอดถอด\n(ก่อน OH/VAT)", "ตัวคูณ\nOH/VAT",
             "ยอดถอดรวม\nOH/VAT", "แถวในไฟล์เดิม"]
    header(s, 4, scols, [44, 8, 17, 16, 17, 10, 18, 34])
    r = 5
    for name, g in t["groups"].items():
        s.cell(r, 1, name)
        s.cell(r, 2, g["n"])
        rng = f"รายการที่ถอด!$B$2:$B${max(2, last)}"
        s.cell(r, 3, f'=SUMIFS(รายการที่ถอด!$J$2:$J${max(2, last)},{rng},A{r})')
        s.cell(r, 4, f'=SUMIFS(รายการที่ถอด!$L$2:$L${max(2, last)},{rng},A{r})')
        s.cell(r, 5, f"=C{r}-D{r}")
        s.cell(r, 6, mult)
        s.cell(r, 7, f"=ROUND(E{r}*F{r},2)")
        s.cell(r, 8, _ranges(g["rows"]))
        style_row(s, r, len(scols))
        s.cell(r, 6).fill = yel
        for c in (3, 4, 5, 7):
            s.cell(r, c).number_format = MF
        s.cell(r, 6).number_format = "0.0000"
        r += 1
    s.cell(r, 1, "รวม")
    for c in (2, 3, 4, 5, 7):
        s.cell(r, c, f"=SUM({CL(c)}5:{CL(c)}{r - 1})")
        s.cell(r, c).number_format = MF if c != 2 else "0"
    style_row(s, r, len(scols), bold=True)
    r += 2
    notes = list(t["notes"])
    if t["no_price"]:
        notes.append(f"{len(t['no_price'])} บรรทัดไม่มีราคาใน BOQ เดิม (นับเป็น 0)")
    pdf_stats = []
    if pdfs:
        for src, pdf in pdfs.items():
            if not pdf:
                continue
            out = int_dir / f"ไฮไลต์รายการที่ถอดจาก{old_name}_{job}_{date}.pdf"
            if len([p for p in pdfs.values() if p]) > 1:
                out = int_dir / f"ไฮไลต์รายการที่ถอดจาก{old_name}_{job}_{src[:30]}_{date}.pdf"
            st = highlight_pdf(rows, [k for k in use if rows[k].source == src], done, pdf, out)
            st["path"] = str(out)
            pdf_stats.append(st)
            msg = f"ไฮไลต์ใน PDF ({Path(pdf).name}): เจอ {st['found']}/{st['wanted']} บรรทัด"
            if st["missing"]:
                msg += " — หาไม่เจอ: " + ", ".join(rows[k].where for k in st["missing"][:8])
            notes.append(msg)
    if notes:
        s.cell(r, 1, "หมายเหตุ").font = fb
        for nline in notes:
            r += 1
            s.cell(r, 1, nline).font = f
    s.freeze_panes = "A5"
    # the picked lines, so the selection can be opened again in the program
    h = wb.create_sheet("_เลือกไว้")
    h.append(["ไฟล์", "ชีท", "แถว", "ทำแล้ว %"])
    for k in use:
        h.append([rows[k].source, rows[k].sheet, rows[k].row, done.get(k, 0)])
    h.sheet_state = "hidden"
    int_path = int_dir / f"ถอดงาน{_short(job)}ออกจาก{old_name}_{date}.xlsx"
    wb.save(int_path)
    return {"send": str(send_path), "internal": str(int_path), "totals": t, "pdf": pdf_stats,
            "send_dir": str(send_dir), "internal_dir": str(int_dir)}


def load_selection(rows, internal_path):
    """Read the hidden "_เลือกไว้" sheet of an earlier package -> (selected idxs, done dict, not_found)."""
    import openpyxl
    wb = openpyxl.load_workbook(internal_path, data_only=True)
    if "_เลือกไว้" not in wb.sheetnames:
        raise ValueError("ไฟล์นี้ไม่มีรายการที่เลือกไว้ (ต้องเป็นไฟล์ 'ถอดงาน…' ที่โปรแกรมทำ)")
    key = {(x.source, x.sheet, x.row): x.idx for x in rows if x.kind == "item"}
    sel, done, miss = [], {}, 0
    for src, sheet, row, pct in wb["_เลือกไว้"].iter_rows(min_row=2, values_only=True):
        k = key.get((src, sheet, row))
        if k is None:
            miss += 1
            continue
        sel.append(k)
        if pct:
            done[k] = float(pct)
    return sel, done, miss


# ---------------------------------------------------------------- PDF highlight
def _pdf_numbers(doc):
    toks = []
    for pn, page in enumerate(doc):
        words = sorted(page.get_text("words"), key=lambda w: (w[1] + w[3]) / 2)
        lines = []
        for w in words:
            yc = (w[1] + w[3]) / 2
            if lines and abs(lines[-1][0] - yc) <= max(2.5, (w[3] - w[1]) * 0.45):
                lines[-1][1].append(w)
            else:
                lines.append([yc, [w]])
        for _, ws in lines:
            nums = []
            for w in ws:
                t = w[4].replace(",", "")
                if re.fullmatch(r"-?\d+(\.\d+)?", t):
                    nums.append((float(t), w))
            if not nums:
                continue
            right = max(nums, key=lambda v: v[1][2])[1]
            x0 = min(w[0] for w in ws)
            x1 = max(w[2] for w in ws)
            for v, w in nums:
                toks.append({"page": pn, "y": (w[1] + w[3]) / 2, "x": w[0], "v": round(v, 2),
                             "right": w is right, "band": (x0, w[1] - 1.5, x1, w[3] + 1.5)})
    toks.sort(key=lambda t: (t["page"], t["y"], t["x"]))
    return toks


def align_pdf(rows, items, doc):
    """Map item idx -> PDF token, walking both in order (amounts repeat a lot, so order matters)."""
    toks = _pdf_numbers(doc)
    out, ptr = {}, 0
    for k in items:
        x = rows[k]
        v = x.value
        if v is None or abs(v) < 0.005:
            continue
        v = round(v, 2)
        start = ptr
        if x.page:
            # page column in the workbook (1-based) -> never search before that page
            while start < len(toks) and toks[start]["page"] < x.page - 1:
                start += 1
        best = None
        for j in range(start, min(len(toks), start + 600)):
            t = toks[j]
            if x.page and t["page"] > x.page:
                break
            if abs(t["v"] - v) < 0.005:
                if t["right"]:
                    best = j
                    break
                best = best if best is not None else j
        if best is not None:
            out[k] = toks[best]
            ptr = best + 1
    return out


def highlight_pdf(rows, selected, done, pdf_path, out_path):
    import pymupdf
    doc = pymupdf.open(str(pdf_path))
    src = rows[selected[0]].source if selected else None
    every = [x.idx for x in rows if x.kind == "item" and x.source == src]
    hit = align_pdf(rows, every, doc)
    wanted = [k for k in selected if rows[k].value]
    found = [k for k in wanted if k in hit]
    pages = set()
    for k in found:
        t = hit[k]
        page = doc[t["page"]]
        rect = pymupdf.Rect(*t["band"])
        orange = done.get(k, 0) > 0
        page.draw_rect(rect, color=(0.85, 0, 0), fill=(1, 0.6, 0.2) if orange else (1, 0.95, 0.2),
                       fill_opacity=0.35, width=0.8, overlay=True)
        pages.add(t["page"])
    if pages:
        outdoc = pymupdf.open()
        for pn in sorted(pages):
            outdoc.insert_pdf(doc, from_page=pn, to_page=pn)
        outdoc.save(str(out_path))
    return {"wanted": len(wanted), "found": len(found), "missing": [k for k in wanted if k not in hit],
            "sum_found": round(sum(rows[k].value for k in found), 2), "pages": [p + 1 for p in sorted(pages)]}
