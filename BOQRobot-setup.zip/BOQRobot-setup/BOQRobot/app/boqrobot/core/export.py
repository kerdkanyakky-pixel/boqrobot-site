"""Export: Excel (live formulas, traceable), CSV, marked-up drawing PDF."""
import csv
import json
from pathlib import Path

from .takeoff import compute, KIND_LABEL
from .geometry import rect_points


def _xl_font():
    from openpyxl.styles import Font
    return Font(name="Tahoma", size=10), Font(name="Tahoma", size=10, bold=True)


def export_excel(project, path):
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    rows = [r for r in compute(project) if r.lines or r.item["mat_rate"] or r.item["lab_rate"]]
    info = project.info()
    f, fb = _xl_font()
    head_fill = PatternFill("solid", fgColor="DDEBF7")
    thin = Side(style="thin", color="BFBFBF")
    border = Border(bottom=thin)
    wb = Workbook()

    # ---- sheet 2 first (so formulas can refer to it): trace ----
    ws_bq = wb.active
    ws_bq.title = "BOQ"
    ws_tr = wb.create_sheet("ที่มาปริมาณ")
    ws_sum = wb.create_sheet("สรุปตามหมวด")

    tr_head = ["รหัส", "รายการ", "แบบ", "หน้า", "วิธีวัด", "ยาว L (ม.)", "พื้นที่ A (ตร.ม.)",
               "จำนวน N", "สูตร / การแทนค่า", "ปริมาณ", "หมายเหตุ"]
    ws_tr.append(tr_head)
    for r in rows:
        for ln in r.lines:
            ws_tr.append([r.item["code"], r.item["name"], ln.drawing, ln.page_no,
                          KIND_LABEL.get(ln.kind, ln.kind), round(ln.L, 3), round(ln.A, 3),
                          ln.N, ln.formula_text, round(ln.qty, 4),
                          "; ".join(x for x in (ln.note, ln.error) if x)])
    n_tr = ws_tr.max_row

    bq_head = ["รหัส", "หมวดงาน", "รายการ", "ปริมาณสุทธิ", "เผื่อ %", "ปริมาณ", "หน่วย",
               "ค่าวัสดุ/หน่วย", "ค่าวัสดุรวม", "ค่าแรง/หน่วย", "ค่าแรงรวม", "รวมเงิน",
               "สูตร", "ที่มา (แบบ/หน้า)", "ตรวจแล้ว", "หมายเหตุ"]
    ws_bq.append([f"BOQ — {info.get('name', '')}"])
    ws_bq.append([f"ลูกค้า: {info.get('client', '')}   ที่ตั้ง: {info.get('address', '')}   "
                  f"เลขที่: {info.get('number', '')}"])
    ws_bq.append(bq_head)
    first = ws_bq.max_row + 1
    for r in rows:
        i = ws_bq.max_row + 1
        it = r.item
        ws_bq.append([
            it["code"], it["category"], it["name"],
            f"=ROUND(SUMIF('ที่มาปริมาณ'!$A$2:$A${max(n_tr,2)},A{i},'ที่มาปริมาณ'!$J$2:$J${max(n_tr,2)}),4)",
            it["waste"] or 0, f"=ROUND(D{i}*(1+E{i}/100),2)", it["unit"],
            it["mat_rate"] or 0, f"=F{i}*H{i}", it["lab_rate"] or 0, f"=F{i}*J{i}",
            f"=I{i}+K{i}", it["formula"], r.refs, "✓" if it["verified"] else "", it["note"] or ""])
    last = ws_bq.max_row
    t = last + 1
    ws_bq.append(["", "", "รวมทั้งสิ้น", "", "", "", "", "", f"=SUM(I{first}:I{last})", "",
                  f"=SUM(K{first}:K{last})", f"=SUM(L{first}:L{last})"])

    cats = []
    for r in rows:
        if r.item["category"] not in cats:
            cats.append(r.item["category"])
    ws_sum.append(["หมวดงาน", "ค่าวัสดุ", "ค่าแรง", "รวม"])
    for c in cats:
        k = ws_sum.max_row + 1
        rng = f"BOQ!$B${first}:$B${last}"
        ws_sum.append([c, f"=SUMIF({rng},A{k},BOQ!$I${first}:$I${last})",
                       f"=SUMIF({rng},A{k},BOQ!$K${first}:$K${last})", f"=B{k}+C{k}"])
    k = ws_sum.max_row
    ws_sum.append(["รวม", f"=SUM(B2:B{k})", f"=SUM(C2:C{k})", f"=SUM(D2:D{k})"])

    # ---- styling ----
    def style(ws, head_row, widths, money_cols=(), qty_cols=()):
        for row in ws.iter_rows():
            for c in row:
                c.font = f
        for c in ws[head_row]:
            c.font, c.fill, c.border = fb, head_fill, border
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        for col in money_cols:
            for c in ws[col][head_row:]:
                c.number_format = "#,##0.00"
        for col in qty_cols:
            for c in ws[col][head_row:]:
                c.number_format = "#,##0.00##"
        ws.freeze_panes = ws.cell(row=head_row + 1, column=1)

    style(ws_bq, 3, [7, 14, 42, 12, 7, 11, 7, 12, 14, 12, 14, 15, 12, 28, 8, 24],
          "HIJKL", "DF")
    ws_bq["A1"].font = type(fb)(name="Tahoma", size=13, bold=True)
    for c in ws_bq[t]:
        c.font = fb
    style(ws_tr, 1, [7, 36, 16, 6, 18, 11, 13, 9, 48, 12, 30], (), "FGJ")
    style(ws_sum, 1, [24, 16, 16, 16], "BCD")
    for c in ws_sum[ws_sum.max_row]:
        c.font = fb
    ws_bq.auto_filter.ref = f"A3:P{last}"
    ws_tr.auto_filter.ref = f"A1:K{n_tr}"
    path = Path(path)
    wb.save(path)
    project.audit("export_excel", path.name)
    project.touch()
    return path


def export_csv(project, path):
    rows = compute(project)
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["รหัส", "หมวดงาน", "รายการ", "ปริมาณ", "หน่วย", "ค่าวัสดุ/หน่วย",
                    "ค่าแรง/หน่วย", "รวมเงิน", "สูตร", "ที่มา", "ตรวจแล้ว"])
        for r in rows:
            if not r.lines:
                continue
            it = r.item
            w.writerow([it["code"], it["category"], it["name"], f"{r.qty:.2f}", it["unit"],
                        it["mat_rate"], it["lab_rate"], f"{r.total:.2f}", it["formula"],
                        r.refs, "Y" if it["verified"] else ""])
    return Path(path)


def _rgb(hexcolor):
    h = hexcolor.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def export_markup_pdf(project, path):
    """Copy of every measured page with measurements drawn on top + item code labels."""
    import fitz
    items = {i["id"]: i for i in project.items()}
    out = fitz.open()
    for d in project.drawings():
        src = None
        for p in project.pages(d["id"]):
            ms = project.measurements(page_id=p["id"])
            if not ms:
                continue
            if src is None:
                src = fitz.open(project.drawing_path(d["id"]))
            out.insert_pdf(src, from_page=p["page_no"] - 1, to_page=p["page_no"] - 1)
            pg = out[-1]
            # measurement points are in displayed (rotated) coords -> convert to unrotated
            mat = pg.derotation_matrix
            for m in ms:
                it = items.get(m["item_id"])
                if not it:
                    continue
                col = _rgb(it["color"] or "#ff0000")
                pts = [fitz.Point(*xy) * mat for xy in json.loads(m["points"])]
                if m["kind"] == "rect" and len(pts) == 2:
                    pts = [fitz.Point(*xy) * mat for xy in
                           rect_points(*json.loads(m["points"]))]
                sh = pg.new_shape()
                if m["kind"] == "count":
                    for q in pts:
                        sh.draw_circle(q, 6)
                    sh.finish(color=col, width=2)
                elif m["kind"] == "line":
                    sh.draw_polyline(pts)
                    sh.finish(color=col, width=2.5, dashes="[4] 0" if m["sign"] == -1 else None)
                else:
                    sh.draw_polyline(pts + [pts[0]])
                    sh.finish(color=col, fill=col, fill_opacity=0.18, width=2,
                              closePath=True)
                label = it["code"] + (" (-)" if m["sign"] == -1 else "")
                sh.insert_text(pts[0] + (4, -4), label, fontsize=9, color=col)
                sh.commit()
        if src:
            src.close()
    if out.page_count == 0:
        raise ValueError("ยังไม่มีการวัดบนแบบ")
    out.save(path, garbage=3, deflate=True)
    project.audit("export_markup_pdf", Path(path).name)
    return Path(path)
