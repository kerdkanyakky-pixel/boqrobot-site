"""ตรวจ BOQ ผู้รับเหมา (คิดย้อน) — audit a contractor's BOQ / quotation workbook WITHOUT drawings.

What it finds (all rule based, no AI, no invented prices):
  1. implied size  — e.g. sand 5.2 m³ at 5 cm = 104 m² of floor in a 4 m² room
  2. sibling ratios per zone — formwork/concrete, rebar kg/m³, plaster vs wall, skim vs plaster,
     primer vs paint, adhesive vs tile, screed vs tile, steel box kg per m² of WPC
  3. one zone far out of line with the other zones (e.g. DB12 kg per m³ concrete 10x the others)
  4. lump-sum rows (Lot/Job) that are an exact % of their sibling rows -> recomputable
  5. probable double charging — same item, same quantity and amount in two places/files
  6. the same item priced differently in different zones
The user then types (or the program fills) "ปริมาณที่เราวัด" and the workbook computes the money.
"""
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass, field
from statistics import median

# ---------------------------------------------------------------- reading
HEAD_DESC = ("DESCRIPTION", "รายการ", "รายละเอียด", "ITEM DESCRIPTION")
HEAD_QTY = ("Q'TY", "QTY", "QUANTITY", "จำนวน", "ปริมาณ")
HEAD_UNIT = ("UNIT", "หน่วย")
HEAD_MAT = ("MATERIAL", "ค่าวัสดุ", "วัสดุ")
HEAD_LAB = ("LABOUR", "LABOR", "ค่าแรง")
SKIP_DESC = re.compile(r"^\s*(total|sub\s*total|grand total|รวม|ยอดรวม|overhead|vat|sumtotal|\*)", re.I)


def _s(v):
    return unicodedata.normalize("NFC", str(v)).strip() if v is not None else ""


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _find_header(ws, max_rows=25):
    """Return (header_row, cols dict) or (None, None)."""
    for r in range(1, min(ws.max_row, max_rows) + 1):
        cells = {c: _s(ws.cell(r, c).value).upper() for c in range(1, min(ws.max_column, 30) + 1)}
        desc = next((c for c, t in cells.items() if any(t.startswith(h.upper()) for h in HEAD_DESC)), None)
        qty = next((c for c, t in cells.items() if any(t.replace(" ", "").startswith(h.upper().replace(" ", ""))
                                                         for h in HEAD_QTY)), None)
        if not (desc and qty):
            continue
        unit = next((c for c, t in cells.items() if any(t.startswith(h.upper()) for h in HEAD_UNIT)), None)
        mat = next((c for c, t in cells.items() if c > qty and any(h.upper() in t for h in HEAD_MAT)), None)
        lab = next((c for c, t in cells.items() if c > qty and any(h.upper() in t for h in HEAD_LAB)), None)
        return r, {"desc": desc, "qty": qty, "unit": unit, "mat": mat, "lab": lab}
    return None, None


@dataclass
class Row:
    source: str          # file label
    sheet: str
    row: int
    zone: str
    desc: str
    unit: str
    qty: float
    mat: float
    lab: float
    key: str = ""        # category detected
    dia: str = ""        # rebar diameter
    flags: list = field(default_factory=list)   # (level, text)
    implied: str = ""
    lot_pct: str = ""

    @property
    def rate(self):
        return (self.mat or 0) + (self.lab or 0)

    @property
    def amount(self):
        return self.qty * self.rate

    @property
    def ref(self):
        return f"{self.source} / {self.sheet} แถว {self.row}"


def read_workbook(path, label=None, sheets=None):
    """Read every sheet that has a BOQ header. Values from Excel's cached results."""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    label = label or __import__("pathlib").Path(path).stem
    rows, skipped = [], []
    for ws in wb.worksheets:
        if sheets and ws.title not in sheets:
            continue
        hr, c = _find_header(ws)
        if not hr:
            skipped.append(ws.title)
            continue
        zone = ws.title
        bold_heads = any(ws.cell(r, c["desc"]).font.b and ws.cell(r, c["qty"]).value is None
                         and _s(ws.cell(r, c["desc"]).value) for r in range(hr + 1, ws.max_row + 1))
        for r in range(hr + 1, ws.max_row + 1):
            desc = _s(ws.cell(r, c["desc"]).value)
            qv = ws.cell(r, c["qty"]).value
            q = _num(qv)
            if q is None and isinstance(qv, str):
                try:
                    q = float(qv.replace(",", ""))
                except ValueError:
                    q = None
            if not desc:
                continue
            if SKIP_DESC.match(desc):
                continue
            unit = _s(ws.cell(r, c["unit"]).value) if c["unit"] else ""
            if q is None:
                is_head = ws.cell(r, c["desc"]).font.b if bold_heads else \
                    (len(desc) < 90 and not desc.startswith(("-", "•")))
                if qv is None and is_head:
                    zone = desc.split("/")[0].strip()[:60] or zone
                continue
            mat = _num(ws.cell(r, c["mat"]).value) if c["mat"] else None
            lab = _num(ws.cell(r, c["lab"]).value) if c["lab"] else None
            rows.append(Row(label, ws.title, r, zone, desc, unit, float(q), mat or 0.0, lab or 0.0))
    for x in rows:
        x.key, x.dia = classify(x.desc, x.unit)
    return rows, skipped


# ---------------------------------------------------------------- classification
U_AREA = re.compile(r"(sq|ตร|m2|m²)", re.I)
U_VOL = re.compile(r"(cbm|cu|ลบ|m3|m³)", re.I)
U_KG = re.compile(r"(kg|กก)", re.I)
U_LEN = re.compile(r"^(m|ม\.?|เมตร|lm)$", re.I)
U_LOT = re.compile(r"(lot|job|jop|เหมา|l\.?s|lump|งาน)", re.I)

RULES = [  # (key, regex on description) — first match wins
    ("lot", re.compile(r"(accessor|fitting|hanger|support|fixing|consumable|อุปกรณ์|equipment|adhesive & glue)", re.I)),
    ("sandwash", re.compile(r"(ทรายล้าง|sand ?wash)", re.I)),
    ("sand", re.compile(r"(ทราย|sand)", re.I)),
    ("lean", re.compile(r"(หยาบ|lean|1\s*:\s*3\s*:\s*5)", re.I)),
    ("tie", re.compile(r"(ลวดผูก|binding wire|tie wire)", re.I)),
    ("nail", re.compile(r"(ตะปู|\bnail)", re.I)),
    ("rebar", re.compile(r"(\b(RB|DB)\s*\d{1,2}\b|SR-?24|SD-?40|เหล็กเสริม)", re.I)),
    ("formwork", re.compile(r"(ไม้แบบ|formwork|model woodwork|แบบหล่อ)", re.I)),
    ("wp_concrete", re.compile(r"(concrete|คอนกรีต).*(waterproof|กันซึม)|(waterproof|กันซึม).*(concrete|คอนกรีต)", re.I)),
    ("concrete", re.compile(r"(structural concrete|คอนกรีตโครงสร้าง|ksc|คอนกรีต|concrete)", re.I)),
    ("dig", re.compile(r"(ขุด|digging|excavat)", re.I)),
    ("fill", re.compile(r"(ถม|filling|backfill)", re.I)),
    ("skim", re.compile(r"(สกิม|skim)", re.I)),
    ("ceiling", re.compile(r"(ฝ้า|ceiling|soffit)", re.I)),
    ("plaster", re.compile(r"(ฉาบ|plaster)", re.I)),
    ("primer", re.compile(r"(รองพื้น|primer)", re.I)),
    ("paint", re.compile(r"(ทาสี|paint)", re.I)),
    ("wall_tile", re.compile(r"(กระเบื้องผนัง|wall til|ผนังหิน|stone.*wall|wall.*stone)", re.I)),
    ("adhesive", re.compile(r"(ปูนกาว|ยาแนว|adhesive|grout)", re.I)),
    ("screed", re.compile(r"(ปรับระดับ|leveling|levelling|screed)", re.I)),
    ("waterproof", re.compile(r"(กันซึม|waterproof)", re.I)),
    ("floor_tile", re.compile(r"(กระเบื้อง|\btil(e|ing))", re.I)),
    ("wpc", re.compile(r"(wpc|ไม้เทียม)", re.I)),
    ("steelbox", re.compile(r"(เหล็กกล่อง|box steel|steel)", re.I)),
    ("corner", re.compile(r"(เซี้ยม|corner|door and window frames|เขิบ)", re.I)),
    ("lintel", re.compile(r"(ทับหลัง|เอ็น|lintel)", re.I)),
    ("wall", re.compile(r"(ก่อ|brick|block|aac|ผนังเบา|lightweight wall|partition|ผนัง)", re.I)),
]


def classify(desc, unit):
    u = unit or ""
    for key, rx in RULES:
        if rx.search(desc):
            if key == "lot" and not U_LOT.search(u):
                continue
            if key in ("plaster", "skim", "primer", "paint", "wall", "floor_tile", "wall_tile", "screed",
                       "adhesive", "waterproof", "ceiling", "wpc", "sand", "lean", "sandwash") and u and \
                    not (U_AREA.search(u) or U_VOL.search(u) or U_LEN.match(u) or U_KG.search(u)):
                continue
            dia = ""
            if key == "rebar":
                m = re.search(r"\b(RB|DB)\s*(\d{1,2})\b", desc, re.I)
                dia = f"{m.group(1).upper()}{m.group(2)}" if m else ""
            return key, dia
    return "", ""


# ---------------------------------------------------------------- checks
ERR, WARN, INFO = "สูงมาก", "สงสัย", "ข้อมูล"
KG_M = {"RB6": 0.222, "RB9": 0.499, "DB10": 0.617, "DB12": 0.888, "DB16": 1.578, "DB20": 2.466}


def _sum(rows, *keys):
    return sum(r.qty for r in rows if r.key in keys)


def _first(rows, key):
    return next((r for r in rows if r.key == key), None)


def _flag(r, lv, txt):
    if r is not None and (lv, txt) not in r.flags:
        r.flags.append((lv, txt))


def check_zone(zrows):
    """Ratios inside one zone. Mutates rows (flags / implied)."""
    floor = max(_sum(zrows, "floor_tile"), _sum(zrows, "screed"), _sum(zrows, "wpc"),
                _sum(zrows, "ceiling") if _sum(zrows, "floor_tile") == 0 else 0)
    conc = _sum(zrows, "concrete", "wp_concrete")
    form = _sum(zrows, "formwork")
    reb = sum(r.qty for r in zrows if r.key == "rebar")
    wall = _sum(zrows, "wall")
    plaster = _sum(zrows, "plaster")
    for key, th in (("sand", 0.05), ("lean", 0.05)):
        for r in (x for x in zrows if x.key == key and U_VOL.search(x.unit or "") ):
            area = r.qty / th
            r.implied = f"{r.qty:g} ลบ.ม. ÷ หนา {th*100:g} ซม. = พื้นที่ {area:,.1f} ตร.ม."
            if floor and area > 2.0 * floor:
                _flag(r, ERR, f"เท่ากับพื้น {area:,.0f} ตร.ม. แต่พื้นในโซนนี้มีแค่ ~{floor:,.0f} ตร.ม. (ทรายรองปกติอยู่ใต้ฐานรากเท่านั้น)")
            elif conc and area > 10 * conc:
                _flag(r, WARN, "ทราย/คอนกรีตหยาบมากผิดสัดส่วนกับคอนกรีตโครงสร้าง")
    if conc:
        for r in (x for x in zrows if x.key in ("concrete", "wp_concrete")):
            if floor:
                t = conc / floor
                r.implied = f"คอนกรีตรวม {conc:g} ลบ.ม. ÷ พื้นโซน {floor:,.0f} ตร.ม. = หนาเฉลี่ย {t:.2f} ม."
                if t > 0.6:
                    _flag(r, ERR, f"เท่ากับคอนกรีตหนา {t:.2f} ม. ทั่วทั้งโซน — ขอแจกแจงฐาน/เสา/คาน/พื้น")
        if form:
            k = form / conc
            fr = _first(zrows, "formwork")
            fr.implied = f"ไม้แบบ {form:g} ตร.ม. ÷ คอนกรีต {conc:g} ลบ.ม. = {k:.1f} ตร.ม./ลบ.ม."
            if k < 2 or k > 9:
                _flag(fr, WARN, f"สัดส่วนไม้แบบ/คอนกรีต {k:.1f} อยู่นอกช่วงปกติ 2–9 — ข้อใดข้อหนึ่งผิด")
        if reb:
            k = reb / conc
            for r in (x for x in zrows if x.key == "rebar"):
                r.implied = f"เหล็กรวม {reb:,.0f} กก. ÷ คอนกรีต {conc:g} ลบ.ม. = {k:,.0f} กก./ลบ.ม."
            if k > 200:
                big = max((x for x in zrows if x.key == "rebar"), key=lambda x: x.qty)
                _flag(big, ERR, f"เหล็กรวม {k:,.0f} กก./ลบ.ม. (ปกติ 60–180) — แถวนี้ใหญ่สุด {big.qty:,.0f} กก. ขอแจกแจงเหล็ก")
    tie = _first(zrows, "tie")
    if tie and reb:
        p = tie.qty / reb * 100
        tie.implied = f"ลวดผูก = {p:.1f}% ของเหล็กเสริม"
        if p > 7:
            _flag(tie, WARN, f"ลวดผูก {p:.1f}% ของเหล็ก (ปกติ 1.5–5%)")
    if wall:
        wr = _first(zrows, "wall")
        wr.implied = f"ผนัง {wall:g} ตร.ม. ÷ สูง 3.0 ม. = ผนังยาว {wall/3:,.1f} ม."
        if floor and wall / floor > 5:
            _flag(wr, ERR, f"ผนัง {wall:g} ตร.ม. = {wall/floor:.1f} เท่าของพื้นโซน ({floor:,.0f}) ปกติ 1.5–3.5 — วัดผนังจริงจากแปลน")
        if plaster:
            k = plaster / wall
            pr = _first(zrows, "plaster")
            pr.implied = f"ฉาบ/ผนัง = {k:.2f} เท่า"
            if k < 0.9 or k > 2.15:
                _flag(pr, WARN, f"ฉาบ {plaster:g} เทียบผนัง {wall:g} = {k:.2f} เท่า (ควรได้ 1 หรือ 2 เท่า)")
    skim = _sum(zrows, "skim")
    if skim and plaster and skim > plaster * 1.05:
        _flag(_first(zrows, "skim"), WARN, f"สกิม {skim:g} มากกว่าฉาบ {plaster:g} — สกิมต้องไม่เกินฉาบ")
    if skim and plaster and abs(skim - plaster) < 0.01 and (_sum(zrows, "wall_tile") > 0):
        _flag(_first(zrows, "skim"), WARN, "สกิม = ฉาบ ทั้งที่มีผนังปูกระเบื้อง — ส่วนที่ปูกระเบื้องไม่ต้องสกิม")
    prim, paint = _sum(zrows, "primer"), _sum(zrows, "paint")
    if prim and paint and abs(prim - paint) > 0.1 * max(prim, paint):
        _flag(_first(zrows, "primer"), WARN, f"สีรองพื้น {prim:g} ไม่เท่าสีจริง {paint:g}")
    tiles = _sum(zrows, "floor_tile") + _sum(zrows, "wall_tile")
    adh = _sum(zrows, "adhesive")
    if adh and tiles and abs(adh - tiles) > 0.1 * tiles:
        _flag(_first(zrows, "adhesive"), WARN, f"ปูนกาว/ยาแนว {adh:g} ไม่เท่ากระเบื้องรวม {tiles:g}")
    scr, ft = _sum(zrows, "screed"), _sum(zrows, "floor_tile") + _sum(zrows, "wpc")
    if scr and ft and scr > ft * 1.1:
        _flag(_first(zrows, "screed"), WARN, f"เทปรับระดับ {scr:g} มากกว่าพื้นที่ปูผิว {ft:g}")
    sb, wpc = _sum(zrows, "steelbox"), _sum(zrows, "wpc")
    if sb and wpc:
        k = sb / wpc
        r = _first(zrows, "steelbox")
        r.implied = f"เหล็กโครงพื้น {k:.1f} กก./ตร.ม. ของ WPC"
        if k > 25 or k < 6:
            _flag(r, WARN, f"เหล็กโครง {k:.1f} กก./ตร.ม. (ปกติ 8–20)")


def check_across_zones(rows):
    """A zone whose ratio is far from the other zones (e.g. DB12 kg per m3)."""
    zones = defaultdict(list)
    for r in rows:
        zones[(r.source, r.sheet, r.zone)].append(r)
    per = {}
    for z, zr in zones.items():
        conc = _sum(zr, "concrete", "wp_concrete")
        if conc <= 0:
            continue
        for d in {x.dia for x in zr if x.key == "rebar" and x.dia}:
            per.setdefault(d, []).append((z, sum(x.qty for x in zr if x.dia == d) / conc,
                                          next(x for x in zr if x.dia == d)))
    for d, lst in per.items():
        if len(lst) < 3:
            continue
        for z, k, r in lst:
            others = [kk for zz, kk, _ in lst if zz != z]
            m = median(others)
            if m > 0 and k > 4 * m and k > 40:
                _flag(r, ERR, f"{d} {k:,.0f} กก./ลบ.ม. — {k/m:.0f} เท่าของโซนอื่น (มัธยฐาน {m:,.0f}) ต้องขอแจกแจง")


def find_lots(rows):
    """Lot rows whose material/labour amount = round % of the sibling rows above (same zone)."""
    out = []
    by_zone = defaultdict(list)
    for r in rows:
        by_zone[(r.source, r.sheet, r.zone)].append(r)
    for zr in by_zone.values():
        start = 0
        for i, r in enumerate(zr):
            if r.key != "lot" or not (r.mat or r.lab):
                continue
            for lo in range(start, i):          # try the siblings from every earlier start
                sib = [x for x in zr[lo:i] if x.key != "lot"]
                if not sib:
                    continue
                sm = sum(x.qty * x.mat for x in sib)
                sl = sum(x.qty * x.lab for x in sib)
                pm = _round_pct(r.qty * r.mat, sm)
                pl = _round_pct(r.qty * r.lab, sl)
                if (pm is not None or not r.mat) and (pl is not None or not r.lab) and (pm or pl):
                    r.lot_pct = f"วัสดุ {pm or 0:g}% + ค่าแรง {pl or 0:g}% ของ{_rng(sib)}"
                    out.append({"row": r, "siblings": sib, "pm": pm or 0, "pl": pl or 0})
                    break
            start = i + 1
    return out


def _round_pct(amount, base):
    if not base or not amount:
        return None
    p = amount / base * 100
    for step in (5, 1, 0.5):
        q = round(p / step) * step
        if 0 < q <= 100 and abs(base * q / 100 - amount) <= max(1.0, amount * 0.0005):
            return q
    return None


def _rng(sib):
    return f"แถว {sib[0].row}–{sib[-1].row}" if len(sib) > 1 else f"แถว {sib[0].row}"


def _norm(s):
    s = re.sub(r"[^0-9a-zก-๙]+", " ", s.lower())
    return " ".join(w for w in s.split() if len(w) > 1 or w.isdigit())


CONCEPTS = {
    "aircon": r"(แอร์|air ?con|\bac\b|a/c)", "kitchen": r"(ครัว|kitchen)", "move": r"(ย้าย|move|relocat)",
    "remove": r"(รื้อ|remove|demolish|สกัด)", "bath": r"(ห้องน้ำ|bath|toilet|wc)", "switch": r"(สวิตช์|switch)",
    "socket": r"(เต้ารับ|ปลั๊ก|socket|outlet)", "light": r"(โคม|ไฟ|light|lamp|led)", "pipe": r"(ท่อ|pipe)",
    "water": r"(น้ำ|water)", "tile": r"(กระเบื้อง|til)", "wall": r"(ผนัง|wall)", "floor": r"(พื้น|floor)",
    "ceiling": r"(ฝ้า|ceiling)", "door": r"(ประตู|door)", "window": r"(หน้าต่าง|window)", "paint": r"(สี|paint)",
    "sink": r"(ซิงค์|อ่างล้าง|sink|basin)", "counter": r"(เคาน์เตอร์|เค้าเตอร์|counter)",
}


def _concepts(desc):
    return {k for k, rx in CONCEPTS.items() if re.search(rx, desc, re.I)}


def find_duplicates(rows):
    """Same item (normalised text), same quantity and amount in another zone/sheet/file."""
    seen = defaultdict(list)
    for r in rows:
        if r.amount <= 0 or r.key in ("nail", "tie"):
            continue
        seen[(_norm(r.desc)[:40], round(r.qty, 2), round(r.amount, 0))].append(r)
    dups = []
    for k, lst in seen.items():
        places = {(x.source, x.sheet) for x in lst}
        if len(lst) > 1 and len(places) > 1:
            dups.append(lst)
            for x in lst:
                others = ", ".join(o.ref for o in lst if o is not x)
                _flag(x, WARN, f"ชื่อ ปริมาณ และยอดเงินเท่ากับ {others} — อาจคิดซ้ำ (ถ้าเป็นของชิ้นเดียวกัน)")
    # same amount + shared keyword across different files (e.g. AC relocation 6,000 in BOQ and VO)
    by_amt = defaultdict(list)
    for r in rows:
        if r.amount >= 1000:
            by_amt[round(r.amount, 0)].append(r)
    for amt, lst in by_amt.items():
        srcs = {x.source for x in lst}
        if len(srcs) < 2:
            continue
        for i, a in enumerate(lst):
            for b in lst[i + 1:]:
                if a.source == b.source:
                    continue
                wa, wb = set(_norm(a.desc).split()), set(_norm(b.desc).split())
                if len(wa & wb) >= 2 or len(_concepts(a.desc) & _concepts(b.desc)) >= 2:
                    dups.append([a, b])
                    _flag(a, WARN, f"ยอด {amt:,.0f} และชื่องานคล้าย {b.ref} — อาจคิดซ้ำข้ามไฟล์")
                    _flag(b, WARN, f"ยอด {amt:,.0f} และชื่องานคล้าย {a.ref} — อาจคิดซ้ำข้ามไฟล์")
    return dups


def find_rate_diffs(rows):
    grp = defaultdict(list)
    for r in rows:
        if r.rate > 0 and r.key not in ("lot",):
            grp[(r.source, r.sheet, _norm(r.desc)[:60], (r.unit or "").lower())].append(r)
    out = []
    for k, lst in grp.items():
        rates = {round(x.rate, 2) for x in lst}
        if len(rates) > 1:
            lo = min(rates)
            for x in lst:
                if x.rate > lo:
                    diff = (x.rate - lo) * x.qty
                    out.append((x, lo, diff))
                    _flag(x, INFO, f"รายการเดียวกันที่อื่นราคา {lo:,.2f}/หน่วย ถูกกว่า {x.rate - lo:,.2f} (รวม {diff:,.0f})")
    return out


def run_audit(paths, labels=None):
    """paths: list of xlsx. Returns dict with rows, lots, dups, rate_diffs, skipped."""
    rows, skipped = [], []
    for i, p in enumerate(paths):
        rr, sk = read_workbook(p, (labels or [None] * len(paths))[i])
        rows += rr
        skipped += [f"{p}: {s}" for s in sk]
    zones = defaultdict(list)
    for r in rows:
        zones[(r.source, r.sheet, r.zone)].append(r)
    for zr in zones.values():
        check_zone(zr)
    check_across_zones(rows)
    lots = find_lots(rows)
    dups = find_duplicates(rows)
    rdiff = find_rate_diffs(rows)
    return {"rows": rows, "lots": lots, "dups": dups, "rate_diffs": rdiff, "skipped": skipped}


def match_project(result, project):
    """Fill 'ปริมาณที่เราวัด' from a BOQ Robot project when an item name matches closely."""
    import difflib
    from .takeoff import compute
    ours = [(_norm(r.item["name"]), r) for r in compute(project) if r.lines]
    out = {}
    for x in result["rows"]:
        n = _norm(x.desc)
        best, score = None, 0
        for nm, r in ours:
            s = difflib.SequenceMatcher(None, n, nm).ratio()
            if s > score:
                best, score = r, s
        if best is not None and score >= 0.75:
            out[id(x)] = (round(best.qty, 2), f"{best.item['code']} {best.item['name']} ({score:.0%})")
    return out


# ---------------------------------------------------------------- export
def export_audit(result, path, our_qty=None):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter as CL
    from openpyxl.worksheet.datavalidation import DataValidation
    our_qty = our_qty or {}
    f = Font(name="Tahoma", size=10)
    fb = Font(name="Tahoma", size=10, bold=True, color="FFFFFF")
    head = PatternFill("solid", fgColor="2F5597")
    fill = {ERR: PatternFill("solid", fgColor="F8CBAD"), WARN: PatternFill("solid", fgColor="FFF2CC"),
            INFO: PatternFill("solid", fgColor="DDEBF7")}
    thin = Side(style="thin", color="BFBFBF")
    bd = Border(left=thin, right=thin, top=thin, bottom=thin)
    MF = '#,##0.00;[Red]-#,##0.00'
    wb = Workbook()
    s = wb.active
    s.title = "สรุป"
    ws = wb.create_sheet("ตรวจรายแถว")
    cols = ["ไฟล์", "ชีท", "แถว", "โซน", "รายการ", "หน่วย", "ปริมาณผู้รับเหมา", "ค่าของ/หน่วย", "ค่าแรง/หน่วย",
            "ยอดผู้รับเหมา", "หมวดที่จับได้", "คิดย้อน (ปริมาณนี้เท่ากับ)", "ระดับ", "ข้อสังเกต",
            "ปริมาณที่เราวัด", "ที่มาปริมาณเรา", "ผลตรวจ", "ส่วนต่างเงิน", "ยอดที่ควรจ่าย"]
    widths = [14, 12, 6, 18, 44, 7, 11, 11, 11, 13, 11, 40, 8, 60, 11, 26, 12, 13, 14]
    ws.append(cols)
    for i, (c, w) in enumerate(zip(cols, widths), 1):
        x = ws.cell(1, i)
        x.font, x.fill, x.border = fb, head, bd
        x.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        ws.column_dimensions[CL(i)].width = w
    ws.row_dimensions[1].height = 34
    ws.freeze_panes = "F2"
    order = {ERR: 0, WARN: 1, INFO: 2, "": 3}
    rws = result["rows"]
    for x in rws:
        lv = min((fl[0] for fl in x.flags), key=lambda v: order[v], default="")
        note = " | ".join(t for _, t in x.flags)
        if x.lot_pct:
            note = (note + " | " if note else "") + f"Lot = {x.lot_pct}"
        oq = our_qty.get(id(x))
        i = ws.max_row + 1
        ws.append([x.source, x.sheet, x.row, x.zone, x.desc, x.unit, x.qty, x.mat, x.lab,
                   f"=ROUND(G{i}*(H{i}+I{i}),2)", x.key, x.implied, lv, note,
                   oq[0] if oq else None, oq[1] if oq else None,
                   "ยังไม่ตรวจ",
                   f'=IF(AND(ISNUMBER(O{i}),OR(Q{i}="ปริมาณเกิน",Q{i}="ปริมาณขาด",Q{i}="ซ้ำ")),ROUND((O{i}-G{i})*(H{i}+I{i}),2),0)',
                   f"=J{i}+R{i}"])
        for c in range(1, len(cols) + 1):
            cell = ws.cell(i, c)
            cell.font, cell.border = f, bd
            cell.alignment = Alignment(vertical="top", wrap_text=c in (5, 12, 14, 16))
            if lv and c in (13, 14):
                cell.fill = fill[lv]
        for c in (7, 8, 9, 10, 15, 18, 19):
            ws.cell(i, c).number_format = MF
    last = ws.max_row
    dv = DataValidation(type="list", formula1='"ยังไม่ตรวจ,ตรง,ปริมาณเกิน,ปริมาณขาด,ซ้ำ,ถามวิธีคิด"')
    ws.add_data_validation(dv)
    dv.add(f"Q2:Q{max(last, 2)}")
    ws.auto_filter.ref = f"A1:S{last}"

    # lots
    wl = wb.create_sheet("Lot คิดเป็น %")
    wl.append(["ไฟล์", "ชีท", "แถว", "รายการ", "ยอด Lot", "% วัสดุ", "% ค่าแรง", "แถวที่เป็นฐาน",
               "ฐานวัสดุ", "ฐานค่าแรง", "หมายเหตุ"])
    for L in result["lots"]:
        r = L["row"]
        sm = sum(x.qty * x.mat for x in L["siblings"])
        sl = sum(x.qty * x.lab for x in L["siblings"])
        wl.append([r.source, r.sheet, r.row, r.desc, r.amount, L["pm"], L["pl"], _rng(L["siblings"]),
                   sm, sl, "พิสูจน์แล้ว (ตรงทุกบาท) — ถ้าแก้ปริมาณแถวฐาน ให้คิด Lot ใหม่ด้วย % นี้"])
    # duplicates
    wd = wb.create_sheet("อาจคิดซ้ำ")
    wd.append(["กลุ่ม", "ไฟล์", "ชีท", "แถว", "โซน", "รายการ", "ปริมาณ", "ยอด"])
    for g, lst in enumerate(result["dups"], 1):
        for x in lst:
            wd.append([g, x.source, x.sheet, x.row, x.zone, x.desc, x.qty, x.amount])
    # rate diffs
    wr = wb.create_sheet("ราคาต่อหน่วยไม่เท่ากัน")
    wr.append(["ไฟล์", "ชีท", "แถว", "รายการ", "ปริมาณ", "ราคานี้", "ราคาต่ำสุดของรายการเดียวกัน", "ส่วนต่างรวม"])
    for x, lo, diff in result["rate_diffs"]:
        wr.append([x.source, x.sheet, x.row, x.desc, x.qty, x.rate, lo, diff])
    for w in (wl, wd, wr):
        for c in range(1, w.max_column + 1):
            w.cell(1, c).font, w.cell(1, c).fill = fb, head
            w.column_dimensions[CL(c)].width = 16 if c != 4 and c != 6 else 44
        for row in w.iter_rows(min_row=2):
            for cell in row:
                cell.font = f
                if isinstance(cell.value, float):
                    cell.number_format = MF
        w.freeze_panes = "A2"

    # summary
    n = {ERR: 0, WARN: 0, INFO: 0}
    for x in rws:
        for lv in {fl[0] for fl in x.flags}:
            n[lv] += 1
    s.append(["ตรวจ BOQ ผู้รับเหมา (คิดย้อน) — BOQ Robot"])
    s["A1"].font = Font(name="Tahoma", size=13, bold=True)
    s.append([])
    s.append(["จำนวนแถวที่อ่านได้", len(rws)])
    s.append(["ยอดตามผู้รับเหมา (ก่อน OH/VAT)", f"=SUM('ตรวจรายแถว'!J2:J{last})"])
    s.append(["แถวสงสัยมาก (สีแดง)", n[ERR]])
    s.append(["แถวสงสัย (สีเหลือง)", n[WARN]])
    s.append(["ข้อมูล (สีฟ้า)", n[INFO]])
    s.append(["Lot ที่พิสูจน์ % ได้", len(result["lots"])])
    s.append(["กลุ่มที่อาจคิดซ้ำ", len(result["dups"])])
    s.append(["ส่วนต่างเงินจากผลตรวจ (ใส่ปริมาณเรา + เลือกผลตรวจ)", f"=SUM('ตรวจรายแถว'!R2:R{last})"])
    s.append(["ยอดที่ควรจ่าย (ก่อน OH/VAT)", f"=SUM('ตรวจรายแถว'!S2:S{last})"])
    s.append([])
    s.append(["วิธีใช้"])
    for t in ["1. เริ่มจากแถวสีแดง/เหลืองในชีท 'ตรวจรายแถว' — คอลัมน์ 'คิดย้อน' บอกว่าปริมาณนั้นเท่ากับขนาดเท่าไหร่",
              "2. วัดของจริงจากแบบ (ในโปรแกรม) แล้วใส่ 'ปริมาณที่เราวัด' + เลือก 'ผลตรวจ' — ยอดเงินคำนวณเอง",
              "3. ผนัง: สูงตามรูปด้าน ถ้าไม่มีใช้ระดับฝ้า หักประตูหน้าต่าง • ฉาบ = สกิม ยกเว้นส่วนปูกระเบื้อง • สีรองพื้น = สีจริง",
              "4. ชีท Lot: ถ้าแก้ปริมาณแถวฐาน ให้คิด Lot ใหม่ด้วย % ที่พิสูจน์ได้",
              "5. ทุกข้อเป็น 'ข้อสงสัย' ให้ยืนยันกับแบบก่อน ห้ามหักเงินจากธงอย่างเดียว"]:
        s.append([t])
    s.column_dimensions["A"].width = 60
    s.column_dimensions["B"].width = 20
    for row in s.iter_rows():
        for cell in row:
            if cell.row > 1:
                cell.font = f
            if cell.column == 2:
                cell.number_format = MF if cell.row in (4, 10, 11) else "0"
    if result["skipped"]:
        s.append([])
        s.append(["ชีทที่ข้าม (หาแถวหัวตารางไม่เจอ): " + ", ".join(result["skipped"])])
    wb.save(path)
    return path
