"""Project storage: a folder with project.db (SQLite) + copied drawings + exports + logs."""
import json
import logging
import shutil
import sqlite3
import time
from pathlib import Path

from .library import DEFAULT_ITEMS, COLORS

log = logging.getLogger("boqrobot")

SCHEMA_VERSION = 1
SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS drawings(
  id INTEGER PRIMARY KEY, file_name TEXT, stored TEXT, number TEXT, title TEXT,
  discipline TEXT DEFAULT 'ARCH', revision TEXT DEFAULT '', sort INTEGER DEFAULT 0,
  imported_at TEXT);
CREATE TABLE IF NOT EXISTS pages(
  id INTEGER PRIMARY KEY, drawing_id INTEGER REFERENCES drawings(id) ON DELETE CASCADE,
  page_no INTEGER, width REAL, height REAL, mm_per_pt REAL, scale_label TEXT DEFAULT '',
  scale_source TEXT DEFAULT '', title TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS items(
  id INTEGER PRIMARY KEY, code TEXT, sort INTEGER DEFAULT 0, category TEXT, name TEXT,
  unit TEXT, mode TEXT, formula TEXT, H REAL DEFAULT 0, T REAL DEFAULT 0, W REAL DEFAULT 0,
  F REAL DEFAULT 1, waste REAL DEFAULT 0, mat_rate REAL DEFAULT 0, lab_rate REAL DEFAULT 0,
  manual_qty REAL DEFAULT 0, color TEXT, verified INTEGER DEFAULT 0, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS measurements(
  id INTEGER PRIMARY KEY, item_id INTEGER REFERENCES items(id) ON DELETE CASCADE,
  page_id INTEGER REFERENCES pages(id) ON DELETE CASCADE, kind TEXT, points TEXT,
  sign INTEGER DEFAULT 1, H REAL, T REAL, W REAL, repeat REAL DEFAULT 1,
  note TEXT DEFAULT '', created_at TEXT);
CREATE TABLE IF NOT EXISTS audit(ts TEXT, action TEXT, detail TEXT);
"""

PROJECT_FIELDS = ["name", "client", "address", "number", "notes", "created", "modified"]


def safe_name(s):
    """Keep Thai/latin letters incl. vowel & tone marks; replace only characters Windows forbids."""
    import unicodedata
    out = "".join(c if (unicodedata.category(c)[0] in "LMN" or c in "-_ .()") else "_" for c in s)
    return out.strip(" .") or "file"


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def page_meta(page):
    """(title, scale suggestion label, source) from the sheet's title block."""
    from .scale import sheet_info, detect_scale
    info = sheet_info(page)
    title = " ".join(x for x in (info["number"], info["name"]) if x)
    det = info["scale"] or detect_scale(page)
    if det:
        return title, f"1:{det:g} (อ่านจากแบบ - ยังไม่ยืนยัน)", "detected"
    return title, "", ""


class Project:
    DB = "project.db"

    def __init__(self, folder):
        self.folder = Path(folder)
        if not (self.folder / self.DB).exists():
            raise FileNotFoundError(f"ไม่พบไฟล์โปรเจคใน {self.folder}")
        self.con = sqlite3.connect(self.folder / self.DB)
        self.con.row_factory = sqlite3.Row
        self.con.execute("PRAGMA foreign_keys=ON")
        self.con.executescript(SCHEMA)
        cols = {r[1] for r in self.con.execute("PRAGMA table_info(measurements)")}
        if "source" not in cols:  # v1.2: who created the measurement (manual / ai / tag)
            self.con.execute("ALTER TABLE measurements ADD COLUMN source TEXT DEFAULT 'manual'")
        for d in ("drawings", "exports", "logs", "backups"):
            (self.folder / d).mkdir(exist_ok=True)

    # ---------- lifecycle ----------
    @classmethod
    def create(cls, folder, name, client="", address="", number="", seed_library=True):
        folder = Path(folder)
        if (folder / cls.DB).exists():
            raise FileExistsError("โฟลเดอร์นี้มีโปรเจคอยู่แล้ว")
        folder.mkdir(parents=True, exist_ok=True)
        sqlite3.connect(folder / cls.DB).close()
        p = cls(folder)
        info = {"name": name, "client": client, "address": address, "number": number,
                "notes": "", "created": now(), "modified": now(),
                "schema": str(SCHEMA_VERSION)}
        p.con.executemany("INSERT OR REPLACE INTO meta VALUES(?,?)", info.items())
        if seed_library:
            for row in DEFAULT_ITEMS:
                p.add_item(*row)
        p.audit("create_project", name)
        p.con.commit()
        log.info("project created %s", folder)
        return p

    def close(self):
        try:
            self.con.commit()
            self.con.close()
        except Exception:
            pass

    def backup(self):
        dst = self.folder / "backups" / f"project_{time.strftime('%Y%m%d_%H%M%S')}.db"
        b = sqlite3.connect(dst)
        self.con.backup(b)
        b.close()
        return dst

    def audit(self, action, detail=""):
        self.con.execute("INSERT INTO audit VALUES(?,?,?)", (now(), action, str(detail)))

    def touch(self):
        self.con.execute("INSERT OR REPLACE INTO meta VALUES('modified',?)", (now(),))
        self.con.commit()

    # ---------- meta ----------
    def info(self):
        return {r["key"]: r["value"] for r in self.con.execute("SELECT * FROM meta")}

    def set_info(self, **kw):
        self.con.executemany("INSERT OR REPLACE INTO meta VALUES(?,?)", kw.items())
        self.touch()

    # ---------- drawings ----------
    def import_drawing(self, src, discipline="ARCH", progress=None):
        import fitz
        src = Path(src)
        if not src.exists():
            raise FileNotFoundError(str(src))
        ext = src.suffix.lower()
        if ext not in (".pdf", ".jpg", ".jpeg", ".png"):
            raise ValueError("รองรับเฉพาะไฟล์ PDF, JPG, PNG")
        stem = safe_name(src.stem)[:60]
        dst = self.folder / "drawings" / f"{int(time.time()*1000)}_{stem}.pdf"
        try:
            if ext == ".pdf":
                shutil.copy2(src, dst)
                doc = fitz.open(dst)
            else:
                img = fitz.open(src)
                pdf = fitz.open("pdf", img.convert_to_pdf())
                pdf.save(dst)
                doc = fitz.open(dst)
            if doc.page_count == 0:
                raise ValueError("ไฟล์ไม่มีหน้า")
        except Exception as e:
            dst.unlink(missing_ok=True)
            raise ValueError(f"เปิดไฟล์ไม่ได้ (ไฟล์อาจเสียหรือมีรหัสผ่าน): {e}") from e
        sort = self.con.execute("SELECT COALESCE(MAX(sort),0)+1 FROM drawings").fetchone()[0]
        cur = self.con.execute(
            "INSERT INTO drawings(file_name,stored,number,title,discipline,sort,imported_at)"
            " VALUES(?,?,?,?,?,?,?)",
            (src.name, dst.name, "", src.stem, discipline, sort, now()))
        did = cur.lastrowid
        for i, page in enumerate(doc):
            if progress:
                progress(i + 1, doc.page_count)
            r = page.rect
            title, label, src_ = page_meta(page)
            self.con.execute(
                "INSERT INTO pages(drawing_id,page_no,width,height,mm_per_pt,scale_label,scale_source,title)"
                " VALUES(?,?,?,?,?,?,?,?)", (did, i + 1, r.width, r.height, None, label, src_, title))
        doc.close()
        self.audit("import_drawing", src.name)
        self.touch()
        log.info("imported %s", src)
        return did

    def drawings(self):
        return self.con.execute("SELECT * FROM drawings ORDER BY sort,id").fetchall()

    def drawing(self, did):
        return self.con.execute("SELECT * FROM drawings WHERE id=?", (did,)).fetchone()

    def drawing_path(self, did):
        return self.folder / "drawings" / self.drawing(did)["stored"]

    def update_drawing(self, did, **kw):
        cols = ",".join(f"{k}=?" for k in kw)
        self.con.execute(f"UPDATE drawings SET {cols} WHERE id=?", (*kw.values(), did))
        self.touch()

    def move_drawing(self, did, delta):
        rows = [r["id"] for r in self.drawings()]
        i = rows.index(did)
        j = max(0, min(len(rows) - 1, i + delta))
        rows[i], rows[j] = rows[j], rows[i]
        for s, rid in enumerate(rows):
            self.con.execute("UPDATE drawings SET sort=? WHERE id=?", (s, rid))
        self.touch()

    def delete_drawing(self, did):
        path = self.drawing_path(did)
        self.con.execute("DELETE FROM drawings WHERE id=?", (did,))
        self.audit("delete_drawing", did)
        self.touch()
        try:
            path.unlink()
        except OSError:
            log.warning("could not delete %s", path)

    def pages(self, did):
        return self.con.execute("SELECT * FROM pages WHERE drawing_id=? ORDER BY page_no",
                                (did,)).fetchall()

    def page(self, pid):
        return self.con.execute("SELECT * FROM pages WHERE id=?", (pid,)).fetchone()

    def fill_page_titles(self, did, progress=None):
        """For projects imported before sheet reading existed."""
        import fitz
        doc = fitz.open(self.drawing_path(did))
        for p in self.pages(did):
            if progress:
                progress(p["page_no"], doc.page_count)
            title, label, src_ = page_meta(doc[p["page_no"] - 1])
            self.con.execute("UPDATE pages SET title=? WHERE id=?", (title, p["id"]))
            if not p["mm_per_pt"]:
                self.con.execute("UPDATE pages SET scale_label=?, scale_source=? WHERE id=?",
                                 (label, src_, p["id"]))
        doc.close()
        self.touch()

    def set_scale(self, pid, mm_per_pt, label, source):
        self.con.execute("UPDATE pages SET mm_per_pt=?,scale_label=?,scale_source=? WHERE id=?",
                         (mm_per_pt, label, source, pid))
        self.audit("set_scale", f"page {pid}: {label}")
        self.touch()

    # ---------- items ----------
    def add_item(self, category, name, unit, mode, formula, H=0, T=0, W=0, F=1, waste=0,
                 mat_rate=0, lab_rate=0, note=""):
        n = self.con.execute("SELECT COUNT(*) FROM items").fetchone()[0]
        cur = self.con.execute(
            "INSERT INTO items(category,name,unit,mode,formula,H,T,W,F,waste,mat_rate,lab_rate,"
            "color,sort,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (category, name, unit, mode, formula, H, T, W, F, waste, mat_rate, lab_rate,
             COLORS[n % len(COLORS)], n, note))
        self.renumber()
        self.touch()
        return cur.lastrowid

    def items(self):
        return self.con.execute("SELECT * FROM items ORDER BY sort,id").fetchall()

    def item(self, iid):
        return self.con.execute("SELECT * FROM items WHERE id=?", (iid,)).fetchone()

    def update_item(self, iid, **kw):
        cols = ",".join(f"{k}=?" for k in kw)
        self.con.execute(f"UPDATE items SET {cols} WHERE id=?", (*kw.values(), iid))
        if "category" in kw:
            self.renumber()
        self.touch()

    def delete_item(self, iid):
        self.con.execute("DELETE FROM items WHERE id=?", (iid,))
        self.audit("delete_item", iid)
        self.renumber()
        self.touch()

    def categories(self):
        seen = []
        for r in self.items():
            if r["category"] not in seen:
                seen.append(r["category"])
        return seen

    def renumber(self):
        """Code = category order . item order, e.g. 2.03. Items grouped by category."""
        rows = self.con.execute("SELECT id,category FROM items ORDER BY sort,id").fetchall()
        cats = []
        for r in rows:
            if r["category"] not in cats:
                cats.append(r["category"])
        s = 0
        for ci, c in enumerate(cats, 1):
            k = 0
            for r in rows:
                if r["category"] == c:
                    k += 1
                    self.con.execute("UPDATE items SET code=?, sort=? WHERE id=?",
                                     (f"{ci}.{k:02d}", s, r["id"]))
                    s += 1

    # ---------- measurements ----------
    def add_measurement(self, item_id, page_id, kind, points, sign=1, note="", source="manual"):
        cur = self.con.execute(
            "INSERT INTO measurements(item_id,page_id,kind,points,sign,note,created_at,source)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (item_id, page_id, kind, json.dumps([list(map(float, p)) for p in points]),
             sign, note, now(), source))
        self.touch()
        return cur.lastrowid

    def measurements(self, page_id=None, item_id=None):
        q, a = "SELECT * FROM measurements WHERE 1=1", []
        if page_id is not None:
            q += " AND page_id=?"
            a.append(page_id)
        if item_id is not None:
            q += " AND item_id=?"
            a.append(item_id)
        return self.con.execute(q + " ORDER BY id", a).fetchall()

    def measurement(self, mid):
        return self.con.execute("SELECT * FROM measurements WHERE id=?", (mid,)).fetchone()

    def update_measurement(self, mid, **kw):
        if "points" in kw:
            kw["points"] = json.dumps([list(map(float, p)) for p in kw["points"]])
        cols = ",".join(f"{k}=?" for k in kw)
        self.con.execute(f"UPDATE measurements SET {cols} WHERE id=?", (*kw.values(), mid))
        self.touch()

    def delete_measurement(self, mid):
        self.con.execute("DELETE FROM measurements WHERE id=?", (mid,))
        self.touch()
