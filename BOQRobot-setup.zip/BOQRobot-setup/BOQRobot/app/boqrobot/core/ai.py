"""AI takeoff (Claude API). Architecture rule: the AI only *finds and labels geometry*
(room outlines, wall runs, symbols) and proposes BOQ item names from the sheet legend.
Every quantity is still calculated by the deterministic core (scale x geometry x formula),
AI vertices are snapped to real CAD line endpoints, and everything lands as 'ai' measurements
the user reviews on the drawing. Doors/windows are counted from their text tags (no AI)."""
import base64
import json
import re
import urllib.error
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
MODELS = ["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-4-5-20251001"]
MAX_SIDE = 1568  # API downsizes larger images; send at this size so pixel coords stay exact

PROMPT = """You are a senior Thai quantity surveyor doing a quantity takeoff from ONE construction drawing sheet.
Sheet: {title}. The image is {w} x {h} pixels. Pixel (0,0) is top-left.
Text found on the sheet (legend/spec tables, room tags, dimension numbers) is listed after the image.

Find the measurable work on this sheet and return its GEOMETRY in image pixel coordinates.
I will compute all quantities myself from the geometry and the drawing scale - do NOT compute areas or lengths.

Rules
- Floor plans with floor finish tags (e.g. F-01, F-05): one polygon per room/zone, following the INSIDE face of the walls,
  tagged with that room's floor code. Use enough vertices for L-shapes. Skip furniture and tile pattern lines.
- The same room polygon may also carry the wall-paint item and the ceiling item if the sheet shows them (list several item keys).
- Walls: a polyline along the centre of each wall run, grouped by wall type/finish if the sheet distinguishes them.
- Ceiling plans (C-xx codes): one polygon per ceiling zone with its code.
- Roof plans: polygons per roof material zone.
- Sloped / gable ceilings and roofs: the polygon is the PLAN outline; also give "factor" = real surface / plan area
  (e.g. 1.11), computed from the levels/dimensions written on the drawing (ridge/eave levels, slope angle, section),
  and add a Thai warning saying which numbers you used. Omit "factor" for flat surfaces.
- Electrical / sanitary plans: a point for each symbol you can identify, grouped by symbol type.
- Do NOT return doors or windows (they are counted from their D/W tags separately).
- Ignore key plans, title block, legends, elevations of details, and anything outside the main drawing.
- items: Thai BOQ names built from the legend spec (type, brand, code, size), e.g.
  "ปูกระเบื้องพื้น F-05 BASIQ 1254633 20x120 ซม.". category must be one of:
  งานพื้น, งานผนัง, งานสี, งานฝ้า, งานหลังคา, งานไฟฟ้า, งานประปา-สุขภัณฑ์, งานอื่นๆ.
  measure: "area" (polygon, unit ตร.ม.), "length" (polyline, unit ม.), "count" (points, unit จุด/ชุด).
  For wall paint / wall tiles measured from a room polygon use measure "perimeter" and give height_m (floor to ceiling) if the
  sheet or its notes show it, else 0.
- If something is uncertain, still return it but add a short Thai warning.

Return ONLY this JSON (no markdown):
{{"items":[{{"key":"F-05","category":"งานพื้น","name":"...","measure":"area","height_m":0}}],
 "objects":[{{"items":["F-05","2.1"],"type":"polygon","points":[[x,y],[x,y],[x,y]],"note":"ห้องนอน 1"}},
            {{"items":["C-03"],"type":"polygon","points":[[x,y],[x,y],[x,y]],"note":"ฝ้าลาดเอียง ห้องนั่งเล่น","factor":1.11}}],
 "warnings":["..."]}}

Sheet text:
{text}"""


class AIError(RuntimeError):
    pass


def render_page(page, max_side=MAX_SIDE):
    """PNG of the sheet without the title block strip; returns (png, clip, px_per_pt)."""
    import fitz
    r = page.rect
    clip = fitz.Rect(r.x0, r.y0, r.x0 + r.width * 0.87, r.y1) if r.width > r.height else r
    z = max_side / max(clip.width, clip.height)
    pix = page.get_pixmap(matrix=fitz.Matrix(z, z), clip=clip, alpha=False)
    return pix.tobytes("png"), clip, z, (pix.width, pix.height)


def sheet_text(page, clip, limit=6000):
    words = page.get_text("words", clip=clip)
    lines, cur, last = [], [], None
    for w in sorted(words, key=lambda w: (w[5], w[6], w[7])):
        key = (w[5], w[6])
        if last is not None and key != last:
            lines.append(" ".join(cur))
            cur = []
        cur.append(w[4])
        last = key
    if cur:
        lines.append(" ".join(cur))
    txt = "\n".join(l for l in lines if l.strip())
    return txt[:limit]


def call_claude(api_key, model, png, prompt, timeout=300):
    body = {
        "model": model, "max_tokens": 16000,
        "messages": [{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": "image/png",
                                         "data": base64.b64encode(png).decode()}},
            {"type": "text", "text": prompt}]}],
    }
    req = urllib.request.Request(API_URL, data=json.dumps(body).encode(), method="POST", headers={
        "x-api-key": api_key.strip(), "anthropic-version": "2023-06-01",
        "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read())
    except urllib.error.HTTPError as e:
        msg = e.read().decode(errors="ignore")[:300]
        if e.code == 401:
            raise AIError("API key ไม่ถูกต้อง") from e
        if e.code == 429:
            raise AIError("เรียก AI ถี่เกินไป/เครดิตหมด ลองใหม่อีกครั้ง") from e
        raise AIError(f"AI ตอบกลับผิดพลาด ({e.code}): {msg}") from e
    except urllib.error.URLError as e:
        raise AIError(f"เชื่อมต่ออินเทอร์เน็ต/AI ไม่ได้: {e.reason}") from e
    text = "".join(c.get("text", "") for c in data.get("content", []) if c.get("type") == "text")
    usage = data.get("usage", {})
    return text, usage


SERVICE_URL = "https://boqrobot.com/api/ai"
SERVICE_MODEL = "claude-sonnet-5-5"


def build_prompt(kind, fields):
    if kind == "takeoff":
        return PROMPT.format(title=str(fields.get("title", ""))[:200], w=int(fields["w"]), h=int(fields["h"]),
                             text=str(fields.get("text", ""))[:6000])
    if kind == "table":
        from .pdfscan import PROMPT as TABLE_PROMPT
        return TABLE_PROMPT.format(page=int(fields["page"]))
    raise AIError("ชนิดงาน AI ไม่ถูกต้อง")


def call_service(kind, png, fields, timeout=320):
    """AI included with BOQ Robot: the seller's server holds the Claude key (never this program)."""
    from . import lic
    from .. import VERSION
    st = lic.status()
    body = {"mid": st["mid"], "code": st["code"], "ver": VERSION, "kind": kind,
            "png": base64.b64encode(png).decode(), "fields": fields}
    req = urllib.request.Request(SERVICE_URL, data=json.dumps(body).encode(), method="POST",
                                 headers={"content-type": "application/json", "user-agent": f"BOQRobot/{VERSION}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read()).get("error", "")
        except Exception:
            msg = ""
        raise AIError(msg or f"บริการ AI ตอบกลับผิดพลาด ({e.code})") from e
    except urllib.error.URLError as e:
        raise AIError(f"เชื่อมต่ออินเทอร์เน็ตไม่ได้: {e.reason}") from e
    return data.get("text", ""), data.get("usage", {})


def run(settings, kind, png, fields):
    """Own API key in settings → call Claude directly; otherwise use the included BOQ Robot AI service."""
    key = (settings or {}).get("api_key", "").strip()
    if key:
        return call_claude(key, settings.get("ai_model", MODELS[0]), png, build_prompt(kind, fields))
    return call_service(kind, png, fields)


def parse_result(text):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise AIError("AI ไม่ได้ส่งผลเป็น JSON")
    try:
        d = json.loads(m.group(0))
    except json.JSONDecodeError as e:
        raise AIError(f"อ่านผล AI ไม่ได้: {e}") from e
    d.setdefault("items", [])
    d.setdefault("objects", [])
    d.setdefault("warnings", [])
    return d


# ---------------- deterministic helpers ----------------
TAG_RE = re.compile(r"^(D|W|DW|SD|WD)\d{1,2}[A-Z]?$")


def door_window_tags(page, clip=None):
    """{'D1': [(x,y),...], 'W3': [...]} from text tags on a plan sheet."""
    out = {}
    for w in page.get_text("words", clip=clip):
        t = w[4].strip().upper()
        if TAG_RE.match(t):
            out.setdefault(t, []).append(((w[0] + w[2]) / 2, (w[1] + w[3]) / 2))
    return out


def vertex_index(page):
    grid = {}
    for d in page.get_drawings():
        for it in d["items"]:
            if it[0] in ("l", "c"):
                pts = (it[1], it[-1])
            elif it[0] == "re":
                r = it[1]
                pts = (r.tl, r.tr, r.bl, r.br)
            else:
                continue
            for q in pts:
                grid.setdefault((int(q.x // 4), int(q.y // 4)), []).append((q.x, q.y))
    return grid


def snap(p, grid, radius_pt):
    if not grid or radius_pt <= 0:
        return p, False
    cx, cy, n = int(p[0] // 4), int(p[1] // 4), int(radius_pt // 4) + 1
    best, bd = None, radius_pt
    for i in range(cx - n, cx + n + 1):
        for j in range(cy - n, cy + n + 1):
            for q in grid.get((i, j), ()):
                d = ((q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2) ** 0.5
                if d < bd:
                    best, bd = q, d
    return (best, True) if best else (p, False)


UNIT = {"area": "ตร.ม.", "length": "ม.", "count": "จุด", "perimeter": "ตร.ม."}
FORMULA = {"area": "A", "length": "L", "count": "N", "perimeter": "L*H"}
MODE = {"area": "AREA", "length": "LENGTH", "count": "COUNT", "perimeter": "AREA"}
KIND = {"polygon": "poly", "polyline": "line", "point": "count"}


def apply_result(project, page_row, result, clip, z, grid=None, snap_mm=300):
    """Create/merge BOQ items and 'ai' measurements. Returns summary dict."""
    items = {i["name"]: i["id"] for i in project.items()}
    by_key = {}
    for it in result["items"]:
        key = str(it.get("key") or it.get("name"))
        name = (it.get("name") or key).strip()
        if name not in items:
            m = it.get("measure", "area")
            items[name] = project.add_item(
                it.get("category") or "งานอื่นๆ", name, UNIT.get(m, "หน่วย"), MODE.get(m, "AREA"),
                FORMULA.get(m, "A"), H=float(it.get("height_m") or 0), note=f"AI: {key}")
        by_key[key] = items[name]
    k = page_row["mm_per_pt"] or 0
    radius = snap_mm / k if k else 0
    n_obj = n_snap = n_pts = 0
    for ob in result["objects"]:
        keys = ob.get("items") or ob.get("item") or []
        keys = [keys] if isinstance(keys, str) else keys
        kind = KIND.get(ob.get("type"), None)
        pts = [(clip.x0 + x / z, clip.y0 + y / z) for x, y in ob.get("points", []) if
               isinstance(x, (int, float)) and isinstance(y, (int, float))]
        need = {"poly": 3, "line": 2, "count": 1}.get(kind)
        if not need or len(pts) < need:
            continue
        if kind != "count":
            snapped = []
            for p in pts:
                q, ok = snap(p, grid, radius)
                snapped.append(q)
                n_snap += ok
                n_pts += 1
            pts = snapped
        note = (ob.get("note") or "")[:80]
        try:
            factor = float(ob.get("factor") or 1)
        except (TypeError, ValueError):
            factor = 1.0
        if factor <= 0:
            factor = 1.0
        if factor != 1:
            note = f"{note} (คูณลาดเอียง x{factor:g})".strip()
        for key in keys:
            iid = by_key.get(str(key))
            if iid:
                mid = project.add_measurement(iid, page_row["id"], kind, pts, note=note, source="ai")
                if factor != 1:
                    project.update_measurement(mid, repeat=factor)
                n_obj += 1
    project.con.commit()
    return {"objects": n_obj, "snapped": n_snap, "points": n_pts,
            "warnings": [str(w) for w in result["warnings"]][:20]}


# sheets that re-draw the floor plan (ceiling, electrical, ...) - counting their tags would double-count
REPEAT_PLAN_WORDS = ("CEILING", "LIGHTING", "LIGTHTING", "POWER", "ELECTRICAL", "AC PLAN", "AIR", "PATTERN",
                     "ROOF", "SECTION", "ELEVATION", "DETAIL", "MASTER PLAN", "KEY PLAN")


_REPEAT_RE = re.compile(r"\b(?:" + "|".join(re.escape(w) for w in REPEAT_PLAN_WORDS) + ")")  # \b: AIR != STAIR


def skip_tag_count(title):
    """True when the sheet title says it is not the floor plan the doors/windows are counted from."""
    return bool(_REPEAT_RE.search((title or "").upper()))


def apply_door_window_tags(project, page_row, tags):
    """Count measurements (source 'tag') per door/window type. Skipped (returns 0) on sheets
    whose title shows they repeat the plan (ceiling/electrical/roof ...)."""
    if skip_tag_count(page_row["title"]):
        return 0
    items = {i["name"]: i["id"] for i in project.items()}
    n = 0
    for tag, pts in sorted(tags.items()):
        cat = "ประตู-หน้าต่าง"
        name = f"{'ประตู' if tag.startswith('D') else 'หน้าต่าง'} {tag} (ตามแบบขยาย)"
        iid = items.get(name) or project.add_item(cat, name, "ชุด", "COUNT", "N",
                                                  note="นับจากป้ายในแบบ")
        items[name] = iid
        project.add_measurement(iid, page_row["id"], "count", pts, note="นับจากป้าย",
                                source="tag")
        n += len(pts)
    project.con.commit()
    return n
