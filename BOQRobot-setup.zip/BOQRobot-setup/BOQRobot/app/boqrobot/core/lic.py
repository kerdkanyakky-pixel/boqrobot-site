"""License: 3-month free trial, then an activation code tied to this computer.

Code = base32(payload + Ed25519 signature). Only the PUBLIC key is in the program;
the private key that makes codes stays with the seller (never in this repository).
Payload: b"B1|<machine id>|<expiry yyyymmdd or 0 = no expiry>"
"""
import base64
import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path

TRIAL_DAYS = 90
PUBLIC_KEY = bytes.fromhex("c396563e3edaa8019061fb96de7c7537d748733696e780cae58c45ffe7e20f90")
CONTACT = "ไลน์ 099-998-9222"
SITE = "boqrobot.com"

# ---------------- Ed25519 (RFC 8032 reference, pure python) ----------------
_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _sha512(b):
    return hashlib.sha512(b).digest()


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _eq(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y, sign):
    if y >= _p:
        return None
    x2 = (y * y - 1) * pow(_d * y * y + 1, _p - 2, _p)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _I % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * pow(5, _p - 2, _p) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P):
    zinv = pow(P[2], _p - 2, _p)
    x, y = P[0] * zinv % _p, P[1] * zinv % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)


def _secret_expand(secret):
    h = _sha512(secret)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_key(secret):
    a, _ = _secret_expand(secret)
    return _compress(_mul(a, _G))


def sign(secret, msg):
    a, prefix = _secret_expand(secret)
    A = _compress(_mul(a, _G))
    r = int.from_bytes(_sha512(prefix + msg), "little") % _L
    R = _compress(_mul(r, _G))
    h = int.from_bytes(_sha512(R + A + msg), "little") % _L
    s = (r + h * a) % _L
    return R + int.to_bytes(s, 32, "little")


def verify(public, msg, signature):
    if len(public) != 32 or len(signature) != 64:
        return False
    A = _decompress(public)
    R = _decompress(signature[:32])
    if not A or not R:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _L:
        return False
    h = int.from_bytes(_sha512(signature[:32] + public + msg), "little") % _L
    return _eq(_mul(s, _G), _add(R, _mul(h, A)))


# ---------------- codes ----------------
def _b32(b):
    return base64.b32encode(b).decode().rstrip("=")


def _unb32(s):
    s = "".join(ch for ch in s.upper() if ch.isalnum())
    return base64.b32decode(s + "=" * (-len(s) % 8))


def make_code(secret, machine_id, expiry=None):
    """Seller side. expiry: date or None (no expiry)."""
    exp = expiry.strftime("%Y%m%d") if expiry else "0"
    payload = f"B1|{norm_mid(machine_id)}|{exp}".encode()
    raw = _b32(payload + sign(secret, payload))
    return "-".join(raw[i:i + 6] for i in range(0, len(raw), 6))


def read_code(code, public=None):
    """{'mid':..., 'expiry': date|None} for a genuine code, else None."""
    try:
        raw = _unb32(code)
    except Exception:
        return None
    if len(raw) < 70:
        return None
    payload, sig = raw[:-64], raw[-64:]
    if not verify(public or PUBLIC_KEY, payload, sig):
        return None
    try:
        tag, mid, exp = payload.decode().split("|")
    except ValueError:
        return None
    if tag != "B1":
        return None
    expiry = None if exp == "0" else dt.datetime.strptime(exp, "%Y%m%d").date()
    return {"mid": mid, "expiry": expiry}


def norm_mid(s):
    s = "".join(ch for ch in (s or "").upper() if ch.isalnum())
    return f"{s[:5]}-{s[5:10]}" if len(s) == 10 else s


# ---------------- this computer ----------------
def _machine_guid():
    if sys.platform == "win32":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                               winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0))
            return winreg.QueryValueEx(k, "MachineGuid")[0]
        except OSError:
            pass
    import uuid
    return f"{uuid.getnode():x}"


def machine_id():
    h = hashlib.sha256(("boqrobot:" + _machine_guid()).encode()).digest()
    return norm_mid(_b32(h)[:10])


# ---------------- local state ----------------
def _state_file():
    base = os.environ.get("APPDATA") or str(Path.home())
    d = Path(base) / "BOQRobot"
    d.mkdir(parents=True, exist_ok=True)
    return d / "license.json"


def _reg_first_run(today):
    """Windows: keep the first-run date in the registry too, so deleting the file does not restart the trial."""
    if sys.platform != "win32":
        return today
    try:
        import winreg
        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\BOQRobot")
        try:
            v = winreg.QueryValueEx(k, "fr")[0]
            return min(today, dt.date.fromisoformat(v))
        except (OSError, ValueError):
            winreg.SetValueEx(k, "fr", 0, winreg.REG_SZ, today.isoformat())
            return today
    except OSError:
        return today


def load_state():
    try:
        return json.loads(_state_file().read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(st):
    try:
        _state_file().write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def status(today=None, state=None, mid=None):
    """{'mode': 'licensed'|'trial'|'expired', 'days_left': int|None, 'mid':..., 'code':..., 'expiry':...}"""
    today = today or dt.date.today()
    st = load_state() if state is None else state
    mid = mid or machine_id()
    first = None
    try:
        first = dt.date.fromisoformat(st.get("first_run", ""))
    except ValueError:
        pass
    first = min(first or today, today)
    if state is None:
        first = _reg_first_run(first)
        if st.get("first_run") != first.isoformat():
            st["first_run"] = first.isoformat()
            save_state(st)
    code = st.get("code", "")
    info = read_code(code) if code else None
    if info and info["mid"] == mid and (info["expiry"] is None or info["expiry"] >= today):
        left = None if info["expiry"] is None else (info["expiry"] - today).days
        return {"mode": "licensed", "days_left": left, "mid": mid, "code": code, "expiry": info["expiry"]}
    left = TRIAL_DAYS - (today - first).days
    return {"mode": "trial" if left > 0 else "expired", "days_left": max(0, left), "mid": mid,
            "code": "", "expiry": first + dt.timedelta(days=TRIAL_DAYS)}


def activate(code, today=None):
    """Store a code if it is genuine for this computer. Returns (ok, message)."""
    today = today or dt.date.today()
    info = read_code(code)
    if not info:
        return False, "รหัสไม่ถูกต้อง — ตรวจว่าคัดลอกมาครบทุกตัว"
    mid = machine_id()
    if info["mid"] != mid:
        return False, f"รหัสนี้ออกให้เครื่องอื่น (เครื่องนี้คือ {mid})"
    if info["expiry"] and info["expiry"] < today:
        return False, f"รหัสนี้หมดอายุแล้ว ({info['expiry']:%d/%m/%Y})"
    st = load_state()
    st["code"] = "".join(ch for ch in code.upper() if ch.isalnum() or ch == "-")
    save_state(st)
    return True, "เปิดใช้งานเรียบร้อย" + (f" ใช้ได้ถึง {info['expiry']:%d/%m/%Y}" if info["expiry"] else "")
