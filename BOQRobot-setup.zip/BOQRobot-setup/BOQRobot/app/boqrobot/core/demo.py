"""Builds the 'BOQ Robot Demo Project' with a synthetic 1:100 floor plan."""
from pathlib import Path

from .geometry import standard_scale_mm_per_pt
from .project import Project

MM = 72 / 25.4  # pt per mm of paper


def make_plan_pdf(path):
    import fitz
    d = fitz.open()
    pg = d.new_page(width=1190.55, height=841.89)  # A3 landscape
    s = MM / 100.0 * 1  # 1:100 -> 1 mm real = 0.01 mm paper

    def P(x, y):  # real mm -> pt, origin offset
        return fitz.Point(150 + x * s * 1, 120 + y * s * 1)

    sh = pg.new_shape()
    # outer walls 9000 x 6000, internal wall at x=4500, bath 2000x2000
    for a, b in [((0, 0), (9000, 0)), ((9000, 0), (9000, 6000)), ((9000, 6000), (0, 6000)),
                 ((0, 6000), (0, 0)), ((4500, 0), (4500, 6000)), ((7000, 4000), (9000, 4000)),
                 ((7000, 4000), (7000, 6000))]:
        sh.draw_line(P(*a), P(*b))
    sh.finish(width=4)
    # dimension lines
    sh.draw_line(P(0, -800), P(9000, -800))
    sh.draw_line(P(-800, 0), P(-800, 6000))
    sh.finish(width=0.5)
    sh.commit()
    txt = [((3800, -950), "9000"), ((-1300, 3000), "6000"), ((1500, 3000), "LIVING 01"),
           ((5500, 2000), "BEDROOM 01"), ((7500, 5000), "BATH"), ((1000, 6000), "D1"),
           ((6000, 0), "W1"), ((2000, 0), "W1")]
    for (x, y), t in txt:
        pg.insert_text(P(x, y), t, fontsize=9)
    pg.insert_text((900, 800), "A-101  FLOOR PLAN   SCALE 1:100", fontsize=12)
    d.save(path)
    return path


def create_demo(parent):
    folder = Path(parent) / "BOQ Robot Demo Project"
    if (folder / Project.DB).exists():
        return Project(folder)
    p = Project.create(folder, "BOQ Robot Demo Project", client="ลูกค้าตัวอย่าง",
                       address="ภูเก็ต", number="DEMO-001")
    pdf = make_plan_pdf(folder / "demo_plan_src.pdf")
    did = p.import_drawing(pdf)
    (folder / "demo_plan_src.pdf").unlink(missing_ok=True)
    p.update_drawing(did, number="A-101", title="แปลนพื้นชั้น 1")
    page = p.pages(did)[0]
    p.set_scale(page["id"], standard_scale_mm_per_pt(100), "1:100", "standard")
    items = {r["name"]: r["id"] for r in p.items()}

    def pt(x, y):
        return (150 + x * MM / 100, 120 + y * MM / 100)

    p.add_measurement(items["ผนังก่ออิฐมอญครึ่งแผ่น"], page["id"], "line",
                      [pt(0, 0), pt(9000, 0), pt(9000, 6000), pt(0, 6000), pt(0, 0)],
                      note="ผนังภายนอก")
    p.add_measurement(items["ผนังก่ออิฐมอญครึ่งแผ่น"], page["id"], "line",
                      [pt(4500, 0), pt(4500, 6000)], note="ผนังกั้นห้อง")
    p.add_measurement(items["ปูกระเบื้องพื้น"], page["id"], "rect", [pt(0, 0), pt(9000, 6000)])
    p.add_measurement(items["ประตู D1"], page["id"], "count", [pt(1000, 6000)])
    p.add_measurement(items["หน้าต่าง W1"], page["id"], "count", [pt(2000, 0), pt(6000, 0)])
    p.con.commit()
    return p
