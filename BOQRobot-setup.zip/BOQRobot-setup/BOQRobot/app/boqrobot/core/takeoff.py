"""Takeoff engine: measurement -> quantity (with full trace) -> BOQ rows."""
import json
from dataclasses import dataclass, field

from .formula import evaluate, describe, FormulaError
from .geometry import base_values

KIND_LABEL = {"line": "เส้น/ความยาว", "poly": "พื้นที่ (รูปหลายเหลี่ยม)",
              "rect": "พื้นที่ (สี่เหลี่ยม)", "count": "นับจำนวน", "manual": "ป้อนเอง"}


@dataclass
class Line:
    """One traceable contribution to an item's quantity."""
    item_id: int
    measurement_id: int | None
    drawing: str
    page_no: int | None
    kind: str
    L: float
    A: float
    N: float
    env: dict
    qty: float
    formula_text: str
    note: str = ""
    error: str = ""


@dataclass
class BoqRow:
    item: dict
    net_qty: float = 0.0
    qty: float = 0.0
    lines: list = field(default_factory=list)
    refs: str = ""

    @property
    def mat_total(self):
        return self.qty * (self.item["mat_rate"] or 0)

    @property
    def lab_total(self):
        return self.qty * (self.item["lab_rate"] or 0)

    @property
    def total(self):
        return self.mat_total + self.lab_total


def _val(m, item, k):
    v = m[k] if m is not None and k in m.keys() else None
    return item[k] if v is None else v


def measurement_line(item, m, page, drawing_name) -> Line:
    pts = json.loads(m["points"])
    base = base_values(m["kind"], pts, page["mm_per_pt"])
    env = dict(base, H=_val(m, item, "H"), T=_val(m, item, "T"), W=_val(m, item, "W"),
               F=item["F"])
    err = ""
    if m["kind"] != "count" and not page["mm_per_pt"]:
        err = "หน้านี้ยังไม่ได้ตั้งสเกล"
    try:
        q = evaluate(item["formula"], env)
    except FormulaError as e:
        q, err = 0.0, str(e)
    rep = m["repeat"] or 1
    sign = -1 if m["sign"] == -1 else 1
    q = q * rep * sign
    ftxt = f"{item['formula']} = {describe(item['formula'], env)}"
    if rep != 1:
        ftxt += f" × {rep:g} (ซ้ำ/ตัวคูณ)"
    if sign < 0:
        ftxt = "หัก: " + ftxt
    return Line(item["id"], m["id"], drawing_name, page["page_no"], m["kind"],
                base["L"], base["A"], base["N"], env, q, ftxt, m["note"] or "", err)


def compute(project):
    """Return list[BoqRow] for all items, in BOQ order."""
    pages = {p["id"]: p for p in project.con.execute("SELECT * FROM pages")}
    dnames = {d["id"]: (d["number"] or d["title"] or d["file_name"]) for d in project.drawings()}
    by_item = {}
    for m in project.measurements():
        by_item.setdefault(m["item_id"], []).append(m)
    rows = []
    for it in project.items():
        item = dict(it)
        r = BoqRow(item)
        for m in by_item.get(it["id"], []):
            pg = pages.get(m["page_id"])
            if pg is None:
                continue
            r.lines.append(measurement_line(it, m, pg, dnames.get(pg["drawing_id"], "?")))
        if item["manual_qty"]:
            r.lines.append(Line(it["id"], None, "-", None, "manual", 0, 0, 0, {},
                                item["manual_qty"], "ป้อนปริมาณเอง"))
        r.net_qty = sum(x.qty for x in r.lines)
        r.qty = round(r.net_qty * (1 + (item["waste"] or 0) / 100.0), 2)
        refs = []
        for x in r.lines:
            if x.page_no:
                s = f"{x.drawing} น.{x.page_no}"
                if s not in refs:
                    refs.append(s)
        r.refs = ", ".join(refs)
        rows.append(r)
    return rows


def totals(rows):
    mat = sum(r.mat_total for r in rows)
    lab = sum(r.lab_total for r in rows)
    return {"mat": mat, "lab": lab, "total": mat + lab}
