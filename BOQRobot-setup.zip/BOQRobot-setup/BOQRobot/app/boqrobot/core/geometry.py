"""Pure geometry + unit conversion. Points are PDF page points (1 pt = 1/72 in)."""
import math

PT_TO_MM = 25.4 / 72.0


def standard_scale_mm_per_pt(ratio: float) -> float:
    """Scale 1:ratio on a PDF printed at true paper size."""
    return PT_TO_MM * ratio


def calibrate(p1, p2, actual_mm: float) -> float:
    d = dist(p1, p2)
    if d <= 0 or actual_mm <= 0:
        raise ValueError("ระยะต้องมากกว่า 0")
    return actual_mm / d


def dist(a, b) -> float:
    return math.hypot(b[0] - a[0], b[1] - a[1])


def polyline_length(pts) -> float:
    return sum(dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def polygon_area(pts) -> float:
    n = len(pts)
    if n < 3:
        return 0.0
    s = 0.0
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def polygon_perimeter(pts) -> float:
    if len(pts) < 2:
        return 0.0
    return polyline_length(list(pts) + [pts[0]])


def rect_points(p1, p2):
    (x1, y1), (x2, y2) = p1, p2
    return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]


def base_values(kind: str, pts, mm_per_pt: float) -> dict:
    """Return L (m), A (m2), N for a measurement."""
    if kind == "count":
        return {"L": 0.0, "A": 0.0, "N": float(len(pts))}
    if not mm_per_pt:
        return {"L": 0.0, "A": 0.0, "N": 0.0}
    k = mm_per_pt / 1000.0  # pt -> m
    if kind == "line":
        return {"L": polyline_length(pts) * k, "A": 0.0, "N": 1.0}
    if kind == "rect" and len(pts) == 2:
        pts = rect_points(*pts)
    return {"L": polygon_perimeter(pts) * k, "A": polygon_area(pts) * k * k, "N": 1.0}


def seg_distance(p, a, b) -> float:
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    if dx == dy == 0:
        return dist(p, a)
    t = max(0, min(1, ((p[0] - ax) * dx + (p[1] - ay) * dy) / (dx * dx + dy * dy)))
    return dist(p, (ax + t * dx, ay + t * dy))


def point_in_polygon(p, pts) -> bool:
    x, y = p
    inside = False
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
    return inside
