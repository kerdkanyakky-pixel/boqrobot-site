"""Read wall lines straight from a vector PDF (no AI, no image).

A wall on a CAD plan is two parallel lines 7-30 cm apart. This module finds those pairs, merges
collinear pieces and returns wall runs (centre line, thickness, length in metres). Totals are
approximate — they are a cross-check against what was measured by hand or by the AI, never a
replacement for it. Raster/scanned PDFs have no vector lines -> empty result.
"""
from collections import defaultdict


def segments(page, min_len_pt=6):
    """Straight horizontal/vertical segments ((x0,y0,x1,y1), width) from the page drawings."""
    out = []
    for d in page.get_drawings():
        w = d.get("width") or 0
        for it in d["items"]:
            if it[0] == "l":
                a, b = it[1], it[2]
                out.append(((a.x, a.y, b.x, b.y), w))
            elif it[0] == "re":
                r = it[1]
                for s in ((r.x0, r.y0, r.x1, r.y0), (r.x0, r.y1, r.x1, r.y1),
                          (r.x0, r.y0, r.x0, r.y1), (r.x1, r.y0, r.x1, r.y1)):
                    out.append((s, w))
    res = []
    for (x0, y0, x1, y1), w in out:
        if abs(y1 - y0) < 0.3 and abs(x1 - x0) >= min_len_pt:
            res.append(("h", round((y0 + y1) / 2, 1), min(x0, x1), max(x0, x1)))
        elif abs(x1 - x0) < 0.3 and abs(y1 - y0) >= min_len_pt:
            res.append(("v", round((x0 + x1) / 2, 1), min(y0, y1), max(y0, y1)))
    return res


def _merge(lines, gap):
    """Merge collinear pieces on the same offset (ranges that touch within gap)."""
    by = defaultdict(list)
    for o, pos, a, b in lines:
        by[(o, pos)].append((a, b))
    out = []
    for (o, pos), rs in by.items():
        rs.sort()
        ca, cb = rs[0]
        for a, b in rs[1:]:
            if a <= cb + gap:
                cb = max(cb, b)
            else:
                out.append((o, pos, ca, cb))
                ca, cb = a, b
        out.append((o, pos, ca, cb))
    return out


def wall_runs(page, mm_per_pt, t_min=0.07, t_max=0.30, min_len=0.5, clip=None):
    """Return list of dict(orient, x0,y0,x1,y1 (pt, centre line), thick_m, length_m).
    mm_per_pt: page scale from the project (required)."""
    if not mm_per_pt:
        return []
    k = mm_per_pt / 1000.0                       # metres per pt
    segs = segments(page)
    if clip is not None:
        segs = [s for s in segs if (clip.x0 <= (s[1] if s[0] == "v" else s[2]) <= clip.x1 and
                                    clip.y0 <= (s[1] if s[0] == "h" else s[2]) <= clip.y1)]
    segs = _merge(segs, gap=0.05 / k)
    lo, hi = t_min / k, t_max / k
    runs, used = [], set()
    for o in ("h", "v"):
        ls = sorted((s for s in segs if s[0] == o), key=lambda s: s[1])
        for i, (_, p1, a1, b1) in enumerate(ls):
            for j in range(i + 1, len(ls)):
                _, p2, a2, b2 = ls[j]
                d = p2 - p1
                if d > hi:
                    break
                if d < lo or (i, o) in used:
                    continue
                a, b = max(a1, a2), min(b1, b2)
                if (b - a) * k < min_len:
                    continue
                mid = (p1 + p2) / 2
                x0, y0, x1, y1 = (a, mid, b, mid) if o == "h" else (mid, a, mid, b)
                runs.append({"orient": o, "x0": x0, "y0": y0, "x1": x1, "y1": y1,
                             "thick_m": round(d * k, 3), "length_m": round((b - a) * k, 2)})
                used.add((i, o))
                used.add((j, o))
                break
    return runs


def summary(runs):
    """Total length per thickness band (rounded to 1 cm)."""
    tot = defaultdict(float)
    for r in runs:
        tot[round(r["thick_m"], 2)] += r["length_m"]
    return dict(sorted(tot.items()))


def wall_area(runs, height_m, openings_m2=0.0, faces=1):
    """Wall area = length x height (from elevation / ceiling level) - openings, per face."""
    L = sum(r["length_m"] for r in runs)
    return round(max(L * height_m - openings_m2, 0) * faces, 2)
