"""อ่านใบเสนอราคา PDF ที่เป็นภาพสแกน ด้วย AI — copy the printed table, then let the normal checks run.

The AI only COPIES what is printed (text and figures, cell by cell, in the row where they are printed).
It never calculates. Everything after that is the same rule-based code as for Excel:
qty × rate ≠ amount, figures shifted a line, unpriced / coloured cells, duplicates, and here also
"sum of the amounts read ≠ total printed on the page" -> a warning, so misread digits show up.

Results are cached per file (md5) so the same PDF is read (and paid for) once.
Flow used by the UI:  pages = render_scanned(path)        (main thread — PyMuPDF)
                      results = [read_page(...) ...]       (worker thread — network only)
                      save_cache(path, results)
then open_book(path) -> pdftable.pdf_to_workbook() finds the cache and builds the sheet.
"""
import hashlib
import json
from pathlib import Path

from .ai import parse_result

CACHE_DIR = Path.home() / "BOQRobot" / "ai_cache"
MAX_SIDE = 1568

PROMPT = """This is page {page} of a scanned Thai construction quotation / BOQ. COPY its price table exactly as printed.

Rules
- Do not calculate, round, correct or guess anything. Copy figures exactly as printed (keep commas and decimals).
- Keep every value in the row where it is printed, even if the figures look shifted or wrong. Never move a number
  to another row. A cell that is empty or shows only "-" is "".
- One output row per printed table row, top to bottom: section headings (e.g. "ข้อ 2 Walk in closet") and items.
  A description printed on two lines belongs to one row.
- columns: the header labels left to right. If a header has two levels (e.g. MATERIAL over U.PRICE / AMOUNT),
  write "upper | lower".
- colored: for each row, the column indexes (0-based) whose cell is filled with a colour (yellow, red, ...).
  Ignore the light colour of heading rows.
- Do not include anything below the table (payment terms, bank account, signatures). Put printed totals
  (รวม / Total / Overhead / VAT / Grand total / ราคารวมทั้งสิ้น) in printed_totals instead of rows.
- If a figure is hard to read, copy your best reading and say which row/column in unreadable (Thai).
- If the page has no price table, return empty columns and rows.

Return ONLY this JSON:
{{"columns":["ลำดับ","รายละเอียด","จำนวน","หน่วย","..."],
 "rows":[{{"cells":["1.1","Construction of ...","10","Sq.m","7,200.00"],"colored":[]}}],
 "printed_totals":[{{"label":"ราคารวม","value":"1,234.00"}}],
 "unreadable":[]}}"""


def file_key(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def cache_path(path):
    return CACHE_DIR / f"{file_key(path)}.json"


def load_cache(path):
    p = cache_path(path)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
    return None


def save_cache(path, pages, model=""):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    data = {"file": Path(path).name, "model": model, "pages": pages}
    cache_path(path).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    return data


def is_scanned(path):
    import pymupdf
    with pymupdf.open(str(path)) as doc:
        return sum(len(p.get_text("text").strip()) for p in doc) < 20


def render_scanned(path, max_pages=30):
    """[(page_no 1-based, png bytes)] — call from the main thread."""
    import pymupdf
    out = []
    with pymupdf.open(str(path)) as doc:
        for i, page in enumerate(doc):
            if i >= max_pages:
                break
            z = MAX_SIDE / max(page.rect.width, page.rect.height)
            pix = page.get_pixmap(matrix=pymupdf.Matrix(z, z), alpha=False)
            out.append((i + 1, pix.tobytes("png")))
    return out


def read_page(settings, page_no, png):
    """One network call (safe in a worker thread). Returns the page dict."""
    from .ai import run
    text, usage = run(settings, "table", png, {"page": page_no})
    d = parse_result(text)
    return {"page": page_no, "columns": d.get("columns") or [], "rows": d.get("rows") or [],
            "printed_totals": d.get("printed_totals") or [], "unreadable": d.get("unreadable") or [],
            "usage": usage}


def build_workbook(data):
    """Cached AI pages -> Workbook with one sheet per page ("หน้า N (AI)") + notes for the summary."""
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill
    from .pdftable import _is_num, _to_num
    from .compare import find_columns
    wb = Workbook()
    wb.remove(wb.active)
    notes = []
    fill = PatternFill("solid", fgColor="FFFF00")
    for pg in data.get("pages", []):
        cols = [str(c or "") for c in pg.get("columns") or []]
        if not cols or not pg.get("rows"):
            continue
        ws = wb.create_sheet(f"หน้า {pg['page']} (AI)")
        two = any(" | " in c for c in cols)
        ws.append([c.split(" | ")[0] for c in cols])
        if two:
            ws.append([c.split(" | ", 1)[1] if " | " in c else None for c in cols])
        hr = ws.max_row
        for row in pg["rows"]:
            cells = list(row.get("cells") or [])[:len(cols)]
            vals = []
            for i, t in enumerate(cells):
                t = "" if t is None else str(t).strip()
                if t in ("", "-", "–"):
                    vals.append(None)
                elif i > 0 and _is_num(t):
                    vals.append(_to_num(t))
                else:
                    vals.append(t)
            ws.append(vals)
            for i in row.get("colored") or []:
                if isinstance(i, int) and 0 <= i < len(cols):
                    ws.cell(ws.max_row, i + 1).fill = fill
        # check: amounts read vs totals printed on the page
        h, c = find_columns(ws)
        if h and c.get("amount"):
            s = sum(v for r in range(hr + 1, ws.max_row + 1)
                    if isinstance(v := ws.cell(r, c["amount"]).value, (int, float)))
            printed = [(_to_num(str(t.get("value", ""))), t.get("label", "")) for t in pg["printed_totals"]]
            printed = [(v, lb) for v, lb in printed if v is not None]
            if printed and not any(abs(v - s) < 1 for v, _ in printed):
                notes.append(f"หน้า {pg['page']}: ยอดรวมที่ AI อ่านได้ {s:,.2f} ไม่ตรงกับยอดที่พิมพ์ในใบ "
                             f"({', '.join(f'{lb} {v:,.2f}' for v, lb in printed[:3])}) — มีตัวเลขอ่านผิดหรือขาดบรรทัด")
            elif printed:
                notes.append(f"หน้า {pg['page']}: ยอดรวมที่อ่านได้ {s:,.2f} ตรงกับยอดที่พิมพ์ในใบ")
        for u in pg.get("unreadable") or []:
            notes.append(f"หน้า {pg['page']}: อ่านไม่ชัด — {u}")
    wb.boq_notes = [f"{data.get('file', '')}: อ่านจากภาพสแกนด้วย AI — เทียบตัวเลขกับใบจริงก่อนสรุป"] + notes
    return wb
