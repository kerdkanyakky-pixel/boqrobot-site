"""อ่านตารางราคาจาก PDF (ที่มีตัวอักษร ไม่ใช่ภาพสแกน) — turn a priced PDF table into an in-memory worksheet.

The worksheet is then read by the same code as an Excel quotation (compare.read_lines), so every
check (shift, typed rate, unpriced, duplicates) works the same way.

How:
  1. words of each page are grouped into rows (same height) and phrases (words close together)
  2. the header band is found: rows close together that contain รายการ/description AND จำนวน/qty,
     plus group labels just above (MATERIAL COST / ค่าแรง) and sub labels just below (U.PRICE / AMOUNT)
  3. the lowest label of each stack becomes a column; labels above it are joined to its name
  4. a data phrase that starts between the code column and the qty column is description;
     anything else goes to the column it overlaps most (or the nearest)
  5. an item can be printed over several lines (description above/below, figures in the middle):
     lines without a quantity are joined to the nearest line with a quantity when they are close
     (closer than 0.7 × the usual distance between items); otherwise they are section headings
Pages without a header reuse the previous page's columns.
"""
import re
import statistics
import unicodedata

from .compare import H_CODE, H_DESC, H_QTY, H_UNIT, H_RATE, H_AMT, H_MAT, H_LAB, H_REMARK, H_EXTRA, H_REF, SKIP_DESC

NUM = re.compile(r"^-?\(?[\d,]+(\.\d+)?\)?$")
GLUE_LEFT = ("COST", "PRICE", "ราคา", "(บาท)", "บาท", "(BAHT)")
ALL_HEAD = H_CODE + H_DESC + H_QTY + H_UNIT + H_RATE + H_AMT + H_MAT + H_LAB + H_REMARK + H_EXTRA + H_REF + (
    "ราคา", "ค่า", "ต่อหน่วย", "หน่วยละ", "PRICE", "รวม", "COST", "BAHT", "บาท", "เป็นเงิน", "ส่วนลด",
    "DISCOUNT", "สุทธิ", "NET", "U.PRICE")


TOTAL_RE = re.compile(r"(grand\s*total|sum\s*total|^total|total work|รวมทั้งสิ้น|รวมเป็นเงิน|^ราคารวม|^รวม\b|"
                      r"เป็นเงินสุทธิ|net amount)", re.I)


class PdfReadError(RuntimeError):
    def __init__(self, msg, scanned=False):
        super().__init__(msg)
        self.scanned = scanned


def _fix_thai(s):
    # PDFs often store sara am as nikhahit + sara aa
    if "ํ" in s:
        s = s.replace("ํา", "ำ").replace("ํ", "ำ")
    return unicodedata.normalize("NFC", s)


def _is_num(t):
    t = t.replace(" ", "")
    return bool(NUM.match(t)) and any(ch.isdigit() for ch in t)


def _to_num(t):
    t = t.replace(",", "").replace(" ", "")
    neg = t.startswith("(") and t.endswith(")")
    try:
        v = float(t.strip("()"))
    except ValueError:
        return None
    return -v if neg else v


def _key(t):
    return re.sub(r"\s+", "", t.upper())


def _is_head(t, words):
    k = _key(t)
    return any(k.startswith(_key(h)) for h in words)


def _has_head(t):
    k = _key(t)
    return any(_key(h) in k for h in ALL_HEAD)


def _overlap(a0, a1, b0, b1):
    return max(0.0, min(a1, b1) - max(a0, b0))


def _rows(page):
    words = [(w[0], w[1], w[2], w[3], _fix_thai(w[4])) for w in page.get_text("words")]
    words.sort(key=lambda w: ((w[1] + w[3]) / 2, w[0]))
    rows = []
    for w in words:
        yc = (w[1] + w[3]) / 2
        tol = max(2.5, (w[3] - w[1]) * 0.45)
        if rows and abs(rows[-1]["y"] - yc) <= tol:
            rows[-1]["w"].append(w)
        else:
            rows.append({"y": yc, "w": [w]})
    out = []
    for r in rows:
        phrases = []
        for w in sorted(r["w"], key=lambda w: w[0]):
            size = max(4.0, w[3] - w[1])
            if phrases:
                gap = w[0] - phrases[-1]["x1"]
                both_num = _is_num(w[4]) and _is_num(phrases[-1]["t"].split()[-1])
                if gap <= size * (0.3 if both_num else 0.45):
                    p = phrases[-1]
                    p["t"] += " " + w[4]
                    p["x1"] = w[2]
                    continue
            phrases.append({"x0": w[0], "x1": w[2], "t": w[4]})
        out.append({"y": r["y"], "p": phrases})
    return out


def _glue(phrases):
    """'MATERIAL' 'COST' printed as two words over two columns -> one group label."""
    out = []
    for p in phrases:
        if out and _key(p["t"]) in [_key(g) for g in GLUE_LEFT] and p["x0"] - out[-1]["x1"] < 40:
            out[-1] = dict(out[-1], t=out[-1]["t"] + " " + p["t"], x1=p["x1"])
        else:
            out.append(dict(p))
    return out


def _find_header(rows):
    """Index range (first, last) of the header band, or None."""
    for i, r in enumerate(rows):
        win = [j for j in range(i, min(i + 4, len(rows))) if rows[j]["y"] - r["y"] <= 14]
        texts = [p["t"] for j in win for p in rows[j]["p"]]
        if any(_is_head(t, H_DESC) for t in texts) and any(_is_head(t, H_QTY) for t in texts):
            if not any(_is_head(p["t"], H_DESC + H_QTY) for p in r["p"]):
                continue                      # start the band at the row that holds desc or qty
            band = [j for j in win if all(not _is_num(p["t"]) for p in rows[j]["p"])]
            band = band[:1] + [j for j in band[1:] if sum(_has_head(p["t"]) for p in rows[j]["p"]) * 2 >= len(
                rows[j]["p"])]
            first, last = band[0], band[-1]
            for j in (first - 1, first - 2):    # group labels above (MATERIAL COST / LABOUR COST / TOTAL)
                if j >= 0 and rows[first]["y"] - rows[j]["y"] < 16 and rows[j]["p"] and all(
                        not _is_num(p["t"]) for p in rows[j]["p"]) and sum(
                        _has_head(p["t"]) for p in rows[j]["p"]) * 2 >= len(rows[j]["p"]):
                    first = j
                else:
                    break
            for j in (last + 1, last + 2):      # sub labels below (U.PRICE / AMOUNT / ราคาต่อหน่วย)
                if j < len(rows) and rows[j]["y"] - rows[last]["y"] < 16 and rows[j]["p"] and all(
                        not _is_num(p["t"]) for p in rows[j]["p"]) and any(_has_head(p["t"]) for p in rows[j]["p"]):
                    last = j
                else:
                    break
            return first, last
    return None


def _columns(rows, first, last):
    phrases = [dict(p, r=j) for j in range(first, last + 1) for p in _glue(rows[j]["p"])]
    # a label sitting over two or more labels of one lower row is a group label, not a column
    leaves = []
    for p in phrases:
        below = [q for q in phrases if q["r"] > p["r"] and _overlap(p["x0"], p["x1"], q["x0"], q["x1"]) > 1]
        if not below:
            leaves.append(p)
    # a lower label spanning several upper labels of one row ("Discount/Baht Net Unit/Baht Amount/Baht")
    # means the upper labels are the columns
    final = []
    for p in leaves:
        above = [q for q in phrases if q["r"] < p["r"] and _overlap(p["x0"], p["x1"], q["x0"], q["x1"]) > 1]
        rows_above = {}
        for q in above:
            rows_above.setdefault(q["r"], []).append(q)
        split = next((v for v in rows_above.values() if len(v) >= 2), None)
        if split:
            for q in split:
                final.append(dict(q, r=p["r"], t=q["t"] + " " + p["t"]))
        else:
            final.append(p)
    final = sorted(final, key=lambda p: p["x0"])
    cols = []
    for p in final:
        over = sorted((q for q in phrases if q["r"] < p["r"] and _overlap(p["x0"], p["x1"], q["x0"], q["x1"]) > 1
                       and q["t"] not in p["t"]), key=lambda q: q["r"])
        if len(_key(p["t"])) <= 2 and not over and not _is_head(p["t"], H_CODE + H_UNIT):
            continue                    # a stray letter, not a column
        groups, own = [], []
        for q in over:
            n = sum(1 for o in final if _overlap(q["x0"], q["x1"], o["x0"], o["x1"]) > 1)
            (groups if n >= 2 else own).append(q)
        label = " ".join([q["t"] for q in own] + [p["t"]])
        top = " ".join(q["t"] for q in groups)
        cols.append({"x0": min([p["x0"]] + [q["x0"] for q in own]), "x1": max([p["x1"]] + [q["x1"] for q in own]),
                     "top": top or label, "sub": label if top else ""})
    return cols


def _roles(cols):
    desc_i = next((i for i, c in enumerate(cols) if _is_head(c["top"], H_DESC) or _is_head(c["sub"], H_DESC)), None)
    qty_i = next((i for i, c in enumerate(cols) if _is_head(c["top"], H_QTY) or _is_head(c["sub"], H_QTY)), None)
    code_i = next((i for i, c in enumerate(cols) if _is_head(c["top"], H_CODE) or _is_head(c["sub"], H_CODE)), None)
    return desc_i, qty_i, code_i


def _assign(cols, phrases, roles):
    desc_i, qty_i, code_i = roles
    if code_i is not None and desc_i is not None and code_i < desc_i:
        d0 = (cols[code_i]["x1"] + cols[desc_i]["x0"]) / 2 if cols[code_i]["x1"] < cols[desc_i]["x0"] else \
            cols[code_i]["x1"] + 1
        d0 = min(d0, cols[code_i]["x1"] + 6)
    else:
        d0 = cols[desc_i]["x0"] - 60 if desc_i is not None else -1
    d1 = cols[qty_i]["x0"] - 4 if qty_i is not None else 1e9
    cell = {}
    for p in phrases:
        text_like = not _is_num(p["t"]) and p["t"].strip("-– ") != ""
        mid = (p["x0"] + p["x1"]) / 2
        if desc_i is not None and text_like and (d0 <= p["x0"] < d1 or (
                len(p["t"]) > 4 and p["x1"] > d0 + 12 and p["x0"] < d1)):
            i = desc_i
        elif desc_i is not None and d0 <= p["x0"] and p["x1"] < d1 - 10 and not text_like and p["t"].strip("-– "):
            i = desc_i                    # a number inside the description area (size, count)
        else:
            i = min(range(len(cols)), key=lambda k: (
                -_overlap(p["x0"], p["x1"], cols[k]["x0"], cols[k]["x1"]),
                abs(mid - (cols[k]["x0"] + cols[k]["x1"]) / 2)))
        cell.setdefault(i, []).append(p["t"])
    return {i: " ".join(v) for i, v in cell.items()}


def _logical_rows(rows, cols, roles):
    """Join lines printed around an item's figures into that item (see module doc, step 5)."""
    desc_i, qty_i, code_i = roles
    cells = [(r["y"], _assign(cols, r["p"], roles)) for r in rows]
    cells = [(y, c) for y, c in cells if c]

    def has_qty(c):
        return qty_i is not None and qty_i in c and _is_num(c[qty_i]) and (_to_num(c[qty_i]) or 0) != 0
    qy = [y for y, c in cells if has_qty(c)]
    gaps = [b - a for a, b in zip(qy, qy[1:]) if b - a > 0]
    thr = 0.7 * (statistics.median(gaps) if gaps else 16)
    owner = {}
    for k, (y, c) in enumerate(cells):
        if has_qty(c):
            continue
        txt = c.get(desc_i, "")
        if SKIP_DESC.match(txt or "") or (code_i is not None and c.get(code_i) and txt and not any(
                abs(y2 - y) < 2.5 for y2 in qy)):
            continue                      # a total line, or a numbered heading
        near = min(((abs(y2 - y), y2) for y2 in qy), default=None)
        if near and near[0] < thr:
            owner[k] = near[1]
    out, by_y = [], {}
    for k, (y, c) in enumerate(cells):
        if k in owner:
            continue
        row = {i: [t] for i, t in c.items()}
        by_y[y] = row
        out.append((y, row))
    for k, y2 in owner.items():
        y, c = cells[k]
        tgt = by_y[y2]
        for i, t in c.items():
            if i in tgt and i != desc_i and _is_num(tgt[i][0]):
                continue
            tgt.setdefault(i, []).append((y, t))
    result = []
    for y, row in out:
        merged = {}
        for i, parts in row.items():
            own = [(y, p) for p in parts if isinstance(p, str)]
            extra = [p for p in parts if not isinstance(p, str)]
            merged[i] = " ".join(t for _, t in sorted(own + extra, key=lambda x: x[0]))
        result.append(merged)
    return result


def pdf_to_workbook(path, max_pages=200):
    """Return an openpyxl Workbook with one sheet per page ("หน้า N"). Raises PdfReadError."""
    import pymupdf
    with pymupdf.open(str(path)) as doc:      # closed again so the file can be deleted (Windows)
        return _pdf_to_workbook(doc, path, max_pages)


def _pdf_to_workbook(doc, path, max_pages):
    from openpyxl import Workbook
    if sum(len(p.get_text("text").strip()) for p in doc) < 20:
        from . import pdfscan
        cached = pdfscan.load_cache(path)
        if cached:
            return pdfscan.build_workbook(cached)
        raise PdfReadError("PDF นี้เป็นภาพสแกน (ไม่มีตัวอักษรในไฟล์) — ต้องให้ AI อ่านก่อน "
                           "(ใส่ API key ในปุ่ม 🤖 ถอด BOQ (AI)) หรือขอไฟล์ Excel จากผู้รับเหมา", scanned=True)
    wb = Workbook()
    wb.remove(wb.active)
    cols = roles = None
    for pn, page in enumerate(doc):
        if pn >= max_pages:
            break
        rows = _rows(page)
        band = _find_header(rows)
        start = 0
        if band:
            cols = _columns(rows, *band)
            roles = _roles(cols)
            start = band[1] + 1
        if not cols or roles[0] is None or roles[1] is None:
            continue
        ws = wb.create_sheet(f"หน้า {pn + 1}")
        two = any(c["sub"] for c in cols)
        ws.append([c["top"] for c in cols])
        if two:
            ws.append([c["sub"] or None for c in cols])
        head_rows = ws.max_row
        logical = _logical_rows(rows[start:], cols, roles)
        unit_i = next((i for i, c in enumerate(cols) if _is_head(c["top"], H_UNIT) or _is_head(c["sub"], H_UNIT)),
                      None)
        totals_at = [k for k, c in enumerate(logical) if any(
            TOTAL_RE.search(t) for t in c.values() if not _is_num(t))]
        with_unit = [k for k, c in enumerate(logical) if unit_i is not None and c.get(unit_i)]
        cut = next((k for k in totals_at if not any(u > k for u in with_unit)), None)
        if cut is not None:
            # payment terms / bank details printed under the grand total are not items
            logical = logical[:cut + 1]
        for cell in logical:
            vals = []
            for i in range(len(cols)):
                t = cell.get(i)
                if t is None:
                    vals.append(None)
                elif i not in (roles[0], roles[2]) and _is_num(t):
                    vals.append(_to_num(t))
                else:
                    vals.append(t)
            ws.append(vals)
        if ws.max_row <= head_rows:
            wb.remove(ws)
    if cols is None:
        raise PdfReadError("หาแถวหัวตารางใน PDF ไม่เจอ (ต้องมีคำว่า รายการ/Description และ จำนวน/Qty)")
    if not wb.worksheets:
        raise PdfReadError("อ่านรายการใน PDF ไม่ได้")
    return wb
