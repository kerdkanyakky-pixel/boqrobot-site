"""QA/QC checks - rule based, no AI. Returns list of (level, where, message)."""
import json

from .takeoff import compute
from .geometry import polygon_area, polyline_length
from .ai import TAG_RE

ERROR, WARN, INFO = "ผิดพลาด", "เตือน", "ข้อมูล"


def run_checks(project, rows=None):
    issues = []
    rows = rows if rows is not None else compute(project)
    used_pages = {m["page_id"] for m in project.measurements()}
    for d in project.drawings():
        for p in project.pages(d["id"]):
            where = f"{d['number'] or d['title']} น.{p['page_no']}"
            if not p["mm_per_pt"] and p["id"] in used_pages:
                issues.append((ERROR, where, "มีการวัดแต่ยังไม่ได้ตั้งสเกล — ปริมาณเป็น 0"))
            elif p["scale_source"] == "detected" and not p["mm_per_pt"]:
                issues.append((INFO, where, f"พบสเกลในแบบ {p['scale_label']} — กดตั้งสเกลเพื่อยืนยัน"))
    page_tags = {}
    for r in rows:
        for m in project.measurements(item_id=r.item["id"]):
            if m["source"] == "tag":
                page_tags.setdefault(m["page_id"], set()).add(r.item["id"])
    for r in rows:
        it = r.item
        name = f"{it['code']} {it['name']}"
        for ln in r.lines:
            if ln.error:
                issues.append((ERROR, name, f"{ln.drawing} น.{ln.page_no}: {ln.error}"))
            elif ln.qty == 0 and ln.kind != "manual":
                issues.append((WARN, name, f"{ln.drawing} น.{ln.page_no}: ปริมาณเป็น 0 "
                               f"(สูตร {it['formula']} อาจไม่ตรงกับวิธีวัด '{ln.kind}')"))
        if r.lines and r.net_qty < 0:
            issues.append((ERROR, name, "ปริมาณรวมติดลบ (หักมากกว่าที่วัด)"))
        if r.lines and not it["verified"]:
            issues.append((INFO, name, "ยังไม่ได้ติ๊ก 'ตรวจแล้ว'"))
        if r.qty and not (it["mat_rate"] or it["lab_rate"]):
            issues.append((INFO, name, "มีปริมาณแต่ยังไม่ใส่ราคาต่อหน่วย"))
        uses = set(it["formula"])
        for v in "HTW":
            if v in uses and not it[v]:
                issues.append((WARN, name, f"สูตรใช้ {v} แต่ค่า {v} = 0"))
        meas = project.measurements(item_id=it["id"])
        # door/window tags counted on more than one sheet (e.g. plan + ceiling plan) -> likely double count
        tag_pages = sorted({m["page_id"] for m in meas if m["source"] == "tag"})
        # only warn when the sheets carry (almost) the same set of tags = the same plan drawn twice;
        # different buildings legitimately reuse tag names (D10 in building B and C)
        def _same_plan(a, b):
            sa, sb = page_tags.get(a, set()), page_tags.get(b, set())
            u = sa | sb
            return len(u) >= 2 and len(sa & sb) / len(u) >= 0.8
        if len(tag_pages) > 1 and any(_same_plan(a, b) for i, a in enumerate(tag_pages) for b in tag_pages[i + 1:]):
            tag = next((w for w in it["name"].split() if TAG_RE.match(w)), it["name"])
            nos = ", ".join(f"น.{project.page(pid)['page_no']}" for pid in tag_pages)
            issues.append((WARN, name, f"ป้ายประตู/หน้าต่าง {tag} ถูกนับจากหลายแผ่น ({nos}) — อาจนับซ้ำ"))
        # duplicate measurements on the same page
        seen = {}
        for m in meas:
            key = (m["page_id"], m["points"])
            if key in seen:
                issues.append((WARN, name, f"วัดซ้ำจุดเดิม (รายการวัด #{seen[key]} และ #{m['id']})"))
            seen[key] = m["id"]
            pts = json.loads(m["points"])
            if m["kind"] == "poly" and polygon_area(pts) == 0:
                issues.append((WARN, name, f"รายการวัด #{m['id']} พื้นที่เป็นศูนย์"))
            if m["kind"] == "line" and polyline_length(pts) == 0:
                issues.append((WARN, name, f"รายการวัด #{m['id']} ความยาวเป็นศูนย์"))
    issues += wall_checks(project, rows)
    order = {ERROR: 0, WARN: 1, INFO: 2}
    return sorted(issues, key=lambda x: order[x[0]])


# ---------------------------------------------------------------- walls (v1.4)
WALL_WORDS = ("ผนัง", "ฉาบ", "สกิม", "ทาสีผนัง", "สีรองพื้นผนัง", "กระเบื้องผนัง", "wall", "plaster", "skim")
DEFAULT_H = (3.0, 2.7, 2.4)


def _is_wall(it):
    n = (it["name"] or "").lower()
    return any(w in n for w in WALL_WORDS) and "H" in (it["formula"] or "")


def wall_checks(project, rows):
    """Rules learned from the Sharon / Villa R audits:
    - wall height must come from the elevation, or the ceiling level when there is no elevation
    - doors and windows must be deducted
    - plaster = skim on the same wall (except the tiled part); primer = paint"""
    out = []
    tag_pages = set()
    for r in rows:
        for m in project.measurements(item_id=r.item["id"]):
            if m["source"] == "tag":
                tag_pages.add(m["page_id"])
    by_kind = {}
    for r in rows:
        it = r.item
        if not r.lines or not _is_wall(it):
            continue
        name = f"{it['code']} {it['name']}"
        meas = project.measurements(item_id=it["id"])
        hs = {m["H"] for m in meas if m["H"]}
        note = (it["note"] or "")
        if not hs and it["H"] in DEFAULT_H and "สูง" not in note:
            out.append((WARN, name, f"ความสูงผนังยังเป็นค่าเริ่มต้น {it['H']:g} ม. — ตั้งตามรูปด้าน "
                                    "ถ้าไม่มีรูปด้านใช้ระดับฝ้า (ใส่ที่มาในหมายเหตุ เช่น 'สูงตามฝ้า +2.80')"))
        pages = {m["page_id"] for m in meas if m["sign"] != -1}
        ded = [m for m in meas if m["sign"] == -1]
        if pages & tag_pages and not ded and "ไม่หัก" not in note:
            out.append((WARN, name, "หน้าที่วัดผนังนี้มีประตู/หน้าต่าง แต่ยังไม่ได้หักช่องเปิด"))
        n = (it["name"] or "").lower()
        for k, words in (("plaster", ("ฉาบ", "plaster")), ("skim", ("สกิม", "skim")),
                         ("primer", ("รองพื้น", "primer")), ("paint", ("ทาสี", "paint")),
                         ("tile", ("กระเบื้องผนัง", "wall til"))):
            if any(w in n for w in words) and not (k == "plaster" and "ฝ้า" in n):
                by_kind[k] = by_kind.get(k, 0) + r.qty
                break
    pl, sk, pr, pa, ti = (by_kind.get(k, 0) for k in ("plaster", "skim", "primer", "paint", "tile"))
    if pl and sk and abs(sk - (pl - ti)) > 0.05 * pl:
        out.append((WARN, "ฉาบ/สกิม", f"สกิม {sk:,.2f} ควรเท่ากับฉาบ {pl:,.2f} − ผนังปูกระเบื้อง {ti:,.2f} "
                                      f"= {pl - ti:,.2f} ตร.ม."))
    if pr and pa and abs(pr - pa) > 0.05 * pa:
        out.append((WARN, "สีรองพื้น/สีจริง", f"สีรองพื้น {pr:,.2f} ไม่เท่าสีจริง {pa:,.2f} ตร.ม."))
    return out
