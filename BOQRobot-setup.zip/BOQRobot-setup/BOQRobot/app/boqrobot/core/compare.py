"""เทียบใบเสนอราคาผู้รับเหมาใหม่ กับ BOQ เดิม — compare a new contractor's quotation against the original BOQ.

Rule based, no AI, no invented prices. What it does:
  1. reads priced Excel sheets (header row is detected: ลำดับ / รายการ / จำนวน / หน่วย / ราคา / มูลค่า / หมายเหตุ)
  2. finds the original value of every quoted line — either from a "มูลค่า BOQ" column in the quote itself
     or by matching the line to a separate BOQ file (code + description + unit + quantity + order)
  3. flags: not priced ("ขอแยก", blank, coloured cell), priced but marked "ขอแยก", figures shifted one line,
     quantity × rate ≠ amount (typed rate wrong), quantity different from the original, extra claims,
     original lines nobody quoted, quoted lines not in the original
  4. compares money on the SAME lines only, each side with its own multiplier (OH / VAT)
  5. exports an internal workbook (with original prices) and a separate question list that can be sent
     to the contractor (no original prices in it)
"""
import re
import unicodedata
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path

# ---------------------------------------------------------------- header detection
H_CODE = ("ITEM", "ลำดับ", "NO.", "NO", "ข้อ", "รหัส")
H_DESC = ("DESCRIPTION", "รายการ", "รายละเอียด", "ITEM DESCRIPTION", "งาน")
H_QTY = ("Q'TY", "QTY", "QUANTITY", "จำนวน", "ปริมาณ")
H_UNIT = ("UNIT", "หน่วย")
H_MAT = ("MATERIAL", "ค่าวัสดุ", "วัสดุ")
H_LAB = ("LABOUR", "LABOR", "ค่าแรง")
H_RATE = ("UNIT PRICE", "UNIT/RATE", "RATE", "U.PRICE", "U/PRICE", "PRICE/UNIT", "ราคาต่อหน่วย", "ราคา/หน่วย",
          "รวม/หน่วย", "บาท/หน่วย", "/หน่วย", "ต่อหน่วย", "หน่วยละ")
H_AMT = ("AMOUNT", "TOTAL", "รวมเงิน", "มูลค่า", "จำนวนเงิน", "ราคารวม", "ยอด", "เป็นเงิน")
H_EXTRA = ("เพิ่มเติม", "ขอเพิ่ม", "EXTRA", "ADDITIONAL", "งานเพิ่ม")
H_REF = ("BOQ", "เดิม", "ORIGINAL")
H_DONE = ("ทำแล้ว", "DONE", "เบิกแล้ว")
H_REMARK = ("หมายเหตุ", "REMARK", "NOTE")
H_SKIP = ("ต่าง", "DIFF", "ผลตรวจ", "ตำรวจ", "ควรจ่าย", "ที่ใช้คิด", "จากแบบ", "ตรวจแล้ว", "ที่มา")
H_CHECK = ("ตรวจแล้ว", "ที่ใช้คิด", "จากแบบ")
SKIP_DESC = re.compile(r"^\s*(total|sub\s*total|grand total|รวม|ยอดรวม|ราคารวม|overhead|over head|vat|ภาษี|"
                       r"sumtotal|\*|สรุป)", re.I)
NOT_PRICED = re.compile(r"(ขอแยก|แยกเสนอ|เสนอแยก|ยังไม่ได้รวม|ไม่รวมในราคา|ไม่เสนอ|exclud|by owner|n/?a\b|ไม่รับ)", re.I)


def safe_text(s):
    """Text that starts with '=' would be written back to Excel as a formula — put an invisible
    zero-width space in front so it stays text."""
    return "\u200b" + s if isinstance(s, str) and s.startswith("=") else s


def _s(v):
    return safe_text(unicodedata.normalize("NFC", str(v)).strip()) if v is not None else ""


def _u(v):
    return re.sub(r"\s+", " ", _s(v).upper())


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        t = v.replace(",", "").replace("฿", "").strip()
        try:
            return float(t)
        except ValueError:
            return None
    return None


def _has(text, words):
    return any(w.upper() in text for w in words)


def find_columns(ws, max_rows=30):
    """Return (last_header_row, cols) or (None, None). Two-row headers are merged."""
    mc = min(ws.max_column, 40)
    for r in range(1, min(ws.max_row, max_rows) + 1):
        top = {c: _u(ws.cell(r, c).value) for c in range(1, mc + 1)}
        sub = {c: _u(ws.cell(r + 1, c).value) for c in range(1, mc + 1)}
        desc = next((c for c, t in top.items() if t and any(t.startswith(h.upper()) for h in H_DESC)), None)
        qty = next((c for c, t in top.items()
                    if t and any(t.replace(" ", "").startswith(h.upper().replace(" ", "")) for h in H_QTY)), None)
        if not (desc and qty):
            continue
        two = any(_has(sub[c], H_RATE + H_AMT) for c in sub if c > qty) and not any(
            _num(ws.cell(r + 1, c).value) is not None for c in (qty,))
        # a column's text = its own header + the sub header (for MATERIAL / UNIT PRICE / TOTAL layouts)
        name, group = {}, ""
        for c in range(1, mc + 1):
            if top[c]:
                group = top[c]
            name[c] = (top[c] or (group if two and c > qty else "")) + (" | " + sub[c] if two and sub[c] else "")
        cols = {"desc": desc, "qty": qty, "code": None, "unit": None, "rate": None, "mat": None, "lab": None,
                "amount": None, "ref_amount": None, "extra": None, "remark": None, "headers": {},
                "check_qty": None, "group": None, "page": None}
        for c in range(1, mc + 1):
            t = top[c]
            if not t or c in (desc, qty):
                continue
            if t in ("กลุ่ม", "GROUP"):
                cols["group"] = cols["group"] or c
            elif t.startswith("หน้า") or t.startswith("PAGE"):
                cols["page"] = cols["page"] or c
        cols["check_qty"] = next((c for h in H_CHECK for c in range(qty + 1, mc + 1)
                                  if top[c] and h in top[c] and not _has(top[c], ("ต่าง", "เงิน"))), None)
        used = set()
        cols["code"] = next((c for c in range(1, desc) if top[c] and any(
            top[c].startswith(h.upper()) for h in H_CODE)), None) or (1 if desc > 1 else None)
        is_unit = lambda t: t and any(t.startswith(h.upper()) for h in H_UNIT) and not _has(  # noqa: E731
            t, H_RATE[:6] + ("ราคา", "ละ"))
        cols["unit"] = next((c for c in range(qty + 1, mc + 1) if is_unit(top[c])), None) or next(
            (c for c in range(1, mc + 1) if c not in (desc, qty) and is_unit(top[c])), None)
        for c in range(qty + 1, mc + 1):
            t = name[c]
            if not t or c == cols["unit"]:
                continue
            cols["headers"][c] = t
            used.add(c)
            per_unit = _has(t, H_RATE + ("/หน่วย", "ต่อหน่วย"))
            if _has(t, H_REMARK):
                cols["remark"] = cols["remark"] or c
            elif _has(t, H_DONE) or _has(t, H_SKIP):
                continue
            elif _has(t, H_EXTRA):
                cols["extra"] = cols["extra"] or c
            elif _has(t, H_MAT) and not _has(t, H_LAB) and per_unit:
                cols["mat"] = c
            elif _has(t, H_LAB) and not _has(t, H_MAT) and per_unit:
                cols["lab"] = c
            elif (_has(t, H_MAT) or _has(t, H_LAB)) and not (_has(t, H_MAT) and _has(t, H_LAB)) and (
                    _has(t, H_AMT) or "รวม" in t):
                continue      # material total / labour total
            elif _has(t, H_RATE) and not _has(t, H_AMT[:3] + ("เป็นเงิน",)):
                if _has(t, ("ส่วนลด", "DISCOUNT")) and not _has(t, ("สุทธิ", "NET")):
                    continue
                cols["rate"] = c if (cols["rate"] is None or _has(t, ("สุทธิ", "NET"))) else cols["rate"]
            elif _has(t, H_AMT) or (two and "TOTAL" in t):
                if _has(t, H_REF):
                    cols["ref_amount"] = cols["ref_amount"] or c
                elif two and (_has(t, H_MAT) or _has(t, H_LAB)):
                    continue      # material total / labour total — the grand total column is used
                else:
                    cols["amount"] = c if (cols["amount"] is None or "ใหม่" in t or "สัญญา" in t) else cols["amount"]
            else:
                used.discard(c)
        if cols["amount"] is None:
            # e.g. "ค่าวัสดุและแรงงาน" — the last unlabelled figure column is the line total
            free = [c for c in cols["headers"] if c not in used and c not in (cols["group"], cols["page"])]
            if free and (cols["mat"] or cols["lab"] or cols["rate"]):
                cols["amount"] = free[-1]
        return (r + 1 if two else r), cols
    return None, None


@dataclass
class Line:
    source: str
    sheet: str
    row: int
    section: str
    code: str
    desc: str
    unit: str
    qty: float | None
    rate: float | None          # unit price as typed
    amount: float | None        # quoted amount (None = blank)
    ref_amount: float | None = None   # original value, from the same sheet or matched
    extra: float = 0.0
    remark: str = ""
    coloured: bool = False
    ref: "Line | None" = None   # matched original line
    ref_cmp: float | None = None  # original value of the same portion of work (for money comparison)
    summary_of: str = ""        # this line is the total of other lines (not counted twice)
    over_qty: float = 0.0       # quantity above the original BOQ (money to claim back = over_qty × own rate)
    status: str = ""
    flags: list = field(default_factory=list)   # (level, text)
    question: list = field(default_factory=list)

    @property
    def where(self):
        return f"{self.source} / {self.sheet} แถว {self.row}"

    @property
    def priced(self):
        return self.status in (ST_OK, ST_PRICED_ASK)


ST_OK, ST_PRICED_ASK, ST_UNPRICED, ST_ZERO = "ใส่ราคา", "ใส่ราคา (ต้องถาม)", "ไม่ใส่ราคา", "เสนอ 0"
ST_SUMMARY = "ยอดสรุป (ไม่นับซ้ำ)"
ERR, WARN, INFO = "สูงมาก", "สงสัย", "ข้อมูล"
LV_ORDER = {ERR: 0, WARN: 1, INFO: 2, "": 3}


def _fill_coloured(cell):
    try:
        f = cell.fill
        if not f or f.fill_type != "solid":
            return False
        rgb = (f.fgColor.rgb or "") if isinstance(f.fgColor.rgb, str) else ""
        return rgb[-6:].upper() not in ("", "FFFFFF", "000000") and not rgb.endswith("F2F2F2")
    except Exception:  # noqa: BLE001
        return False


def open_book(path):
    """Excel file, or a text PDF converted to an in-memory workbook (one sheet per page)."""
    if str(path).lower().endswith(".pdf"):
        from .pdftable import pdf_to_workbook
        return pdf_to_workbook(path)
    import openpyxl
    return openpyxl.load_workbook(path, data_only=True)


NOTES = []      # messages from the last books opened (PDF read by AI: totals check)


def read_lines(path, label=None, sheets=None):
    """Read every sheet with a priced header. Returns (lines, skipped_sheets)."""
    wb = open_book(path)
    NOTES.extend(getattr(wb, "boq_notes", []))
    label = safe_text(label or Path(path).stem)
    out, skipped = [], []
    for ws in wb.worksheets:
        if sheets and ws.title.strip() not in [x.strip() for x in sheets]:
            continue
        hr, c = find_columns(ws)
        if not hr:
            skipped.append(ws.title)
            continue
        section = ""
        for r in range(hr + 1, ws.max_row + 1):
            desc = _s(ws.cell(r, c["desc"]).value)
            code = _s(ws.cell(r, c["code"]).value) if c["code"] else ""
            if isinstance(ws.cell(r, c["code"]).value if c["code"] else None, float):
                code = _code_from_float(ws.cell(r, c["code"]).value, ws.cell(r, c["code"]).number_format)
            q = _num(ws.cell(r, c["qty"]).value)
            if not desc and not code:
                continue
            if SKIP_DESC.match(desc) or SKIP_DESC.match(code):
                continue
            if q is None:
                if desc or code:
                    section = (code + " " + desc).strip()[:60]
                continue
            unit = _s(ws.cell(r, c["unit"]).value) if c["unit"] else ""
            if c["mat"] or c["lab"]:
                m = _num(ws.cell(r, c["mat"]).value) if c["mat"] else None
                lb = _num(ws.cell(r, c["lab"]).value) if c["lab"] else None
                rate = None if m is None and lb is None else (m or 0) + (lb or 0)
            else:
                rate = _num(ws.cell(r, c["rate"]).value) if c["rate"] else None
            acell = ws.cell(r, c["amount"]) if c["amount"] else None
            amount = _num(acell.value) if acell is not None else (q * rate if rate is not None else None)
            line = Line(label, safe_text(ws.title.strip()), r, section, code, desc, unit, q, rate, amount,
                        ref_amount=_num(ws.cell(r, c["ref_amount"]).value) if c["ref_amount"] else None,
                        extra=_num(ws.cell(r, c["extra"]).value) or 0.0 if c["extra"] else 0.0,
                        remark=_s(ws.cell(r, c["remark"]).value) if c["remark"] else "",
                        coloured=_fill_coloured(acell) if acell is not None else False)
            out.append(line)
    _fix_codes(out)
    return out, skipped


def _fix_codes(lines):
    """Excel keeps 1.10 as 1.1 — restore by order: 1.9 then 1.1 means 1.10."""
    prev = {}
    for x in lines:
        m = re.fullmatch(r"(\d+)\.(\d+)", x.code or "")
        if not m:
            continue
        key = (x.source, x.sheet, m.group(1))
        minor = m.group(2)
        last = prev.get(key)
        while last is not None and int(minor) <= last and len(minor) < 4:
            minor += "0"
        prev[key] = int(minor)
        x.code = f"{m.group(1)}.{minor}"


def _code_from_float(v, fmt):
    # 1.1 / 1.10 are different items but Excel stores both as 1.1 — keep the decimals shown by the format
    m = re.search(r"0\.(0+)", fmt or "")
    if m:
        return f"{v:.{len(m.group(1))}f}"
    return f"{v:g}"


def mark_summaries(lines):
    """A 1-lot line whose amount equals the sum of a run of other lines in the same file is a summary
    (e.g. page 2 "ELECTRICAL SYSTEM WORKS 1 Ls." = the electrical pages). Marks x.summary_of; returns them."""
    found = []
    by_src = {}
    for x in lines:
        by_src.setdefault(x.source, []).append(x)
    for src, xs in by_src.items():
        cands = [x for x in xs if x.qty is not None and abs(x.qty - 1) < 1e-9 and _unit_key(x.unit) == "lot"
                 and x.amount and x.amount > 0]
        if not cands or len(xs) < 3:
            continue
        for c in cands:
            others = [x for x in xs if x is not c and not getattr(x, "summary_of", None)]
            pref, pos = [0], {0: 0}
            for k, x in enumerate(others, 1):
                pref.append(pref[-1] + round((x.amount or 0) * 100))
                pos.setdefault(pref[-1], k)
            target = round(c.amount * 100)
            hit = None
            for i in range(len(others)):
                j = pos.get(pref[i] + target)
                if j is not None and j - i >= 2 and not (others[i].row <= c.row <= others[j - 1].row
                                                          and others[i].sheet == c.sheet):
                    hit = (others[i], others[j - 1])
                    break
            if hit:
                a, b = hit
                c.summary_of = f"{a.sheet} {a.code or ''} {a.desc[:25]} … {b.sheet} {b.code or ''} {b.desc[:25]}"
                found.append(c)
    return found


# ---------------------------------------------------------------- matching to a separate original BOQ
def _norm(s):
    s = _s(s).lower()
    s = re.sub(r"[^\w฀-๿]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _sim(a, b):
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return 0.0
    ta, tb = set(a.split()), set(b.split())
    tok = len(ta & tb) / max(1, len(ta | tb))
    return max(tok, SequenceMatcher(None, a, b).ratio())


def _unit_key(u):
    u = _norm(u).replace(" ", "")
    # order matters: linear metre is matched whole-word first ("เมตร" contains "ตร"), m3 before m2
    for k, pat in (("m", r"^(m|ม|เมตร|lm|lin\.?m|เมตรยาว|ม\.ยาว)$"), ("m3", r"(cbm|cu|ลบ|ลูกบาศก์|m3)"),
                   ("m2", r"(sq|ตร\.?ม|ตาราง|m2)"), ("kg", r"(kg|กก)"),
                   ("lot", r"(lot|job|jop|เหมา|ls|lump|งาน)"), ("set", r"(set|ชุด|pcs|ea|อัน|ตัว|บาน)")):
        if re.search(pat, u):
            return k
    return u


def match_to_original(quote, original):
    """Attach the best original line to each quote line (each original used once)."""
    n_q, n_o = len(quote), len(original)
    pairs = []
    for i, q in enumerate(quote):
        for j, o in enumerate(original):
            s = _sim(q.desc, o.desc)
            if s < 0.35:
                continue
            score = s
            if q.code and o.code and q.code == o.code:
                score += 0.35
            if _unit_key(q.unit) == _unit_key(o.unit):
                score += 0.2
            if q.qty is not None and o.qty is not None and abs(q.qty - o.qty) <= max(0.01, 0.005 * abs(o.qty)):
                score += 0.25
            score -= 0.3 * abs(i / max(1, n_q - 1) - j / max(1, n_o - 1))   # keep the order
            pairs.append((score, i, j))
    pairs.sort(reverse=True)
    used_q, used_o = set(), set()
    for score, i, j in pairs:
        if score < 0.75 or i in used_q or j in used_o:
            continue
        used_q.add(i)
        used_o.add(j)
        q, o = quote[i], original[j]
        q.ref = o
        if q.ref_amount is None:
            q.ref_amount = o.amount if o.amount is not None else (
                o.qty * o.rate if o.qty is not None and o.rate is not None else None)
    return [o for j, o in enumerate(original) if j not in used_o]


# ---------------------------------------------------------------- checks
def _part_of_line(x):
    """amount = p% × qty × rate, rate = original rate, p a round 5 % step below 100 -> p, else None."""
    if not (x.qty and x.rate and x.amount and x.ref_amount):
        return None
    if not _close(x.qty * x.rate, x.ref_amount, 1.0):
        return None
    p = 100 * x.amount / (x.qty * x.rate)
    if 0 < p < 99.5 and abs(p - round(p / 5) * 5) < 0.05:
        return round(p / 5) * 5
    return None


def _close(a, b, tol=0.5):
    return a is not None and b is not None and abs(a - b) <= max(tol, 0.0005 * abs(b))


def _flag(x, lv, text, question=None):
    if (lv, text) not in x.flags:
        x.flags.append((lv, text))
    if question and question not in x.question:
        x.question.append(question)


def over_rate(x):
    """Unit rate the contractor actually charges on this line (amount ÷ qty)."""
    return x.amount / x.qty if x.amount and x.qty else None


def check_lines(lines, only_over=False):
    """only_over: the client's rule — talk only about quantities counted ABOVE the original BOQ;
    lines not quoted / not priced / counted less are not raised."""
    for k, x in enumerate(lines):
        if x.summary_of:
            x.status = ST_SUMMARY
            _flag(x, INFO, f"เป็นยอดรวมของ {x.summary_of} — ไม่นับซ้ำ")
            continue
        remark_np = bool(NOT_PRICED.search(x.remark or "")) or bool(NOT_PRICED.search(x.desc or ""))
        has_amt = x.amount is not None and abs(x.amount) > 0.004
        if x.amount is not None and not has_amt and not remark_np and not x.coloured:
            x.status = ST_ZERO      # contractor typed 0 — nothing left to do on this line
        elif not has_amt:
            x.status = ST_UNPRICED
            why = f'เขียน "{x.remark}"' if remark_np else ("ช่องมีสี" if x.coloured else "ช่องว่าง")
            if not only_over:
                _flag(x, WARN, f"ไม่ใส่ราคา ({why})", "ขอราคาให้ครบ หรือยืนยันว่าไม่รับทำ")
        elif remark_np:
            x.status = ST_PRICED_ASK
            _flag(x, WARN, f'ใส่ราคา {x.amount:,.2f} แต่เขียน "{x.remark}"',
                  f'ใส่ราคา {x.amount:,.2f} แต่เขียน "{x.remark}" — รวมในราคาหรือไม่')
        else:
            x.status = ST_OK
        # figures shifted by one line (value belongs to the line above / below)
        if has_amt and x.ref_amount is not None and not _close(x.amount, x.ref_amount):
            for d, word in ((-1, "บน"), (1, "ล่าง")):
                y = lines[k + d] if 0 <= k + d < len(lines) else None
                if y is not None and y.sheet == x.sheet and _close(x.amount, y.ref_amount):
                    _flag(x, ERR, f"ตัวเลข {x.amount:,.2f} เท่ากับมูลค่าเดิมของบรรทัด{word} ({y.code} {y.desc[:30]}) "
                                  f"— น่าจะเลื่อนบรรทัด",
                          f"ตัวเลขข้อ {x.code} น่าจะเลื่อนมาจากบรรทัด{word} ({y.code}) — ขอแก้")
                    break
        # quantity × rate ≠ amount — a typed rate, or the price covers only part of the quantity
        x.ref_cmp = x.ref_amount
        part = _part_of_line(x) if has_amt else None
        if part is not None:
            x.ref_cmp = x.amount        # same unit price as the original, only part of the quantity
            _flag(x, INFO, f"คิด {part:g}% ของปริมาณ ด้วยราคาต่อหน่วยเดิม (น่าจะเป็นงานคงเหลือ)")
        else:
            # the BOQ value is only comparable when it sits in the contractor's own sheet (same unit rate);
            # a separately matched BOQ has its own rate, so qty × new rate ≠ BOQ value is normal
            pairs = [(x.amount if has_amt else None, "ยอดที่เสนอ")]
            if x.ref is None:
                pairs.append((x.ref_amount, "มูลค่า BOQ"))
            for val, name in pairs:
                if val and x.qty and x.rate and not _close(x.qty * x.rate, val, 1.0):
                    typo = any(_close(val / x.qty, x.rate * m, 1.0) for m in (10, 100, 1000))
                    note = (f"(ราคาต่อหน่วยที่ถูกน่าจะเป็น {val / x.qty:,.2f})" if typo
                            else f"(ยอด ÷ จำนวน = {val / x.qty:,.2f})")
                    _flag(x, WARN, f"จำนวน {x.qty:g} × ราคาต่อหน่วย {x.rate:,.2f} ไม่เท่ากับ{name} {val:,.2f} {note}",
                          f"ข้อ {x.code} ราคาต่อหน่วยพิมพ์ {x.rate:,.2f} ไม่ตรงกับยอด — ขอแก้")
                    break
        # against a separately matched original line
        if x.ref is not None:
            o = x.ref
            if x.qty is not None and o.qty is not None and not _close(x.qty, o.qty, 0.01):
                if x.qty > o.qty and has_amt and _unit_key(x.unit) == _unit_key(o.unit):
                    x.over_qty = x.qty - o.qty
                    r = over_rate(x)
                    back = f" — เอาคืน {x.over_qty * r:,.2f}" if r else ""
                    _flag(x, WARN, f"นับเกิน BOQ เดิม {x.over_qty:g} {o.unit} ({x.qty:g} > {o.qty:g}){back}",
                          f"ข้อ {x.code} ปริมาณ {x.qty:g} เกินที่ส่งไป ({o.qty:g} {o.unit}) — ขอใช้ปริมาณตามที่ส่ง")
                elif not only_over:
                    _flag(x, WARN, f"ปริมาณ {x.qty:g} ไม่ตรงกับ BOQ เดิม {o.qty:g} {o.unit}",
                          f"ข้อ {x.code} ปริมาณ {x.qty:g} ไม่ตรงกับที่ส่งไป ({o.qty:g} {o.unit}) — ขอใช้ปริมาณตามที่ส่ง")
        if not only_over and has_amt and x.ref_amount and x.qty and part is None and not any(
                "เลื่อนบรรทัด" in t for _, t in x.flags):
            new_r, old_r = x.amount / x.qty, x.ref_amount / x.qty
            if old_r and new_r > old_r * 1.005:
                _flag(x, INFO, f"แพงกว่าเดิม {100 * (new_r / old_r - 1):.1f}%")
            elif old_r and new_r < old_r * 0.995:
                _flag(x, INFO, f"ถูกกว่าเดิม {100 * (1 - new_r / old_r):.1f}%")
        if x.extra:
            _flag(x, WARN, f"ขอเพิ่ม {x.extra:,.2f}" + (f' ({x.remark})' if x.remark and not remark_np else ""),
                  f"ข้อ {x.code} ขอเพิ่ม {x.extra:,.2f} — ขอรายละเอียดและปริมาณจริง")
    # same description + quantity + amount twice (double charging) across sheets / files
    seen = {}
    for x in lines:
        if x.status not in (ST_UNPRICED, ST_SUMMARY) and x.amount:
            seen.setdefault((_norm(x.desc)[:40], round(x.qty or 0, 2), round(x.amount, 2)), []).append(x)
    dups = [v for v in seen.values() if len({(y.source, y.sheet) for y in v}) > 1]
    for grp in dups:
        for x in grp:
            others = ", ".join(f"{y.sheet} ข้อ {y.code}" for y in grp if y is not x)
            _flag(x, WARN, f"อาจคิดซ้ำกับ {others}", f"ข้อ {x.code} ซ้ำกับ {others} — ให้คิดครั้งเดียว")
    return dups


def run_compare(quote_paths, original_paths=None, ref_mult=1.0, new_mult=1.0, quote_sheets=None,
                original_sheets=None, only_over=False):
    quote, skipped = [], []
    NOTES.clear()
    for p in quote_paths:
        rows, sk = read_lines(p, sheets=quote_sheets)
        quote += rows
        skipped += [f"{Path(p).stem}: {s}" for s in sk]
    mark_summaries(quote)
    not_quoted = []
    if original_paths:
        original = []
        for p in original_paths:
            rows, sk = read_lines(p, sheets=original_sheets)
            original += rows
        mark_summaries(original)
        original = [o for o in original if not o.summary_of]
        not_quoted = match_to_original([q for q in quote if not q.summary_of], original)
        if only_over:
            not_quoted = []          # lines not quoted are not raised under this rule
    dups = check_lines(quote, only_over)
    return {"lines": quote, "not_quoted": not_quoted, "dups": dups, "skipped": skipped, "notes": list(NOTES),
            "only_over": only_over,
            "ref_mult": ref_mult, "new_mult": new_mult, "totals": totals(quote, not_quoted, ref_mult, new_mult)}


def totals(lines, not_quoted, ref_mult, new_mult):
    r2 = lambda v: round(v + 1e-9, 2)  # noqa: E731
    priced = [x for x in lines if x.priced]
    same = [x for x in priced if x.ref_cmp]
    t = {
        "n_lines": len(lines), "n_priced": len(priced),
        "n_summary": sum(1 for x in lines if x.summary_of),
        "n_unpriced": sum(1 for x in lines if x.status == ST_UNPRICED),
        "new_total": r2(sum(x.amount for x in priced)),
        "extra_total": r2(sum(x.extra for x in lines)),
        "same_new": r2(sum(x.amount for x in same)),
        "same_ref": r2(sum(x.ref_cmp for x in same)),
        "unpriced_ref": r2(sum(x.ref_amount or 0 for x in lines if x.status == ST_UNPRICED)),
        "not_quoted_ref": r2(sum((o.amount if o.amount is not None else (o.qty or 0) * (o.rate or 0))
                                 for o in not_quoted)),
        "n_not_quoted": len(not_quoted),
        "n_ref_known": sum(1 for x in lines if x.ref_amount is not None),
        "n_over": sum(1 for x in lines if x.over_qty),
        "over_total": r2(sum(x.over_qty * over_rate(x) for x in lines if x.over_qty and over_rate(x))),
    }
    t["same_new_cash"] = r2(t["same_new"] * new_mult)
    t["same_ref_cash"] = r2(t["same_ref"] * ref_mult)
    t["diff_cash"] = r2(t["same_new_cash"] - t["same_ref_cash"])
    return t


# ---------------------------------------------------------------- export
def export_compare(result, path, ask_path=None, title=""):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter as CL
    f = Font(name="Tahoma", size=10)
    fb = Font(name="Tahoma", size=10, bold=True, color="FFFFFF")
    head = PatternFill("solid", fgColor="2F5597")
    fills = {ERR: PatternFill("solid", fgColor="F8CBAD"), WARN: PatternFill("solid", fgColor="FFF2CC"),
             INFO: PatternFill("solid", fgColor="DDEBF7")}
    bd = Border(*(Side(style="thin", color="BFBFBF"),) * 4)
    MF = '#,##0.00;[Red]-#,##0.00'
    t, rm, nm = result["totals"], result["ref_mult"], result["new_mult"]

    def table(ws, cols, widths, rows, money=(), wrap=()):
        ws.append(cols)
        for i, (c, w) in enumerate(zip(cols, widths), 1):
            x = ws.cell(1, i)
            x.font, x.fill, x.border = fb, head, bd
            x.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
            ws.column_dimensions[CL(i)].width = w
        ws.row_dimensions[1].height = 32
        for row, lv in rows:
            ws.append(row)
            i = ws.max_row
            for c in range(1, len(cols) + 1):
                cell = ws.cell(i, c)
                cell.font, cell.border = f, bd
                cell.alignment = Alignment(vertical="top", wrap_text=c in wrap)
                if c in money:
                    cell.number_format = MF
            if lv:
                for c in (len(cols) - 2, len(cols) - 1):
                    ws.cell(i, c).fill = fills[lv]
        ws.freeze_panes = "D2"
        ws.auto_filter.ref = f"A1:{CL(len(cols))}{max(ws.max_row, 2)}"

    wb = Workbook()
    s = wb.active
    s.title = "สรุป"
    w = wb.create_sheet("เทียบรายบรรทัด")
    rows = []
    for x in result["lines"]:
        lv = min((fl[0] for fl in x.flags), key=lambda v: LV_ORDER[v], default="")
        o = x.ref
        part = any("ของปริมาณ ด้วยราคาต่อหน่วยเดิม" in tx for _, tx in x.flags)
        rows.append(([x.sheet, x.code, x.desc, x.unit,
                      o.qty if o else (x.qty if x.ref_amount is not None else None), x.qty,
                      (x.ref_amount / x.qty if x.ref_amount and x.qty else None),
                      (x.rate if part or not (x.amount and x.qty) else round(x.amount / x.qty, 2)),
                      x.ref_amount, x.amount if x.status != ST_UNPRICED else None, x.extra or None,
                      (x.amount - x.ref_cmp) if x.priced and x.ref_cmp else None,
                      x.status, " | ".join(tx for _, tx in x.flags), x.remark, x.where], lv))
    table(w, ["ชีท", "ข้อ", "รายการ", "หน่วย", "ปริมาณ BOQ เดิม", "ปริมาณในใบใหม่", "ราคา/หน่วย เดิม",
              "ราคา/หน่วย ใหม่", "มูลค่าเดิม", "มูลค่าที่เสนอ", "ขอเพิ่ม", "ต่าง (ใหม่ − เดิม)", "สถานะ",
              "ข้อสังเกต", "หมายเหตุในใบ", "ที่อยู่ในไฟล์"],
          [12, 7, 46, 7, 10, 10, 11, 11, 13, 13, 12, 13, 14, 60, 24, 26], rows,
          money=(5, 6, 7, 8, 9, 10, 11, 12), wrap=(3, 14, 15))
    # move the two highlighted columns to สถานะ / ข้อสังเกต
    for i in range(2, w.max_row + 1):
        for c in (14, 15):
            w.cell(i, c).fill = PatternFill(fill_type=None)
        lv = rows[i - 2][1]
        if lv:
            w.cell(i, 13).fill = fills[lv]
            w.cell(i, 14).fill = fills[lv]
    last = w.max_row
    nq = wb.create_sheet("ใบใหม่ไม่ได้เสนอ")
    table(nq, ["ชีท", "ข้อ", "รายการ", "หน่วย", "ปริมาณ", "ราคา/หน่วย เดิม", "มูลค่าเดิม", "ที่อยู่ในไฟล์ BOQ เดิม"],
          [12, 7, 50, 7, 10, 12, 13, 30],
          [([o.sheet, o.code, o.desc, o.unit, o.qty, o.rate,
             o.amount if o.amount is not None else (o.qty or 0) * (o.rate or 0), o.where], "")
           for o in result["not_quoted"]], money=(5, 6, 7), wrap=(3,))

    over = [x for x in result["lines"] if x.over_qty]
    if over:
        ov = wb.create_sheet("นับเกิน-เอาคืน", 1)
        table(ov, ["ชีท", "ข้อ", "รายการ", "หน่วย", "ปริมาณ BOQ เดิม", "ปริมาณในใบ", "นับเกิน",
                   "ราคา/หน่วยในใบ", "เอาคืน", "ที่อยู่ในไฟล์"],
              [12, 7, 46, 7, 11, 11, 10, 13, 14, 26],
              [([x.sheet, x.code, x.desc, x.unit, x.ref.qty, x.qty, None,
                 over_rate(x), None, x.where], "") for x in over],
              money=(5, 6, 7, 8, 9), wrap=(3,))
        for i in range(2, ov.max_row + 1):
            ov.cell(i, 7, f"=F{i}-E{i}").number_format = MF
            ov.cell(i, 9, f"=IF(H{i}=\"\",0,G{i}*H{i})").number_format = MF
        n = ov.max_row
        ov.append(["", "", "รวมเอาคืน", "", None, None, None, None, f"=SUM(I2:I{n})", ""])
        for c in range(1, 11):
            ov.cell(n + 1, c).font = Font(name="Tahoma", size=10, bold=True)
            ov.cell(n + 1, c).border = bd
        ov.cell(n + 1, 9).number_format = MF
    lines = [
        [title or "เทียบใบเสนอราคาผู้รับเหมาใหม่ กับ BOQ เดิม — BOQ Robot"], [],
        ["", "ก่อนตัวคูณ", "เงินที่จ่ายจริง (คูณแล้ว)"],
        ["ตัวคูณ BOQ เดิม / ใบใหม่", rm, nm],
        ["บรรทัดในใบใหม่", t["n_lines"]],
        ["  ใส่ราคา", t["n_priced"]],
        ["  ไม่ใส่ราคา", t["n_unpriced"]],
        ["ยอดที่ใส่ราคาในใบใหม่", t["new_total"], round(t["new_total"] * nm, 2)],
        ["ขอเพิ่ม (ช่องขอเพิ่มเติม)", t["extra_total"], round(t["extra_total"] * nm, 2)],
        ["บรรทัดเดียวกัน — ใบใหม่", t["same_new"], t["same_new_cash"]],
        ["บรรทัดเดียวกัน — BOQ เดิม", t["same_ref"], t["same_ref_cash"]],
        ["ต่างกัน (ใบใหม่ − เดิม)", round(t["same_new"] - t["same_ref"], 2), t["diff_cash"]],
        ["ยังไม่ใส่ราคา — มูลค่าเดิม", t["unpriced_ref"], round(t["unpriced_ref"] * rm, 2)],
        ["บรรทัดใน BOQ เดิมที่ใบใหม่ไม่ได้เสนอ", t["not_quoted_ref"], round(t["not_quoted_ref"] * rm, 2)],
        ["นับเกิน BOQ เดิม — เอาคืน (ดูชีท นับเกิน-เอาคืน)", t["over_total"], round(t["over_total"] * nm, 2)],
        [], ["วิธีอ่าน"],
        ["1. ดูชีท 'เทียบรายบรรทัด' เริ่มจากแถวสีแดง (ตัวเลขเลื่อนบรรทัด) แล้วสีเหลือง (ไม่ใส่ราคา / ขอแยก / ขอเพิ่ม / ปริมาณไม่ตรง)"],
        ["2. 'บรรทัดเดียวกัน' = เฉพาะบรรทัดที่ทั้งสองฝั่งมีราคา — ส่วนต่างเงินจริงดูคอลัมน์ C (คูณตัวคูณของแต่ละฝั่งแล้ว)"],
        ["3. ตัวเลขเลื่อนบรรทัดเป็นข้อสงสัย ให้เปิดไฟล์ผู้รับเหมาดูก่อน แล้วถามผู้รับเหมาให้แก้"],
        ["4. ไฟล์ 'เรื่องที่ต้องถาม (ส่งได้)' ไม่มีราคาเดิม ส่งผู้รับเหมาได้"],
    ]
    for ln in lines:
        s.append(ln)
    s["A1"].font = Font(name="Tahoma", size=13, bold=True)
    for row in s.iter_rows(min_row=2):
        for cell in row:
            cell.font = Font(name="Tahoma", size=10, bold=cell.row == 3)
            if cell.column in (2, 3) and isinstance(cell.value, (int, float)) and cell.row not in (5, 6, 7):
                cell.number_format = MF if cell.row != 4 else "0.0000"
    s.column_dimensions["A"].width = 44
    s.column_dimensions["B"].width = 18
    s.column_dimensions["C"].width = 22
    for n in result.get("notes", []):
        s.append([n])
    if result["skipped"]:
        s.append([])
        s.append(["ชีทที่ข้าม (หาแถวหัวตารางไม่เจอ): " + ", ".join(result["skipped"])])
    s.append([])
    s.append([f"ตรวจได้ {last - 1} บรรทัด · มีมูลค่าเดิมให้เทียบ {t['n_ref_known']} บรรทัด"])
    wb.save(path)

    if ask_path:
        aw = Workbook()
        a = aw.active
        a.title = "เรื่องที่ต้องถาม"
        qrows = [([x.sheet, x.code, x.desc, x.unit, x.qty, " / ".join(x.question)], "")
                 for x in result["lines"] if x.question]
        table(a, ["ชีท", "ข้อ", "รายการ", "หน่วย", "ปริมาณ", "เรื่องที่ต้องถาม / ขอแก้"],
              [12, 7, 50, 7, 10, 70], qrows, wrap=(3, 6))
        a.freeze_panes = "A2"
        aw.save(ask_path)
    return path
