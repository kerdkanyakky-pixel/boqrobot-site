"""Formula engine: evaluates item formulas like 'L*H' safely (no eval)."""
import ast
import operator

VARIABLES = {
    "L": "ความยาว / เส้นรอบรูป (ม.)",
    "A": "พื้นที่ (ตร.ม.)",
    "N": "จำนวน (นับ)",
    "H": "ความสูง (ม.)",
    "T": "ความหนา (ม.)",
    "W": "ความกว้าง (ม.)",
    "F": "ตัวคูณ (เช่น กก./ม., จำนวนด้าน)",
}

_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.USub: operator.neg, ast.UAdd: operator.pos,
}


class FormulaError(ValueError):
    pass


def _parse(expr: str):
    if not expr or not expr.strip():
        raise FormulaError("สูตรว่าง")
    expr = expr.replace("×", "*").replace("x", "*").replace("X", "*").replace("÷", "/")
    try:
        return ast.parse(expr, mode="eval").body
    except SyntaxError as e:
        raise FormulaError(f"สูตรไม่ถูกต้อง: {expr}") from e


def _ev(node, env):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if isinstance(node, ast.Name):
        if node.id not in VARIABLES:
            raise FormulaError(f"ไม่รู้จักตัวแปร {node.id} (ใช้ได้: {', '.join(VARIABLES)})")
        return float(env.get(node.id) or 0.0)
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        a, b = _ev(node.left, env), _ev(node.right, env)
        if isinstance(node.op, ast.Div) and b == 0:
            return 0.0
        return _OPS[type(node.op)](a, b)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_ev(node.operand, env))
    raise FormulaError("สูตรใช้ได้เฉพาะตัวเลข ตัวแปร และ + - * / ( )")


def evaluate(expr: str, env: dict) -> float:
    return _ev(_parse(expr), env)


def validate(expr: str) -> list:
    """Return list of variables used; raises FormulaError if invalid."""
    node = _parse(expr)
    _ev(node, {k: 1.0 for k in VARIABLES})
    return sorted({n.id for n in ast.walk(node) if isinstance(n, ast.Name)})


def describe(expr: str, env: dict) -> str:
    """Human readable substitution, e.g. 'L*H = 12.500 × 3.000'."""
    out = expr.replace("*", " × ").replace("/", " ÷ ")
    for k in VARIABLES:
        if k in out:
            out = out.replace(k, f"{env.get(k) or 0:,.3f}")
    return out
