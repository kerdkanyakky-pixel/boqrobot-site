"""Scale helpers (deterministic, no AI):
- detect_scale(): reads '1:100' text from the title block (suggestion only)
- estimate_from_dimensions(): measures dimension lines against their numbers in vector PDFs
  and fits mm-per-point. Robust to dimension lines trimmed at the ticks (fits slope, not ratio).
- sheet_info(): drawing number / name from the title block."""
import re
from collections import Counter
from itertools import combinations
from statistics import median

PT_TO_MM = 25.4 / 72.0
SCALE_RE = re.compile(r"1\s*[:：]\s*(\d{1,4}(?:\.\d+)?)(?![\d.])")
COMMON = [5, 10, 12.5, 15, 20, 25, 30, 35, 40, 50, 60, 75, 100, 125, 150, 200, 250, 300, 500, 1000]
CODE_RE = re.compile(r"^[A-Z]{1,3}\d?\s?-\s?\d{2,3}[A-Z]?$")
NAME_LABELS = ("DRAWING NAME", "SHEET TITLE", "TITLE", "ชื่อแบบ")
NO_LABELS = ("DRAWING NO", "SHEET NO", "DWG NO", "DWG. NO", "แผ่นที่", "เลขที่แบบ")
SCALE_LABELS = ("SCALE", "มาตราส่วน")


def _spans(page):
    out = []
    for b in page.get_text("dict")["blocks"]:
        for l in b.get("lines", []):
            for s in l["spans"]:
                t = s["text"].strip()
                if t:
                    out.append((t, s["size"], s["bbox"]))
    return out


def _below(spans, label_boxes, W):
    """Largest-font value span placed just below/right of a label (title-block style)."""
    best = None
    for lb in label_boxes:
        for t, sz, b in spans:
            if b[1] >= lb[1] - 2 and b[1] - lb[3] < 40 and b[0] >= lb[0] - 15 and b[0] - lb[0] < 150 \
                    and not any(t.upper().startswith(x) for x in NAME_LABELS + NO_LABELS + SCALE_LABELS):
                if best is None or sz > best[1]:
                    best = (t, sz, b)
    return best


def sheet_info(page):
    """Return dict(number, name, scale) read from the title block; empty strings if not found."""
    W = page.rect.width
    try:
        spans = _spans(page)
    except Exception:
        return {"number": "", "name": "", "scale": None}
    right = [s for s in spans if s[2][0] > W * 0.6]
    num = ""
    codes = [s for s in right if CODE_RE.match(s[0])]
    if codes:
        num = max(codes, key=lambda s: (s[1], s[2][3]))[0].replace(" ", "")
    name = ""
    lbl = [s[2] for s in right if s[0].upper().startswith(NAME_LABELS)]
    v = _below(right, lbl, W)
    if v and not CODE_RE.match(v[0]) and not SCALE_RE.search(v[0]):
        name = " ".join(v[0].split())
    scale = None
    lbl = [s[2] for s in right if s[0].upper().startswith(SCALE_LABELS) and len(s[0]) < 12]
    for t, sz, b in sorted(right, key=lambda s: -s[1]):
        m = SCALE_RE.search(t)
        if m and any(b[1] >= l[1] - 2 and b[1] - l[3] < 40 and abs(b[0] - l[0]) < 80 for l in lbl):
            scale = float(m.group(1))
            break
    return {"number": num, "name": name, "scale": scale}


def detect_scale(page):
    """Title-block scale if present, else the most frequent '1:N' on the sheet."""
    info = sheet_info(page)
    if info["scale"]:
        return info["scale"]
    try:
        text = page.get_text("text") or ""
    except Exception:
        return None
    found = [float(m.group(1)) for m in SCALE_RE.finditer(text)]
    found = [f for f in found if f in COMMON]
    return Counter(found).most_common(1)[0][0] if found else None


def _segments(page, clip=None):
    H, V = [], []
    for d in page.get_drawings():
        if clip is not None and not d["rect"].intersects(clip):
            continue
        for it in d["items"]:
            if it[0] == "l":
                segs = [(it[1], it[2])]
            elif it[0] == "re":
                r = it[1]
                segs = [(r.tl, r.tr), (r.bl, r.br), (r.tl, r.bl), (r.tr, r.br)]
            else:
                continue
            for a, b in segs:
                if abs(a.y - b.y) < 0.3 and abs(a.x - b.x) > 5:
                    H.append((min(a.x, b.x), max(a.x, b.x), (a.y + b.y) / 2))
                elif abs(a.x - b.x) < 0.3 and abs(a.y - b.y) > 5:
                    V.append((min(a.y, b.y), max(a.y, b.y), (a.x + b.x) / 2))
    return H, V


def dimension_pairs(page, clip=None):
    """(value_mm, line_length_pt, (x, y)) for numbers that sit on a parallel dimension line."""
    import fitz
    H, V = _segments(page, clip)
    pairs = []
    for w in page.get_text("words", clip=clip):
        t = w[4].replace(",", "")
        if not re.fullmatch(r"\d{3,5}", t):
            continue
        val = int(t)
        if not 100 <= val <= 80000:
            continue
        r = fitz.Rect(w[:4])
        cx, cy = (r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2
        hor = r.width >= r.height
        sz = r.height if hor else r.width
        best = None
        if hor:
            for x0, x1, y in H:
                off = abs(y - cy)
                if x0 - 1 <= cx <= x1 + 1 and off < sz * 1.8 and (best is None or off < best[0]):
                    best = (off, x1 - x0)
        else:
            for y0, y1, x in V:
                off = abs(x - cx)
                if y0 - 1 <= cy <= y1 + 1 and off < sz * 1.8 and (best is None or off < best[0]):
                    best = (off, y1 - y0)
        if best:
            pairs.append((val, best[1], (cx, cy)))
    return pairs


def estimate_from_dimensions(page, clip=None):
    """Fit length_pt = value/k - g  (k = mm per pt, g = tick trim). Returns dict or None."""
    pairs = dimension_pairs(page, clip)
    if len(pairs) < 3:
        return None
    ks = []
    uniq = list({(v, round(L, 1)) for v, L, _ in pairs})
    if len(uniq) > 150:
        uniq = sorted(uniq)[:: max(1, len(uniq) // 150)]
    for (v1, l1), (v2, l2) in combinations(uniq, 2):
        if abs(v2 - v1) >= 500 and abs(l2 - l1) > 5:
            k = (v2 - v1) / (l2 - l1)
            if k > 0:
                ks.append(k)
    if len(ks) < 3:
        return None
    k = median(ks)
    agree = sum(1 for x in ks if abs(x - k) / k < 0.01) / len(ks)
    ratio = k / PT_TO_MM
    std = next((s for s in COMMON if abs(ratio - s) / s < 0.006), None)
    if std:
        k, ratio = std * PT_TO_MM, float(std)
    # how many dimensions agree with the fitted scale (after trim)
    trims = [v / k - L for v, L, _ in pairs]
    g = median(trims)
    ok = sum(1 for v, L, _ in pairs if abs((L + g) * k - v) <= max(0.01 * v, 20))
    return {"mm_per_pt": k, "ratio": ratio, "standard": bool(std), "matches": ok,
            "total": len(pairs), "confidence": round(ok / len(pairs) * min(1, agree * 3), 2)}


def auto_scale_page(page):
    """Decide a scale for one sheet. Only returns a value when the title-block scale and the
    measured dimension lines agree (two independent sources) - or dimensions alone are very
    consistent. Returns (mm_per_pt or None, label, note, estimate)."""
    info = sheet_info(page)
    title = info["scale"] or detect_scale(page)
    try:
        est = estimate_from_dimensions(page)
    except Exception:
        est = None
    if est and est["confidence"] >= 0.3:
        agree = title and abs(est["ratio"] - title) / title < 0.01
        if agree:  # two sources agree -> use the standard title-block scale, not the fitted value
            return (title * PT_TO_MM, f"1:{title:g} (อัตโนมัติ ตรวจกับเส้นบอกระยะ "
                    f"{est['matches']}/{est['total']})", "ok", est)
        if not title and est["confidence"] >= 0.6 and est["standard"]:
            return (est["mm_per_pt"], f"1:{est['ratio']:g} (อัตโนมัติ ตรวจกับเส้นบอกระยะ "
                    f"{est['matches']}/{est['total']})", "ok", est)
        if title and est["standard"]:
            return None, "", (f"ขัดแย้ง: ในแบบเขียน 1:{title:g} แต่เส้นบอกระยะวัดได้ 1:{est['ratio']:g} "
                              f"({est['matches']}/{est['total']} เส้น)"), est

    if title:
        return None, "", f"มี 1:{title:g} ในแบบ แต่ยืนยันกับเส้นบอกระยะไม่ได้ — ตรวจแล้วตั้งเอง", None
    return None, "", "ไม่พบสเกล/เส้นบอกระยะ — ตั้งสเกลเองด้วยการคลิกเทียบระยะ", None


def auto_scale_task(path, page_no):
    """Process-pool entry point (PyMuPDF is not thread-safe, so we use processes)."""
    import fitz
    try:
        with fitz.open(path) as doc:
            return auto_scale_page(doc[page_no - 1])
    except Exception as e:
        return None, "", f"อ่านหน้านี้ไม่ได้: {e}", None
