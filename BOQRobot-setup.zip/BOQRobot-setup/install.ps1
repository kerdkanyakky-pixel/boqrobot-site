$ErrorActionPreference = 'Stop'
try {
  $here = Split-Path -Parent $MyInvocation.MyCommand.Path
  $src  = Join-Path $here 'BOQRobot'
  $dest = Join-Path $env:LOCALAPPDATA 'BOQRobot'
  if (-not (Test-Path (Join-Path $src 'python\pythonw.exe'))) {
    throw 'Please extract the whole zip first (right-click the zip > Extract All), then run Install_BOQRobot.bat from the extracted folder.'
  }
  Write-Host 'Step 1/3: closing old version (if open)...'
  Get-Process pythonw -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$dest*" } | Stop-Process -Force
  Write-Host 'Step 2/3: copying program (about 1 minute)...'
  if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
  Copy-Item -Recurse -Force $src $dest
  Get-ChildItem -Recurse $dest | Unblock-File -ErrorAction SilentlyContinue
  Write-Host 'Step 3/3: creating shortcuts...'
  $sh = New-Object -ComObject WScript.Shell
  foreach ($lnk in @(([Environment]::GetFolderPath('Desktop') + '\BOQ Robot.lnk'),
                     ([Environment]::GetFolderPath('Programs') + '\BOQ Robot.lnk'))) {
    $s = $sh.CreateShortcut($lnk)
    $s.TargetPath = Join-Path $dest 'python\pythonw.exe'
    $s.Arguments = '"' + (Join-Path $dest 'app\main.py') + '"'
    $s.WorkingDirectory = $dest
    $s.Save()
  }
  Write-Host ''
  Write-Host 'DONE - BOQ Robot is on your Desktop. Opening it now...' -ForegroundColor Green
  Start-Process (Join-Path $dest 'python\pythonw.exe') -ArgumentList ('"' + (Join-Path $dest 'app\main.py') + '"') -WorkingDirectory $dest
} catch {
  Write-Host ''
  Write-Host ('INSTALL FAILED: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host 'Please send a screenshot of this window to LINE 099-998-9222'
}
Read-Host 'Press Enter to close'
